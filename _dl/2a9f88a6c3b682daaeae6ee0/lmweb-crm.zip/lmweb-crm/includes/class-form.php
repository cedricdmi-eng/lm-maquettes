<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Formulaire de contact natif : [lmweb_crm_form].
 * Zéro JavaScript, quelques lignes de CSS en ligne seulement sur la page qui l'affiche.
 * Envoi classique (admin-post), pot de miel, délai minimal et limite par adresse IP.
 */
class LMCRM_Form {

	public static function init() {
		add_shortcode( 'lmweb_crm_form', array( __CLASS__, 'render' ) );
		add_action( 'admin_post_nopriv_lmcrm_form', array( __CLASS__, 'handle' ) );
		add_action( 'admin_post_lmcrm_form', array( __CLASS__, 'handle' ) );
	}

	private static function sign( $ts ) {
		return substr( hash_hmac( 'sha256', 'lmcrm|' . $ts, wp_salt( 'nonce' ) ), 0, 20 );
	}

	public static function render( $atts ) {
		$a = shortcode_atts( array(
			'bouton'     => 'Envoyer',
			'entreprise' => 'oui',
			'merci'      => 'Merci, votre message est bien reçu. Nous vous répondons rapidement.',
			'redirection' => '',
		), $atts, 'lmweb_crm_form' );

		static $css_done = false;
		$out = '';
		if ( ! $css_done ) {
			$css_done = true;
			$out     .= '<style id="lmcrm-form-css">.lmcrm-form{display:grid;gap:14px;max-width:640px}.lmcrm-form .lmcrm-row{display:grid;gap:14px;grid-template-columns:1fr}@media(min-width:600px){.lmcrm-form .lmcrm-row{grid-template-columns:1fr 1fr}}.lmcrm-form label{display:block;font-weight:600;margin-bottom:4px}.lmcrm-form input[type=text],.lmcrm-form input[type=email],.lmcrm-form input[type=tel],.lmcrm-form textarea{width:100%;box-sizing:border-box;padding:10px 12px;border:1px solid #c9ccd3;border-radius:8px;font:inherit;background:#fff;color:#1a1a1a}.lmcrm-form textarea{min-height:130px;resize:vertical}.lmcrm-form .lmcrm-consent{display:flex;gap:8px;align-items:flex-start;font-size:.9em}.lmcrm-form .lmcrm-consent input{margin-top:4px}.lmcrm-form .lmcrm-hp{position:absolute!important;left:-9999px!important;height:0;overflow:hidden}.lmcrm-form button{justify-self:start;cursor:pointer;border:0;border-radius:8px;padding:12px 22px;font:inherit;font-weight:700;background:var(--wp--preset--color--accent-1,#FF7020);color:#fff}.lmcrm-notice{padding:12px 16px;border-radius:8px;margin-bottom:14px}.lmcrm-ok{background:#e8f6ee;color:#1d6b3f}.lmcrm-err{background:#fdecea;color:#a12b20}</style>';
		}

		$status = isset( $_GET['lmcrm'] ) ? sanitize_key( wp_unslash( $_GET['lmcrm'] ) ) : '';
		if ( 'ok' === $status ) {
			return $out . '<div id="lmcrm-form" class="lmcrm-notice lmcrm-ok" role="status">' . esc_html( $a['merci'] ) . '</div>';
		}
		if ( 'err' === $status ) {
			$out .= '<div class="lmcrm-notice lmcrm-err" role="alert">Il manque une information : vérifiez votre nom, votre courriel et votre consentement, puis réessayez.</div>';
		} elseif ( 'trop' === $status ) {
			$out .= '<div class="lmcrm-notice lmcrm-err" role="alert">Trop d’envois depuis votre connexion. Réessayez dans une heure.</div>';
		}

		$ts     = time();
		$back   = remove_query_arg( 'lmcrm', ( is_ssl() ? 'https://' : 'http://' ) . ( isset( $_SERVER['HTTP_HOST'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_HOST'] ) ) : '' ) . ( isset( $_SERVER['REQUEST_URI'] ) ? esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '/' ) );
		$policy = function_exists( 'get_privacy_policy_url' ) ? get_privacy_policy_url() : '';

		$out .= '<form id="lmcrm-form" class="lmcrm-form" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">'
			. '<input type="hidden" name="action" value="lmcrm_form">'
			. '<input type="hidden" name="lmcrm_ts" value="' . esc_attr( $ts ) . '">'
			. '<input type="hidden" name="lmcrm_sig" value="' . esc_attr( self::sign( $ts ) ) . '">'
			. '<input type="hidden" name="lmcrm_back" value="' . esc_url( $back ) . '">'
			. '<input type="hidden" name="lmcrm_redirect" value="' . esc_url( $a['redirection'] ) . '">'
			. '<div class="lmcrm-hp" aria-hidden="true"><label>Ne pas remplir <input type="text" name="lmcrm_site" tabindex="-1" autocomplete="off"></label></div>'
			. '<div class="lmcrm-row"><div><label for="lmcrm-name">Nom *</label><input id="lmcrm-name" type="text" name="name" required maxlength="120" autocomplete="name"></div>'
			. ( 'non' !== $a['entreprise'] ? '<div><label for="lmcrm-company">Entreprise</label><input id="lmcrm-company" type="text" name="company" maxlength="160" autocomplete="organization"></div>' : '' )
			. '</div><div class="lmcrm-row"><div><label for="lmcrm-email">Courriel *</label><input id="lmcrm-email" type="email" name="email" required maxlength="160" autocomplete="email"></div>'
			. '<div><label for="lmcrm-phone">Téléphone</label><input id="lmcrm-phone" type="tel" name="phone" maxlength="40" autocomplete="tel"></div></div>'
			. '<div><label for="lmcrm-msg">Message</label><textarea id="lmcrm-msg" name="message" maxlength="3000"></textarea></div>'
			. '<label class="lmcrm-consent"><input type="checkbox" name="consent" value="1" required> <span>J’accepte que mes informations servent à répondre à ma demande'
			. ( $policy ? ' (<a href="' . esc_url( $policy ) . '">politique de confidentialité</a>)' : '' ) . '.</span></label>'
			. '<button type="submit">' . esc_html( $a['bouton'] ) . '</button></form>';
		return $out;
	}

	private static function ip() {
		foreach ( array( 'HTTP_CF_CONNECTING_IP', 'REMOTE_ADDR' ) as $k ) {
			if ( ! empty( $_SERVER[ $k ] ) ) {
				return sanitize_text_field( wp_unslash( $_SERVER[ $k ] ) );
			}
		}
		return '0';
	}

	public static function handle() {
		$p    = wp_unslash( $_POST );
		$back = isset( $p['lmcrm_back'] ) ? wp_validate_redirect( esc_url_raw( $p['lmcrm_back'] ), home_url( '/' ) ) : home_url( '/' );
		$go   = function ( $status ) use ( $back ) {
			wp_safe_redirect( add_query_arg( 'lmcrm', $status, $back ) . '#lmcrm-form' );
			exit;
		};

		$ts = isset( $p['lmcrm_ts'] ) ? (int) $p['lmcrm_ts'] : 0;
		// Robot : pot de miel rempli, signature invalide ou envoi en moins de 3 secondes. On fait comme si tout allait bien.
		if ( ! empty( $p['lmcrm_site'] ) || ! hash_equals( self::sign( $ts ), (string) ( $p['lmcrm_sig'] ?? '' ) ) || time() - $ts < 3 ) {
			$go( 'ok' );
		}

		$key = 'lmcrm_rl_' . md5( self::ip() );
		$n   = (int) get_transient( $key );
		if ( $n >= 5 ) {
			$go( 'trop' );
		}

		$name    = mb_substr( sanitize_text_field( $p['name'] ?? '' ), 0, 120 );
		$company = mb_substr( sanitize_text_field( $p['company'] ?? '' ), 0, 160 );
		$email   = sanitize_email( $p['email'] ?? '' );
		$phone   = mb_substr( sanitize_text_field( $p['phone'] ?? '' ), 0, 40 );
		$message = mb_substr( sanitize_textarea_field( $p['message'] ?? '' ), 0, 3000 );
		if ( '' === $name || ! is_email( $email ) || empty( $p['consent'] ) ) {
			$go( 'err' );
		}
		set_transient( $key, $n + 1, HOUR_IN_SECONDS );

		list( $cid, $created ) = LMCRM_DB::upsert_contact( array(
			'name'    => $name,
			'company' => $company,
			'email'   => $email,
			'phone'   => $phone,
			'source'  => 'form',
			'stage'   => 'nouveau',
		) );
		$page = wp_parse_url( $back, PHP_URL_PATH );
		LMCRM_DB::add_activity( $cid, 'form', 'Message reçu par le formulaire (' . $page . ')', $message . "\n\nConsentement : " . LMCRM_DB::now() );
		LMCRM_DB::add_task( $cid, 'Répondre au message du formulaire', LMCRM_DB::business_due( 1 ) );

		$lines = array(
			'Nom : ' . $name,
			$company ? 'Entreprise : ' . $company : '',
			'Courriel : ' . $email,
			$phone ? 'Téléphone : ' . $phone : '',
			'Page : ' . $back,
			'',
			$message,
			'',
			( $created ? 'Nouveau contact' : 'Contact déjà connu' ) . ' : ' . admin_url( 'admin.php?page=lmcrm&contact=' . $cid ),
		);
		LMCRM_Notify::lead( $cid, 'Nouveau message : ' . ( $company ?: $name ), implode( "\n", array_filter( $lines, function ( $l ) {
			return null !== $l;
		} ) ), array( 'Reply-To: ' . $name . ' <' . $email . '>' ) );

		$redirect = ! empty( $p['lmcrm_redirect'] ) ? wp_validate_redirect( esc_url_raw( $p['lmcrm_redirect'] ), '' ) : '';
		if ( $redirect ) {
			wp_safe_redirect( $redirect );
			exit;
		}
		$go( 'ok' );
	}
}

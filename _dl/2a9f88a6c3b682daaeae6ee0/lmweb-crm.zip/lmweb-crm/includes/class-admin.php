<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Interface d'administration : tableau de bord, contacts, pipeline, fiche, réglages.
 * Les fichiers CSS/JS ne se chargent que sur les écrans du CRM.
 */
class LMCRM_Admin {

	const SLUG = 'lmcrm';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_action( 'current_screen', array( __CLASS__, 'screen' ) );
		foreach ( array( 'save_contact', 'add_note', 'add_task', 'task', 'delete_contact', 'delete_note', 'settings', 'sync_now', 'meta_save', 'meta_sync', 'brand', 'stages', 'capture', 'backfill', 'member', 'license' ) as $a ) {
			add_action( 'admin_post_lmcrm_' . $a, array( __CLASS__, 'do_' . $a ) );
		}
	}

	public static function menu() {
		$due    = count( LMCRM_DB::open_tasks( null, 99 ) );
		$bubble = $due ? ' <span class="awaiting-mod">' . (int) $due . '</span>' : '';
		add_menu_page( 'CRM', 'CRM' . $bubble, 'lmcrm_use', self::SLUG, array( __CLASS__, 'page' ), 'dashicons-groups', 3 );
	}

	private static function is_app() {
		return empty( $_GET['view'] ) || 'settings' !== $_GET['view']; // phpcs:ignore
	}

	/** Écran du CRM : plein écran, sans les avis des autres extensions. */
	public static function screen( $screen ) {
		if ( ! $screen || 'toplevel_page_' . self::SLUG !== $screen->id || ! self::is_app() ) {
			return;
		}
		remove_all_actions( 'admin_notices' );
		remove_all_actions( 'all_admin_notices' );
		add_action( 'admin_head', function () {
			echo '<script>document.documentElement.classList.add("lmcrm-full")</script>';
			// Application installable sur l'écran d'accueil du téléphone (nécessaire aux notifications sur iPhone).
			$icon = LMCRM_Push::icon_url( 180 );
			echo '<link rel="manifest" href="' . esc_url( admin_url( 'admin-ajax.php?action=lmcrm_manifest' ) ) . '">'
				. '<meta name="theme-color" content="#13213D"><meta name="apple-mobile-web-app-capable" content="yes"><meta name="mobile-web-app-capable" content="yes">'
				. '<meta name="apple-mobile-web-app-title" content="' . esc_attr( LMCRM_API::brand()['name'] ) . '">'
				. ( $icon ? '<link rel="apple-touch-icon" href="' . esc_url( $icon ) . '">' : '' );
		} );
		add_filter( 'admin_title', function () {
			return LMCRM_API::brand()['name'];
		} );
	}

	public static function assets( $hook ) {
		if ( 'toplevel_page_' . self::SLUG !== $hook ) {
			return;
		}
		if ( ! self::is_app() ) {
			wp_enqueue_style( 'lmcrm-admin', LMCRM_URL . 'assets/admin.css', array(), LMCRM_VERSION );
			wp_enqueue_script( 'lmcrm-admin', LMCRM_URL . 'assets/admin.js', array(), LMCRM_VERSION, true );
			wp_localize_script( 'lmcrm-admin', 'LMCRM', array( 'rest' => esc_url_raw( rest_url( 'lmcrm/v1/' ) ), 'nonce' => wp_create_nonce( 'wp_rest' ) ) );
			return;
		}
		wp_enqueue_style( 'lmcrm-font', 'https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,500;12..96,700&display=swap', array(), null );
		wp_enqueue_style( 'lmcrm-app', LMCRM_URL . 'assets/app.css', array(), LMCRM_VERSION );
		wp_enqueue_script( 'lmcrm-app', LMCRM_URL . 'assets/app.js', array(), LMCRM_VERSION, true );
		wp_localize_script( 'lmcrm-app', 'LMCRM_APP', array(
			'rest'     => esc_url_raw( rest_url( 'lmcrm/v1/' ) ),
			'nonce'    => wp_create_nonce( 'wp_rest' ),
			'settings' => current_user_can( 'manage_options' ) ? self::url( array( 'view' => 'settings' ) ) : '',
			'wp'       => current_user_can( 'manage_options' ) ? admin_url() : '',
			'logout'   => wp_logout_url( wp_login_url() ),
			'assets'   => LMCRM_URL . 'assets/',
			'brand'    => LMCRM_API::brand(),
		) );
	}

	/* ---------- Aides ---------- */

	private static function url( array $args = array() ) {
		return add_query_arg( $args, admin_url( 'admin.php?page=' . self::SLUG ) );
	}

	private static function post_url( $action ) {
		return esc_url( admin_url( 'admin-post.php' ) );
	}

	private static function hidden( $action ) {
		return '<input type="hidden" name="action" value="lmcrm_' . esc_attr( $action ) . '">' . wp_nonce_field( 'lmcrm_' . $action, '_lmcrm', true, false );
	}

	private static function check( $action ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Accès refusé' );
		}
		check_admin_referer( 'lmcrm_' . $action, '_lmcrm' );
	}

	private static function back( array $args ) {
		wp_safe_redirect( self::url( $args ) );
		exit;
	}

	private static function ago( $date ) {
		if ( ! $date ) {
			return '';
		}
		$ts   = strtotime( $date );
		$diff = current_time( 'timestamp' ) - $ts;
		if ( $diff < 0 ) {
			return wp_date( 'j M Y', $ts );
		}
		if ( $diff < 3600 ) {
			return 'il y a ' . max( 1, (int) round( $diff / 60 ) ) . ' min';
		}
		if ( $diff < DAY_IN_SECONDS ) {
			return 'il y a ' . (int) round( $diff / 3600 ) . ' h';
		}
		if ( $diff < 30 * DAY_IN_SECONDS ) {
			$d = (int) round( $diff / DAY_IN_SECONDS );
			return 'il y a ' . $d . ' jour' . ( $d > 1 ? 's' : '' );
		}
		return wp_date( 'j M Y', $ts );
	}

	/* ---------- Page ---------- */

	public static function page() {
		if ( self::is_app() ) {
			$cid = isset( $_GET['contact'] ) ? (int) $_GET['contact'] : 0; // phpcs:ignore
			if ( $cid ) {
				echo '<script>location.replace(' . wp_json_encode( self::url() . '#/contact/' . $cid ) . ')</script>';
			}
			echo '<div id="lmcrm-app"></div>';
			return;
		}
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Accès réservé à l’administrateur du site.' );
		}
		echo '<div class="wrap lmcrm"><h1 class="lmcrm-title">Réglages du CRM</h1><p><a class="button" href="' . esc_url( self::url() ) . '">← Retour au CRM</a></p>';
		if ( ! empty( $_GET['msg'] ) ) { // phpcs:ignore
			$msgs = array( 'meta' => 'Relève Meta terminée : voir le bilan ci-dessous.', 'saved' => 'Enregistré.', 'synced' => 'Synchronisation faite.', 'member' => 'Accès créé : la personne reçoit un courriel pour choisir son mot de passe.', 'exists' => 'Cette adresse a déjà un compte : accès au CRM ajouté.', 'backfill' => 'Demandes déjà reçues importées : voir les contacts en « Contacté ».' );
			$m    = sanitize_key( wp_unslash( $_GET['msg'] ) ); // phpcs:ignore
			if ( isset( $msgs[ $m ] ) ) {
				echo '<div class="notice notice-success is-dismissible"><p>' . esc_html( $msgs[ $m ] ) . '</p></div>';
			}
		}
		self::view_settings();
		echo '</div>';
	}

	private static function view_settings() {
		$log  = get_option( 'lmcrm_inbox_log', array() );
		$last = get_option( 'lmcrm_last_sync' );
		echo '<form class="lmcrm-card lmcrm-edit" method="post" action="' . self::post_url( 'settings' ) . '">' . self::hidden( 'settings' ) // phpcs:ignore
			. '<h2>Réglages</h2><div class="lmcrm-grid">'
			. '<label>Courriel des avis et du résumé quotidien<input type="email" name="notify" value="' . esc_attr( LMCRM_Sources::notify_email() ) . '"></label>'
			. '<label class="lmcrm-check-label"><input type="checkbox" name="digest" value="1"' . checked( get_option( 'lmcrm_digest_on', 1 ), 1, false ) . '> Envoyer chaque matin (7 h 45) la liste des relances dues</label>'
			. '</div><p><button class="button button-primary">Enregistrer</button></p></form>';

		$b = LMCRM_API::brand();
		echo '<form class="lmcrm-card lmcrm-edit" method="post" action="' . self::post_url( 'brand' ) . '">' . self::hidden( 'brand' ) // phpcs:ignore
			. '<h2>Apparence</h2><p>Le nom, la couleur et le logo s’affichent dans l’application. Pour un client, mettez sa marque.</p><div class="lmcrm-grid">'
			. '<label>Nom de l’application<input type="text" name="name" value="' . esc_attr( $b['name'] ) . '"></label>'
			. '<label>Couleur principale<input type="color" name="color" value="' . esc_attr( $b['color'] ) . '" style="height:38px"></label>'
			. '<label>Adresse du logo (carré, facultatif)<input type="url" name="logo" value="' . esc_attr( $b['logo'] ) . '" placeholder="https://…"></label></div>'
			. '<p><button class="button button-primary">Enregistrer</button> <a class="button" href="' . esc_url( self::url( array( 'demo' => 1 ) ) ) . '">Ouvrir le mode démo (données fictives)</a> <a class="button" href="' . esc_url( self::url() . '#/setup' ) . '">Relancer l’assistant</a></p></form>';

		self::view_stages();
		self::view_capture();
		self::view_team();

		echo '<section class="lmcrm-card"><h2>Prospects Google Ads</h2><p>Dans Google Ads, ouvrez votre formulaire de prospects, section « Intégration CRM », choisissez « Webhook » et collez ces deux valeurs. Chaque prospect arrivera ici en quelques secondes.</p>'
			. '<p><strong>URL du webhook</strong><br><code>' . esc_html( rest_url( 'lmcrm/v1/google-lead' ) ) . '</code></p>'
			. '<p><strong>Clé</strong><br><code>' . esc_html( LMCRM_API::google_key() ) . '</code></p>'
			. '<p class="lmcrm-muted">Le bouton « Envoyer des données de test » de Google crée un contact marqué « (test Google) », que vous pouvez supprimer.</p></section>';

		$st    = get_option( 'lmcrm_meta_status' );
		$pname = get_option( 'lmcrm_meta_page_name' );
		echo '<form class="lmcrm-card lmcrm-edit" method="post" action="' . self::post_url( 'meta_save' ) . '">' . self::hidden( 'meta_save' ) // phpcs:ignore
			. '<h2>Prospects Meta (Lead Ads)</h2><p>Le site relève les formulaires instantanés de la Page toutes les 15 minutes, en arrière-plan. Le premier passage reprend l’historique en « Contacté », sans relance ; ensuite chaque prospect arrive en « Nouveau » avec une tâche et un courriel d’avis.</p><div class="lmcrm-grid">'
			. '<label>Jeton d’utilisateur système Meta<input type="password" name="token" autocomplete="off" placeholder="' . esc_attr( LMCRM_Meta::token() ? 'Jeton enregistré (laisser vide pour le garder)' : 'Coller le jeton' ) . '"></label>'
			. '<label>ID de la Page Facebook<input type="text" name="page" inputmode="numeric" value="' . esc_attr( LMCRM_Meta::page() ) . '">' . ( $pname ? '<span class="lmcrm-muted">' . esc_html( $pname ) . '</span>' : '' ) . '</label></div>'
			. ( $st ? '<p class="' . ( $st['ok'] ? 'lmcrm-muted' : 'lmcrm-late' ) . '">Dernière relève ' . esc_html( self::ago( $st['t'] ) ) . ' : ' . esc_html( $st['msg'] ) . '</p>' : '' )
			. '<p><button class="button button-primary">Enregistrer et relever maintenant</button></p></form>';

		echo '<section class="lmcrm-card"><h2>Formulaire de contact</h2><p>Placez ce code court dans un bloc « Code court » de n’importe quelle page :</p>'
			. '<p><code>[lmweb_crm_form]</code></p><p class="lmcrm-muted">Options : <code>bouton="Envoyer ma demande"</code>, <code>entreprise="non"</code>, <code>merci="Votre message…"</code>, <code>redirection="/merci/"</code>.</p></section>';

		echo '<section class="lmcrm-card"><h2>Synchronisation</h2><p>Les rendez-vous et les demandes de maquette arrivent instantanément ; un rattrapage passe aussi chaque heure.'
			. ( $last ? ' Dernier passage : ' . esc_html( self::ago( $last ) ) . '.' : '' ) . '</p>'
			. '<form method="post" action="' . self::post_url( 'sync_now' ) . '">' . self::hidden( 'sync_now' ) . '<button class="button">Tout resynchroniser maintenant</button></form>'; // phpcs:ignore
		if ( $log ) {
			echo '<h3>Derniers imports</h3><ul class="lmcrm-list">';
			foreach ( $log as $l ) {
				echo '<li>' . esc_html( $l['t'] . ' · ' . $l['file'] . ' : ' . $l['created'] . ' créés, ' . $l['updated'] . ' complétés' . ( $l['errors'] ? ', ' . $l['errors'] . ' ignorés' : '' ) ) . '</li>';
			}
			echo '</ul>';
		}
		echo '</section>';
		self::view_updates();
	}

	private static function view_stages() {
		$defs = LMCRM_DB::stage_defs();
		$rows = '';
		foreach ( $defs as $i => $d ) {
			$fixed = in_array( $d['key'], array( 'nouveau', 'contacte', 'gagne', 'perdu' ), true );
			$rows .= '<tr><td><input type="hidden" name="st[' . $i . '][key]" value="' . esc_attr( $d['key'] ) . '"><input type="text" name="st[' . $i . '][label]" value="' . esc_attr( $d['label'] ) . '" maxlength="40"' . ( $fixed ? ' required' : '' ) . '></td>'
				. '<td><input type="color" name="st[' . $i . '][color]" value="' . esc_attr( $d['color'] ) . '"></td>'
				. '<td class="lmcrm-muted">' . ( $fixed ? 'Toujours présente' : 'Vider le nom pour la supprimer' ) . '</td></tr>';
		}
		$n     = count( $defs );
		$rows .= '<tr><td><input type="text" name="st[' . $n . '][label]" placeholder="Ajouter une étape (avant le gain)" maxlength="40"></td><td><input type="color" name="st[' . $n . '][color]" value="#0891B2"></td><td></td></tr>';
		$tpl   = '<select name="template"><option value="">Garder ces étapes</option>';
		foreach ( LMCRM_DB::TEMPLATES as $k => $t ) {
			$tpl .= '<option value="' . esc_attr( $k ) . '">' . esc_html( $t['label'] . ' : ' . implode( ', ', $t['stages'] ) ) . '</option>';
		}
		$tpl .= '</select>';
		echo '<form class="lmcrm-card lmcrm-edit" method="post" action="' . self::post_url( 'stages' ) . '">' . self::hidden( 'stages' ) // phpcs:ignore
			. '<h2>Étapes du pipeline</h2><p>Renommez, recolorez ou ajoutez des étapes. Les contacts d’une étape supprimée passent en « ' . esc_html( LMCRM_DB::stages()['contacte'] ) . ' ».</p>'
			. '<table class="lmcrm-table"><tbody>' . $rows . '</tbody></table>'
			. '<p><label>Ou repartir d’un modèle de métier<br>' . $tpl . '</label></p>' // phpcs:ignore
			. '<p><button class="button button-primary">Enregistrer les étapes</button></p></form>';
	}

	private static function view_capture() {
		$set  = LMCRM_Capture::settings();
		$list = LMCRM_Capture::detected();
		$rows = '';
		foreach ( $list as $key => $title ) {
			$cfg   = $set['forms'][ $key ] ?? array();
			$rows .= '<tr><td><label><input type="checkbox" name="on[' . esc_attr( $key ) . ']" value="1"' . checked( empty( $cfg['off'] ), true, false ) . '> ' . esc_html( $title ) . '</label><br><span class="lmcrm-muted">' . esc_html( $key ) . '</span></td>'
				. '<td><input type="text" name="kind[' . esc_attr( $key ) . ']" value="' . esc_attr( $cfg['kind'] ?? '' ) . '" placeholder="Type de demande (facultatif), ex. Acheteur"></td></tr>';
		}
		$err = get_option( 'lmcrm_capture_error' );
		echo '<form class="lmcrm-card lmcrm-edit" method="post" action="' . self::post_url( 'capture' ) . '">' . self::hidden( 'capture' ) // phpcs:ignore
			. '<h2>Formulaires du site</h2><p>Chaque envoi des formulaires cochés devient un prospect « Nouveau », avec une relance immédiate et une notification. Les formulaires continuent d’envoyer leurs courriels habituels.</p>'
			. '<p><label class="lmcrm-check-label"><input type="checkbox" name="global" value="1"' . checked( ! empty( $set['on'] ), true, false ) . '> Capter les formulaires du site</label></p>'
			. ( $rows ? '<table class="lmcrm-table"><tbody>' . $rows . '</tbody></table>' : '<p class="lmcrm-muted">Aucun formulaire Forminator, Contact Form 7, WPForms ou Gravity Forms détecté. Fluent Forms et Elementor sont captés automatiquement.</p>' )
			. ( $err ? '<p class="lmcrm-late">Dernière erreur : ' . esc_html( $err ) . '</p>' : '' )
			. '<p><button class="button button-primary">Enregistrer</button></p></form>';
		if ( class_exists( 'Forminator_API' ) ) {
			echo '<form class="lmcrm-card" method="post" action="' . self::post_url( 'backfill' ) . '">' . self::hidden( 'backfill' ) // phpcs:ignore
				. '<h2>Demandes déjà reçues</h2><p>Importe les envois passés des formulaires Forminator en « ' . esc_html( LMCRM_DB::stages()['contacte'] ) . ' », sans relance ni notification. Les personnes déjà présentes dans le CRM ne sont pas dupliquées.</p>'
				. '<p><button class="button">Importer l’historique</button></p></form>';
		}
	}

	private static function view_team() {
		$users = get_users( array( 'capability__in' => array( 'lmcrm_use', 'manage_options' ) ) );
		$li    = '';
		foreach ( $users as $u ) {
			$li .= '<li>' . esc_html( $u->display_name . ' · ' . $u->user_email ) . ( user_can( $u, 'manage_options' ) ? ' <span class="lmcrm-muted">(administrateur)</span>' : '' ) . '</li>';
		}
		echo '<form class="lmcrm-card lmcrm-edit" method="post" action="' . self::post_url( 'member' ) . '">' . self::hidden( 'member' ) // phpcs:ignore
			. '<h2>Équipe</h2><p>Chaque membre a son propre accès au CRM (et seulement au CRM), reçoit les notifications sur son téléphone et peut se voir attribuer des prospects.</p>'
			. '<ul class="lmcrm-list">' . $li . '</ul><div class="lmcrm-grid">'
			. '<label>Prénom et nom<input type="text" name="name" required></label>'
			. '<label>Courriel<input type="email" name="email" required></label></div>'
			. '<p><button class="button button-primary">Donner accès au CRM</button></p></form>';
	}

	private static function view_updates() {
		if ( LMCRM_Updater::is_server() ) {
			$host = sanitize_text_field( wp_unslash( $_GET['host'] ?? '' ) ); // phpcs:ignore
			echo '<section class="lmcrm-card"><h2>Mises à jour des sites clients</h2><p>Ce site distribue la version ' . esc_html( LMCRM_VERSION ) . ' du CRM. Chaque site client a besoin de sa clé (option <code>lmcrm_license</code>).</p>'
				. '<form method="get"><input type="hidden" name="page" value="lmcrm"><input type="hidden" name="view" value="settings"><label>Domaine du client <input type="text" name="host" value="' . esc_attr( $host ) . '" placeholder="exemple.ca"></label> <button class="button">Calculer la clé</button></form>'
				. ( $host ? '<p><code>' . esc_html( LMCRM_Updater::key_for( $host ) ) . '</code></p>' : '' ) . '</section>';
			return;
		}
		echo '<form class="lmcrm-card lmcrm-edit" method="post" action="' . self::post_url( 'license' ) . '">' . self::hidden( 'license' ) // phpcs:ignore
			. '<h2>Mises à jour</h2><p>Version installée : ' . esc_html( LMCRM_VERSION ) . '. Avec la clé fournie par LM Web, les nouvelles versions apparaissent dans Extensions comme pour toute extension.</p>'
			. '<div class="lmcrm-grid"><label>Clé de mise à jour<input type="text" name="license" value="' . esc_attr( get_option( 'lmcrm_license', '' ) ) . '"></label></div>'
			. '<p><button class="button">Enregistrer</button></p></form>';
	}

	/* ---------- Actions ---------- */

	public static function do_save_contact() {
		self::check( 'save_contact' );
		$p  = wp_unslash( $_POST );
		$id = (int) ( $p['id'] ?? 0 );
		$d  = array_intersect_key( $p, array_flip( array( 'name', 'company', 'email', 'phone', 'website', 'city', 'source', 'value', 'notes' ) ) );
		if ( $id ) {
			$stage = sanitize_key( $p['stage'] ?? '' );
			LMCRM_DB::update_contact( $id, $d );
			LMCRM_DB::set_stage( $id, $stage );
		} else {
			$d['stage'] = sanitize_key( $p['stage'] ?? 'nouveau' );
			$id         = LMCRM_DB::insert_contact( $d );
			LMCRM_DB::add_activity( $id, 'note', 'Contact créé manuellement' );
		}
		self::back( array( 'contact' => $id, 'msg' => 'saved' ) );
	}

	public static function do_add_note() {
		self::check( 'add_note' );
		$cid  = (int) ( $_POST['contact_id'] ?? 0 );
		$body = sanitize_textarea_field( wp_unslash( $_POST['body'] ?? '' ) );
		if ( $cid && '' !== trim( $body ) ) {
			LMCRM_DB::add_activity( $cid, 'note', 'Note', $body );
		}
		self::back( array( 'contact' => $cid, 'msg' => 'note' ) );
	}

	public static function do_delete_note() {
		self::check( 'delete_note' );
		LMCRM_DB::delete_activity( (int) ( $_POST['id'] ?? 0 ) );
		self::back( array( 'contact' => (int) ( $_POST['contact_id'] ?? 0 ) ) );
	}

	public static function do_add_task() {
		self::check( 'add_task' );
		$cid   = (int) ( $_POST['contact_id'] ?? 0 );
		$title = sanitize_text_field( wp_unslash( $_POST['title'] ?? '' ) );
		$due   = sanitize_text_field( wp_unslash( $_POST['due'] ?? '' ) );
		$due   = preg_match( '/^\d{4}-\d{2}-\d{2}$/', $due ) ? $due . ' 09:00:00' : null;
		if ( $title ) {
			LMCRM_DB::add_task( $cid, $title, $due );
		}
		self::back( array( 'contact' => $cid, 'msg' => 'task' ) );
	}

	public static function do_task() {
		self::check( 'task' );
		$id = (int) ( $_POST['id'] ?? 0 );
		$t  = LMCRM_DB::task( $id );
		if ( 'delete' === ( $_POST['op'] ?? '' ) ) {
			LMCRM_DB::delete_task( $id );
		} else {
			LMCRM_DB::complete_task( $id );
		}
		self::back( $t && $t['contact_id'] ? array( 'contact' => $t['contact_id'] ) : array() );
	}

	public static function do_delete_contact() {
		self::check( 'delete_contact' );
		LMCRM_DB::delete_contact( (int) ( $_POST['id'] ?? 0 ) );
		self::back( array() );
	}

	public static function do_settings() {
		self::check( 'settings' );
		$e = sanitize_email( wp_unslash( $_POST['notify'] ?? '' ) );
		update_option( 'lmcrm_notify', is_email( $e ) ? $e : '', false );
		update_option( 'lmcrm_digest_on', empty( $_POST['digest'] ) ? 0 : 1, false );
		self::back( array( 'view' => 'settings', 'msg' => 'saved' ) );
	}

	public static function do_brand() {
		self::check( 'brand' );
		$color = sanitize_hex_color( wp_unslash( $_POST['color'] ?? '' ) );
		update_option( 'lmcrm_brand', array(
			'name'  => mb_substr( sanitize_text_field( wp_unslash( $_POST['name'] ?? '' ) ), 0, 40 ),
			'color' => $color ? $color : '#FF7020',
			'logo'  => esc_url_raw( wp_unslash( $_POST['logo'] ?? '' ) ),
		), false );
		self::back( array( 'view' => 'settings', 'msg' => 'saved' ) );
	}

	public static function do_stages() {
		self::check( 'stages' );
		$tpl = sanitize_key( wp_unslash( $_POST['template'] ?? '' ) );
		if ( $tpl && isset( LMCRM_DB::TEMPLATES[ $tpl ] ) ) {
			LMCRM_DB::apply_template( $tpl );
		} else {
			$rows = array();
			foreach ( (array) wp_unslash( $_POST['st'] ?? array() ) as $r ) { // phpcs:ignore
				$rows[] = array( 'key' => $r['key'] ?? '', 'label' => $r['label'] ?? '', 'color' => $r['color'] ?? '' );
			}
			// Une nouvelle étape s'insère avant « gagné » et « perdu ».
			$tail = array();
			$mid  = array();
			foreach ( $rows as $r ) {
				if ( in_array( $r['key'], array( 'gagne', 'perdu' ), true ) ) {
					$tail[] = $r;
				} else {
					$mid[] = $r;
				}
			}
			LMCRM_DB::save_stages( array_merge( $mid, $tail ) );
		}
		self::back( array( 'view' => 'settings', 'msg' => 'saved' ) );
	}

	public static function do_capture() {
		self::check( 'capture' );
		$forms = array();
		$on    = (array) ( $_POST['on'] ?? array() ); // phpcs:ignore
		$kind  = (array) wp_unslash( $_POST['kind'] ?? array() ); // phpcs:ignore
		foreach ( array_keys( LMCRM_Capture::detected() ) as $key ) {
			$forms[ $key ] = array( 'off' => empty( $on[ $key ] ) ? 1 : 0, 'kind' => mb_substr( sanitize_text_field( $kind[ $key ] ?? '' ), 0, 40 ) );
		}
		update_option( LMCRM_Capture::OPT, array( 'on' => empty( $_POST['global'] ) ? 0 : 1, 'forms' => $forms ), false );
		self::back( array( 'view' => 'settings', 'msg' => 'saved' ) );
	}

	public static function do_backfill() {
		self::check( 'backfill' );
		LMCRM_Capture::backfill();
		self::back( array( 'view' => 'settings', 'msg' => 'backfill' ) );
	}

	public static function do_member() {
		self::check( 'member' );
		$email = sanitize_email( wp_unslash( $_POST['email'] ?? '' ) );
		$name  = sanitize_text_field( wp_unslash( $_POST['name'] ?? '' ) );
		if ( ! is_email( $email ) ) {
			self::back( array( 'view' => 'settings' ) );
		}
		$u = get_user_by( 'email', $email );
		if ( $u ) {
			$u->add_cap( 'lmcrm_use' );
			self::back( array( 'view' => 'settings', 'msg' => 'exists' ) );
		}
		$parts = preg_split( '/\s+/', trim( $name ), 2 );
		$login = sanitize_user( strtolower( remove_accents( str_replace( ' ', '.', $name ) ) ), true );
		if ( '' === $login || username_exists( $login ) ) {
			$login = sanitize_user( strtok( $email, '@' ), true ) . wp_rand( 10, 99 );
		}
		$id = wp_insert_user( array(
			'user_login'   => $login,
			'user_email'   => $email,
			'user_pass'    => wp_generate_password( 24 ),
			'first_name'   => $parts[0] ?? '',
			'last_name'    => $parts[1] ?? '',
			'display_name' => $name ? $name : $email,
			'role'         => 'lmcrm_user',
		) );
		if ( ! is_wp_error( $id ) ) {
			wp_new_user_notification( $id, null, 'user' );
		}
		self::back( array( 'view' => 'settings', 'msg' => 'member' ) );
	}

	public static function do_license() {
		self::check( 'license' );
		update_option( 'lmcrm_license', sanitize_text_field( wp_unslash( $_POST['license'] ?? '' ) ), false );
		delete_transient( 'lmcrm_update_info' );
		delete_site_transient( 'update_plugins' );
		self::back( array( 'view' => 'settings', 'msg' => 'saved' ) );
	}

	public static function do_meta_save() {
		self::check( 'meta_save' );
		$token = trim( sanitize_text_field( wp_unslash( $_POST['token'] ?? '' ) ) );
		if ( '' !== $token ) {
			LMCRM_Meta::save_token( $token );
		}
		update_option( 'lmcrm_meta_page', preg_replace( '/\D/', '', (string) wp_unslash( $_POST['page'] ?? '' ) ), false );
		delete_transient( 'lmcrm_meta_pt' );
		LMCRM_Meta::schedule();
		if ( LMCRM_Meta::ready() ) {
			LMCRM_Meta::sync();
		}
		self::back( array( 'view' => 'settings', 'msg' => 'meta' ) );
	}

	public static function do_meta_sync() {
		self::check( 'meta_sync' );
		LMCRM_Meta::sync();
		self::back( array( 'view' => 'settings', 'msg' => 'meta' ) );
	}

	public static function do_sync_now() {
		self::check( 'sync_now' );
		LMCRM_Sources::sync( true );
		self::back( array( 'view' => 'settings', 'msg' => 'synced' ) );
	}
}

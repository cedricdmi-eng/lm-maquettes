<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Mises à jour du CRM sur tous les sites clients, sans dépôt public.
 *
 * Serveur (lm-web.ca, option lmcrm_update_server = 1) : il publie sa propre version installée.
 *   GET /wp-json/lmcrm-update/v1/info?host=…&key=…      version, notes
 *   GET /wp-json/lmcrm-update/v1/download?host=…&key=…  archive .zip générée à la volée
 * La clé d'un site = HMAC du domaine avec le secret du serveur : un site sans clé ne télécharge rien.
 *
 * Client (tous les autres sites) : WordPress affiche la mise à jour dans Extensions, comme pour
 * n'importe quelle extension, et l'installe d'un clic (ou automatiquement si activé).
 */
class LMCRM_Updater {

	const SERVER = 'https://lm-web.ca/wp-json/lmcrm-update/v1/';
	const SLUG   = 'lmweb-crm';

	public static function init() {
		if ( self::is_server() ) {
			add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
			return;
		}
		add_filter( 'pre_set_site_transient_update_plugins', array( __CLASS__, 'check' ) );
		add_filter( 'plugins_api', array( __CLASS__, 'details' ), 10, 3 );
		add_filter( 'http_request_args', array( __CLASS__, 'download_args' ), 10, 2 );
	}

	public static function is_server() {
		return (bool) get_option( 'lmcrm_update_server' );
	}

	private static function host() {
		return strtolower( preg_replace( '/^www\./', '', (string) wp_parse_url( home_url(), PHP_URL_HOST ) ) );
	}

	/* ---------- Serveur ---------- */

	private static function secret() {
		$s = (string) get_option( 'lmcrm_update_secret', '' );
		if ( '' === $s ) {
			$s = wp_generate_password( 48, false );
			update_option( 'lmcrm_update_secret', $s, false );
		}
		return $s;
	}

	/** Clé de mise à jour d'un domaine client (à enregistrer dans son option lmcrm_license). */
	public static function key_for( $host ) {
		$host = strtolower( preg_replace( '/^www\./', '', trim( (string) $host ) ) );
		return substr( hash_hmac( 'sha256', $host, self::secret() ), 0, 32 );
	}

	public static function routes() {
		$auth = function ( WP_REST_Request $r ) {
			$host = (string) $r->get_param( 'host' );
			return '' !== $host && hash_equals( self::key_for( $host ), (string) $r->get_param( 'key' ) );
		};
		register_rest_route( 'lmcrm-update/v1', '/info', array(
			'methods'             => 'GET',
			'permission_callback' => $auth,
			'callback'            => function () {
				return array(
					'version'  => LMCRM_VERSION,
					'requires' => '6.0',
					'php'      => '7.4',
					'notes'    => (string) get_option( 'lmcrm_release_notes', '' ),
				);
			},
		) );
		register_rest_route( 'lmcrm-update/v1', '/download', array(
			'methods'             => 'GET',
			'permission_callback' => $auth,
			'callback'            => array( __CLASS__, 'download' ),
		) );
	}

	/** Archive de la version installée sur le serveur (dossier lmweb-crm/, sans la boîte de dépôt). */
	public static function zip_path() {
		$up   = wp_upload_dir();
		$dir  = trailingslashit( $up['basedir'] ) . 'lmcrm-releases';
		$file = $dir . '/lmweb-crm-' . LMCRM_VERSION . '.zip';
		if ( file_exists( $file ) ) {
			return $file;
		}
		if ( ! class_exists( 'ZipArchive' ) ) {
			return new WP_Error( 'lmcrm', 'ZipArchive absent du serveur' );
		}
		wp_mkdir_p( $dir );
		if ( ! file_exists( $dir . '/index.php' ) ) {
			file_put_contents( $dir . '/index.php', "<?php // Silence.\n" ); // phpcs:ignore
			file_put_contents( $dir . '/.htaccess', "Require all denied\nDeny from all\n" ); // phpcs:ignore
		}
		$zip = new ZipArchive();
		if ( true !== $zip->open( $file, ZipArchive::CREATE | ZipArchive::OVERWRITE ) ) {
			return new WP_Error( 'lmcrm', 'Archive impossible à créer' );
		}
		$base = LMCRM_DIR;
		$it   = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $base, FilesystemIterator::SKIP_DOTS ) );
		foreach ( $it as $f ) {
			$rel = ltrim( str_replace( '\\', '/', substr( $f->getPathname(), strlen( $base ) ) ), '/' );
			if ( preg_match( '#^(inbox/(?!index\.php$|\.htaccess$)|\.git/|harness/)#', $rel ) || preg_match( '/\.(zip|bak)$/', $rel ) ) {
				continue;
			}
			$zip->addFile( $f->getPathname(), self::SLUG . '/' . $rel );
		}
		$zip->close();
		return $file;
	}

	public static function download() {
		$file = self::zip_path();
		if ( is_wp_error( $file ) ) {
			return $file;
		}
		nocache_headers();
		header( 'Content-Type: application/zip' );
		header( 'Content-Disposition: attachment; filename="lmweb-crm.zip"' );
		header( 'Content-Length: ' . filesize( $file ) );
		readfile( $file ); // phpcs:ignore
		exit;
	}

	/* ---------- Client ---------- */

	private static function license() {
		return (string) get_option( 'lmcrm_license', '' );
	}

	private static function remote() {
		$hit = get_transient( 'lmcrm_update_info' );
		if ( false !== $hit ) {
			return $hit;
		}
		$info = null;
		if ( '' !== self::license() ) {
			$r = wp_remote_get( add_query_arg( array( 'host' => self::host(), 'key' => self::license() ), self::SERVER . 'info' ), array( 'timeout' => 8 ) );
			if ( ! is_wp_error( $r ) && 200 === wp_remote_retrieve_response_code( $r ) ) {
				$j    = json_decode( wp_remote_retrieve_body( $r ), true );
				$info = is_array( $j ) && ! empty( $j['version'] ) ? $j : null;
			}
		}
		set_transient( 'lmcrm_update_info', $info ? $info : array(), 6 * HOUR_IN_SECONDS );
		return $info ? $info : array();
	}

	private static function package() {
		return add_query_arg( array( 'host' => self::host(), 'key' => self::license() ), self::SERVER . 'download' );
	}

	public static function check( $transient ) {
		if ( ! is_object( $transient ) ) {
			return $transient;
		}
		$info = self::remote();
		$file = self::SLUG . '/lmweb-crm.php';
		if ( ! empty( $info['version'] ) && version_compare( $info['version'], LMCRM_VERSION, '>' ) ) {
			$transient->response[ $file ] = (object) array(
				'slug'        => self::SLUG,
				'plugin'      => $file,
				'new_version' => $info['version'],
				'package'     => self::package(),
				'url'         => 'https://lm-web.ca/',
				'requires_php' => $info['php'] ?? '7.4',
			);
		} else {
			$transient->no_update[ $file ] = (object) array( 'slug' => self::SLUG, 'plugin' => $file, 'new_version' => LMCRM_VERSION, 'url' => 'https://lm-web.ca/', 'package' => '' );
		}
		return $transient;
	}

	public static function details( $res, $action, $args ) {
		if ( 'plugin_information' !== $action || self::SLUG !== ( $args->slug ?? '' ) ) {
			return $res;
		}
		$info = self::remote();
		return (object) array(
			'name'          => 'LM Web – CRM',
			'slug'          => self::SLUG,
			'version'       => $info['version'] ?? LMCRM_VERSION,
			'author'        => 'LM Web',
			'homepage'      => 'https://lm-web.ca/',
			'download_link' => self::package(),
			'sections'      => array( 'changelog' => wpautop( esc_html( $info['notes'] ?? '' ) ) ),
		);
	}

	/** Le téléchargement de l'archive ne suit pas de redirection vers un autre domaine. */
	public static function download_args( $args, $url ) {
		if ( 0 === strpos( (string) $url, self::SERVER ) ) {
			$args['timeout'] = 60;
		}
		return $args;
	}
}

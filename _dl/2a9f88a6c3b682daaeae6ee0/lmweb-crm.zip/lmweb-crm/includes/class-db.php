<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Données du CRM : trois tables dédiées (contacts, activités, tâches).
 * Rien dans wp_posts ni wp_postmeta, aucune option chargée automatiquement.
 */
class LMCRM_DB {

	/**
	 * Modèles d'étapes par métier. « nouveau », « contacte », « gagne » et « perdu » existent toujours
	 * (leur libellé change) ; les étapes du milieu varient. Clés connues des automatismes :
	 * planifie (rendez-vous réservé), rencontre (rendez-vous passé), maquette (présentation LM Web).
	 */
	const TEMPLATES = array(
		'general'  => array(
			'label'  => 'Général',
			'hint'   => 'Pour la plupart des entreprises de services.',
			'stages' => array( 'nouveau' => 'Nouveau', 'contacte' => 'Contacté', 'rencontre' => 'Rendez-vous effectué', 'soumission' => 'Soumission envoyée', 'gagne' => 'Client', 'perdu' => 'Perdu' ),
		),
		'services' => array(
			'label'  => 'Services à domicile et construction',
			'hint'   => 'Plombier, électricien, rénovation, déneigement, entretien…',
			'stages' => array( 'nouveau' => 'Nouveau', 'contacte' => 'Contacté', 'visite' => 'Visite ou estimation', 'soumission' => 'Soumission envoyée', 'gagne' => 'Travaux confirmés', 'perdu' => 'Perdu' ),
		),
		'immo'     => array(
			'label'  => 'Courtage immobilier',
			'hint'   => 'Acheteurs et vendeurs, du premier appel à la transaction.',
			'stages' => array( 'nouveau' => 'Nouveau', 'contacte' => 'Contacté', 'rencontre' => 'Rencontre effectuée', 'mandat' => 'Contrat signé', 'offre' => 'Offre acceptée', 'gagne' => 'Transaction conclue', 'perdu' => 'Perdu' ),
		),
		'sante'    => array(
			'label'  => 'Santé et bien-être',
			'hint'   => 'Clinique, physiothérapie, dentiste, massothérapie…',
			'stages' => array( 'nouveau' => 'Nouveau', 'contacte' => 'Contacté', 'planifie' => 'Rendez-vous planifié', 'rencontre' => 'Première visite faite', 'gagne' => 'Patient suivi', 'perdu' => 'Perdu' ),
		),
		'pro'      => array(
			'label'  => 'Services professionnels',
			'hint'   => 'Comptable, avocat, conseiller financier, consultant…',
			'stages' => array( 'nouveau' => 'Nouveau', 'contacte' => 'Contacté', 'rencontre' => 'Rencontre effectuée', 'soumission' => 'Proposition envoyée', 'gagne' => 'Client', 'perdu' => 'Perdu' ),
		),
		'agence'   => array(
			'label'  => 'Agence web et marketing',
			'hint'   => 'Le pipeline de LM Web, avec la maquette.',
			'stages' => array( 'nouveau' => 'Nouveau', 'contacte' => 'Contacté', 'rencontre' => 'Rendez-vous effectué', 'maquette' => 'Maquette envoyée', 'soumission' => 'Soumission', 'gagne' => 'Client', 'perdu' => 'Perdu' ),
		),
	);

	const STAGE_COLORS = array(
		'nouveau' => '#3B7BF6', 'contacte' => '#8B5CF6', 'planifie' => '#0891B2', 'rencontre' => '#0E9F8E', 'visite' => '#0E9F8E',
		'maquette' => '#F08A24', 'mandat' => '#F08A24', 'soumission' => '#E2468E', 'offre' => '#E2468E', 'gagne' => '#11A36B', 'perdu' => '#8A93A6',
	);
	const PALETTE = array( '#0891B2', '#D97706', '#DB2777', '#7C3AED', '#65A30D', '#0E9F8E' );

	private static $defs = null;

	/** Étapes en vigueur : liste ordonnée de array( key, label, color, short ). */
	public static function stage_defs() {
		if ( null !== self::$defs ) {
			return self::$defs;
		}
		$opt = get_option( 'lmcrm_stages' );
		if ( ! is_array( $opt ) || empty( $opt ) ) {
			$opt = self::template_defs( 'general' );
		}
		$by = array();
		foreach ( $opt as $d ) {
			if ( is_array( $d ) && ! empty( $d['key'] ) && ! isset( $by[ $d['key'] ] ) ) {
				$by[ $d['key'] ] = $d;
			}
		}
		$fixed = array( 'nouveau' => 'Nouveau', 'contacte' => 'Contacté', 'gagne' => 'Client', 'perdu' => 'Perdu' );
		$list  = array( $by['nouveau'] ?? array( 'key' => 'nouveau', 'label' => $fixed['nouveau'] ), $by['contacte'] ?? array( 'key' => 'contacte', 'label' => $fixed['contacte'] ) );
		foreach ( $by as $k => $d ) {
			if ( ! isset( $fixed[ $k ] ) ) {
				$list[] = $d;
			}
		}
		$list[] = $by['gagne'] ?? array( 'key' => 'gagne', 'label' => $fixed['gagne'] );
		$list[] = $by['perdu'] ?? array( 'key' => 'perdu', 'label' => $fixed['perdu'] );
		$i      = 0;
		foreach ( $list as &$d ) {
			$d['label'] = (string) $d['label'];
			if ( empty( $d['color'] ) ) {
				$d['color'] = self::STAGE_COLORS[ $d['key'] ] ?? self::PALETTE[ $i++ % count( self::PALETTE ) ];
			}
			$d['short'] = self::short( $d['label'] );
		}
		unset( $d );
		self::$defs = $list;
		return $list;
	}

	private static function short( $label ) {
		$map = array( 'Rendez-vous effectué' => 'RDV effectué', 'Rendez-vous planifié' => 'RDV planifié', 'Maquette envoyée' => 'Maquette', 'Soumission envoyée' => 'Soumission', 'Proposition envoyée' => 'Proposition', 'Visite ou estimation' => 'Visite', 'Transaction conclue' => 'Conclue', 'Travaux confirmés' => 'Confirmés', 'Première visite faite' => '1re visite', 'Rencontre effectuée' => 'Rencontre' );
		return $map[ $label ] ?? ( mb_strlen( $label ) > 14 ? mb_substr( $label, 0, 13 ) . '…' : $label );
	}

	public static function template_defs( $tpl ) {
		$t   = self::TEMPLATES[ $tpl ] ?? self::TEMPLATES['general'];
		$out = array();
		foreach ( $t['stages'] as $k => $l ) {
			$out[] = array( 'key' => $k, 'label' => $l, 'color' => self::STAGE_COLORS[ $k ] ?? '' );
		}
		return $out;
	}

	/** Étapes : clé => libellé, dans l'ordre. */
	public static function stages() {
		$out = array();
		foreach ( self::stage_defs() as $d ) {
			$out[ $d['key'] ] = $d['label'];
		}
		return $out;
	}

	public static function has_stage( $key ) {
		return isset( self::stages()[ $key ] );
	}

	/**
	 * Enregistre de nouvelles étapes. Les contacts d'une étape supprimée passent en « Contacté ».
	 *
	 * @param array $defs Liste de array( key, label, color ).
	 */
	public static function save_stages( array $defs ) {
		global $wpdb;
		$clean = array();
		$seen  = array();
		foreach ( $defs as $d ) {
			$label = mb_substr( trim( sanitize_text_field( $d['label'] ?? '' ) ), 0, 40 );
			if ( '' === $label ) {
				continue;
			}
			$key = sanitize_key( $d['key'] ?? '' );
			if ( '' === $key ) {
				$key = substr( sanitize_key( remove_accents( str_replace( ' ', '_', strtolower( $label ) ) ) ), 0, 18 );
			}
			if ( '' === $key || isset( $seen[ $key ] ) ) {
				$key = 'etape' . ( count( $seen ) + 1 );
			}
			$seen[ $key ] = 1;
			$color        = sanitize_hex_color( $d['color'] ?? '' );
			$clean[]      = array( 'key' => $key, 'label' => $label, 'color' => $color ? $color : '' );
		}
		$old = array_keys( self::stages() );
		update_option( 'lmcrm_stages', $clean, false );
		self::$defs = null;
		$new = wp_list_pluck( $clean, 'key' );
		$new = array_merge( $new, array( 'nouveau', 'contacte', 'gagne', 'perdu' ) );
		foreach ( array_diff( $old, $new ) as $gone ) {
			$wpdb->update( self::t( 'contacts' ), array( 'stage' => 'contacte' ), array( 'stage' => $gone ) );
		}
		// Contacts dont l'étape n'existe plus du tout (ancien modèle) : en « Contacté ».
		$in = implode( ',', array_map( function ( $k ) use ( $wpdb ) {
			return $wpdb->prepare( '%s', $k );
		}, array_unique( $new ) ) );
		$wpdb->query( 'UPDATE ' . self::t( 'contacts' ) . " SET stage = 'contacte' WHERE stage NOT IN ($in)" ); // phpcs:ignore
	}

	public static function apply_template( $tpl ) {
		self::save_stages( self::template_defs( $tpl ) );
		update_option( 'lmcrm_template', isset( self::TEMPLATES[ $tpl ] ) ? $tpl : 'general', false );
	}

	const SOURCES = array(
		'rdv'      => 'Rendez-vous',
		'maquette' => 'Demande de maquette',
		'form'     => 'Formulaire du site',
		'meta'     => 'Publicité Meta',
		'google'   => 'Google Ads',
		'zoho'     => 'Import Zoho',
		'manuel'   => 'Saisie manuelle',
	);

	public static function t( $name ) {
		global $wpdb;
		return $wpdb->prefix . 'lmcrm_' . $name;
	}

	public static function activate() {
		self::install();
		if ( ! wp_next_scheduled( 'lmcrm_sync' ) ) {
			wp_schedule_event( time() + 60, 'hourly', 'lmcrm_sync' );
		}
		if ( ! wp_next_scheduled( 'lmcrm_digest' ) ) {
			$tz   = wp_timezone();
			$next = new DateTime( 'tomorrow 07:45', $tz );
			wp_schedule_event( $next->getTimestamp(), 'daily', 'lmcrm_digest' );
		}
		// Reprise de l'historique (rendez-vous, demandes de maquette) en arrière-plan.
		wp_schedule_single_event( time() + 5, 'lmcrm_sync', array( true ) );
	}

	public static function maybe_upgrade() {
		if ( get_option( 'lmcrm_db_version' ) !== LMCRM_DB_VERSION ) {
			self::install();
		}
		if ( '1' !== (string) get_option( 'lmcrm_roles' ) ) {
			// Rôle « Utilisateur CRM » : accès au CRM seulement, pas au reste de WordPress.
			add_role( 'lmcrm_user', 'Utilisateur CRM', array( 'read' => true, 'lmcrm_use' => true ) );
			$admin = get_role( 'administrator' );
			if ( $admin ) {
				$admin->add_cap( 'lmcrm_use' );
			}
			update_option( 'lmcrm_roles', '1', false );
		}
		if ( false === get_option( 'lmcrm_stages' ) ) {
			// Installation antérieure aux étapes modifiables : on garde le pipeline existant.
			global $wpdb;
			$has_maquette = (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . self::t( 'contacts' ) . " WHERE stage = 'maquette'" ); // phpcs:ignore
			if ( $has_maquette || class_exists( 'LMWM_Leads' ) || defined( 'LMWM_VERSION' ) ) {
				self::apply_template( 'agence' );
				update_option( 'lmcrm_setup_done', 1, false );
			}
		}
	}

	public static function install() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$c = $wpdb->get_charset_collate();

		dbDelta( 'CREATE TABLE ' . self::t( 'contacts' ) . " (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			name varchar(190) NOT NULL DEFAULT '',
			company varchar(190) NOT NULL DEFAULT '',
			email varchar(190) NOT NULL DEFAULT '',
			phone varchar(60) NOT NULL DEFAULT '',
			website varchar(255) NOT NULL DEFAULT '',
			city varchar(120) NOT NULL DEFAULT '',
			source varchar(20) NOT NULL DEFAULT 'manuel',
			stage varchar(20) NOT NULL DEFAULT 'nouveau',
			value decimal(10,2) NOT NULL DEFAULT 0,
			notes text NULL,
			ext text NULL,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			last_activity_at datetime NULL,
			first_contact_at datetime NULL,
			kind varchar(40) NOT NULL DEFAULT '',
			owner_id bigint(20) unsigned NOT NULL DEFAULT 0,
			PRIMARY KEY  (id),
			KEY email (email),
			KEY stage (stage),
			KEY last_activity_at (last_activity_at)
		) $c;" );

		dbDelta( 'CREATE TABLE ' . self::t( 'activities' ) . " (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			contact_id bigint(20) unsigned NOT NULL,
			type varchar(20) NOT NULL DEFAULT 'note',
			title varchar(255) NOT NULL DEFAULT '',
			body text NULL,
			ref varchar(100) NULL,
			created_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY contact_id (contact_id),
			UNIQUE KEY ref (ref)
		) $c;" );

		dbDelta( 'CREATE TABLE ' . self::t( 'tasks' ) . " (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			contact_id bigint(20) unsigned NOT NULL DEFAULT 0,
			title varchar(255) NOT NULL DEFAULT '',
			due_at datetime NULL,
			done_at datetime NULL,
			ref varchar(100) NULL,
			created_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY contact_id (contact_id),
			KEY due_at (due_at),
			UNIQUE KEY ref (ref)
		) $c;" );

		update_option( 'lmcrm_db_version', LMCRM_DB_VERSION, false );
	}

	public static function now() {
		return current_time( 'mysql' );
	}

	/* ---------- Contacts ---------- */

	public static function contact( $id ) {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::t( 'contacts' ) . ' WHERE id = %d', $id ), ARRAY_A );
		return $row ?: null;
	}

	public static function contact_by_email( $email ) {
		global $wpdb;
		$email = strtolower( trim( (string) $email ) );
		if ( '' === $email ) {
			return null;
		}
		$row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::t( 'contacts' ) . ' WHERE email = %s ORDER BY id LIMIT 1', $email ), ARRAY_A );
		return $row ?: null;
	}

	private static function clean( array $d ) {
		$out = array();
		foreach ( array( 'name' => 190, 'company' => 190, 'phone' => 60, 'city' => 120 ) as $k => $max ) {
			if ( isset( $d[ $k ] ) ) {
				$out[ $k ] = mb_substr( sanitize_text_field( $d[ $k ] ), 0, $max );
			}
		}
		if ( isset( $d['email'] ) ) {
			$out['email'] = strtolower( sanitize_email( $d['email'] ) );
		}
		if ( isset( $d['website'] ) ) {
			$out['website'] = esc_url_raw( $d['website'] );
		}
		if ( isset( $d['source'] ) && isset( self::SOURCES[ $d['source'] ] ) ) {
			$out['source'] = $d['source'];
		}
		if ( isset( $d['stage'] ) && self::has_stage( $d['stage'] ) ) {
			$out['stage'] = $d['stage'];
		}
		if ( isset( $d['value'] ) ) {
			$out['value'] = round( (float) str_replace( array( ' ', ',' ), array( '', '.' ), (string) $d['value'] ), 2 );
		}
		if ( isset( $d['notes'] ) ) {
			$out['notes'] = sanitize_textarea_field( $d['notes'] );
		}
		if ( isset( $d['kind'] ) ) {
			$out['kind'] = mb_substr( sanitize_text_field( $d['kind'] ), 0, 40 );
		}
		if ( isset( $d['owner_id'] ) ) {
			$out['owner_id'] = max( 0, (int) $d['owner_id'] );
		}
		return $out;
	}

	public static function insert_contact( array $d ) {
		global $wpdb;
		$row = self::clean( $d );
		$row += array( 'source' => 'manuel', 'stage' => 'nouveau' );
		$row['created_at']       = ! empty( $d['created_at'] ) ? $d['created_at'] : self::now();
		$row['updated_at']       = self::now();
		$row['last_activity_at'] = $row['created_at'];
		$wpdb->insert( self::t( 'contacts' ), $row );
		return (int) $wpdb->insert_id;
	}

	public static function update_contact( $id, array $d ) {
		global $wpdb;
		$row = self::clean( $d );
		if ( ! $row ) {
			return;
		}
		$row['updated_at'] = self::now();
		$wpdb->update( self::t( 'contacts' ), $row, array( 'id' => (int) $id ) );
	}

	/**
	 * Crée ou complète un contact (dédoublonné par courriel).
	 * Ne remplace jamais une valeur déjà saisie, ne recule jamais dans le pipeline.
	 *
	 * @return array [id, created]
	 */
	public static function upsert_contact( array $d ) {
		$existing = self::contact_by_email( isset( $d['email'] ) ? $d['email'] : '' );
		if ( ! $existing ) {
			return array( self::insert_contact( $d ), true );
		}
		$patch = array();
		foreach ( array( 'name', 'company', 'phone', 'website', 'city', 'kind' ) as $k ) {
			if ( '' === (string) $existing[ $k ] && ! empty( $d[ $k ] ) ) {
				$patch[ $k ] = $d[ $k ];
			}
		}
		if ( ! empty( $d['stage'] ) && self::stage_rank( $d['stage'] ) > self::stage_rank( $existing['stage'] ) ) {
			$patch['stage'] = $d['stage'];
		}
		if ( $patch ) {
			self::update_contact( $existing['id'], $patch );
		}
		return array( (int) $existing['id'], false );
	}

	public static function stage_rank( $stage ) {
		if ( 'perdu' === $stage ) {
			return -1;
		}
		$i = array_search( $stage, array_keys( self::stages() ), true );
		return false === $i ? 0 : (int) $i;
	}

	public static function set_stage( $id, $stage, $log = true ) {
		$c = self::contact( $id );
		if ( ! $c || ! self::has_stage( $stage ) || $c['stage'] === $stage ) {
			return false;
		}
		self::update_contact( $id, array( 'stage' => $stage ) );
		if ( 'nouveau' === $c['stage'] && 'nouveau' !== $stage ) {
			self::mark_contacted( $id );
		}
		if ( $log ) {
			self::add_activity( $id, 'stage', 'Étape : ' . ( self::stages()[ $c['stage'] ] ?? $c['stage'] ) . ' → ' . self::stages()[ $stage ] );
		}
		return true;
	}

	/** Premier contact sortant (sert au temps de réponse). */
	public static function mark_contacted( $id ) {
		global $wpdb;
		$wpdb->query( $wpdb->prepare( 'UPDATE ' . self::t( 'contacts' ) . ' SET first_contact_at = %s WHERE id = %d AND first_contact_at IS NULL', self::now(), $id ) );
	}

	public static function delete_contact( $id ) {
		global $wpdb;
		$id = (int) $id;
		$wpdb->delete( self::t( 'activities' ), array( 'contact_id' => $id ) );
		$wpdb->delete( self::t( 'tasks' ), array( 'contact_id' => $id ) );
		$wpdb->delete( self::t( 'contacts' ), array( 'id' => $id ) );
	}

	public static function contacts( array $args = array() ) {
		global $wpdb;
		$args  = wp_parse_args( $args, array( 's' => '', 'stage' => '', 'source' => '', 'limit' => 50, 'offset' => 0, 'orderby' => 'last_activity_at' ) );
		$where = array( '1=1' );
		$vals  = array();
		if ( '' !== $args['s'] ) {
			$like    = '%' . $wpdb->esc_like( $args['s'] ) . '%';
			$where[] = '(name LIKE %s OR company LIKE %s OR email LIKE %s OR phone LIKE %s OR city LIKE %s)';
			array_push( $vals, $like, $like, $like, $like, $like );
		}
		if ( '' !== $args['stage'] && self::has_stage( $args['stage'] ) ) {
			$where[] = 'stage = %s';
			$vals[]  = $args['stage'];
		}
		if ( '' !== $args['source'] && isset( self::SOURCES[ $args['source'] ] ) ) {
			$where[] = 'source = %s';
			$vals[]  = $args['source'];
		}
		$order = in_array( $args['orderby'], array( 'name', 'created_at', 'last_activity_at', 'value' ), true ) ? $args['orderby'] : 'last_activity_at';
		$dir   = 'name' === $order ? 'ASC' : 'DESC';
		$sql   = 'SELECT SQL_CALC_FOUND_ROWS * FROM ' . self::t( 'contacts' ) . ' WHERE ' . implode( ' AND ', $where )
			. " ORDER BY $order $dir, id DESC LIMIT %d OFFSET %d";
		$vals[] = (int) $args['limit'];
		$vals[] = (int) $args['offset'];
		$rows   = $wpdb->get_results( $wpdb->prepare( $sql, $vals ), ARRAY_A );
		$total  = (int) $wpdb->get_var( 'SELECT FOUND_ROWS()' );
		return array( $rows, $total );
	}

	public static function stage_counts() {
		global $wpdb;
		$rows = $wpdb->get_results( 'SELECT stage, COUNT(*) n, SUM(value) v FROM ' . self::t( 'contacts' ) . ' GROUP BY stage', ARRAY_A );
		$out  = array();
		foreach ( self::stages() as $k => $l ) {
			$out[ $k ] = array( 'n' => 0, 'v' => 0 );
		}
		foreach ( $rows as $r ) {
			$out[ $r['stage'] ] = array( 'n' => (int) $r['n'], 'v' => (float) $r['v'] );
		}
		return $out;
	}

	/* ---------- Activités ---------- */

	/**
	 * Ajoute une activité. $ref (unique) empêche les doublons lors des reprises.
	 *
	 * @return int|false ID, ou false si la référence existe déjà.
	 */
	public static function add_activity( $contact_id, $type, $title, $body = '', $ref = null, $when = null ) {
		global $wpdb;
		if ( $ref && self::activity_exists( $ref ) ) {
			return false;
		}
		$when = $when ?: self::now();
		$ok   = $wpdb->insert( self::t( 'activities' ), array(
			'contact_id' => (int) $contact_id,
			'type'       => sanitize_key( $type ),
			'title'      => mb_substr( wp_strip_all_tags( $title ), 0, 255 ),
			'body'       => sanitize_textarea_field( $body ),
			'ref'        => $ref,
			'created_at' => $when,
		) );
		if ( ! $ok ) {
			return false;
		}
		$wpdb->query( $wpdb->prepare(
			'UPDATE ' . self::t( 'contacts' ) . ' SET last_activity_at = GREATEST(COALESCE(last_activity_at, %s), %s) WHERE id = %d',
			$when, $when, $contact_id
		) );
		return (int) $wpdb->insert_id;
	}

	public static function activity_exists( $ref ) {
		global $wpdb;
		return (bool) $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . self::t( 'activities' ) . ' WHERE ref = %s', $ref ) );
	}

	public static function activities( $contact_id ) {
		global $wpdb;
		return $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . self::t( 'activities' ) . ' WHERE contact_id = %d ORDER BY created_at DESC, id DESC LIMIT 200', $contact_id ), ARRAY_A );
	}

	public static function delete_activity( $id ) {
		global $wpdb;
		$wpdb->delete( self::t( 'activities' ), array( 'id' => (int) $id, 'type' => 'note' ) );
	}

	/* ---------- Tâches ---------- */

	public static function add_task( $contact_id, $title, $due, $ref = null ) {
		global $wpdb;
		if ( $ref && $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . self::t( 'tasks' ) . ' WHERE ref = %s', $ref ) ) ) {
			return false;
		}
		$ok = $wpdb->insert( self::t( 'tasks' ), array(
			'contact_id' => (int) $contact_id,
			'title'      => mb_substr( sanitize_text_field( $title ), 0, 255 ),
			'due_at'     => $due ?: null,
			'ref'        => $ref,
			'created_at' => self::now(),
		) );
		return $ok ? (int) $wpdb->insert_id : false;
	}

	public static function task( $id ) {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::t( 'tasks' ) . ' WHERE id = %d', $id ), ARRAY_A );
	}

	public static function complete_task( $id ) {
		global $wpdb;
		$t = self::task( $id );
		if ( ! $t || $t['done_at'] ) {
			return;
		}
		$wpdb->update( self::t( 'tasks' ), array( 'done_at' => self::now() ), array( 'id' => (int) $id ) );
		if ( $t['contact_id'] ) {
			self::add_activity( $t['contact_id'], 'task', 'Tâche faite : ' . $t['title'] );
		}
	}

	public static function reopen_task( $id ) {
		global $wpdb;
		$t = self::task( $id );
		if ( ! $t || ! $t['done_at'] ) {
			return;
		}
		$wpdb->update( self::t( 'tasks' ), array( 'done_at' => null ), array( 'id' => (int) $id ) );
		if ( $t['contact_id'] ) {
			$wpdb->query( $wpdb->prepare(
				'DELETE FROM ' . self::t( 'activities' ) . " WHERE contact_id = %d AND type = 'task' AND title = %s ORDER BY id DESC LIMIT 1",
				$t['contact_id'], mb_substr( 'Tâche faite : ' . $t['title'], 0, 255 )
			) );
		}
	}

	public static function delete_task( $id ) {
		global $wpdb;
		$wpdb->delete( self::t( 'tasks' ), array( 'id' => (int) $id ) );
	}

	public static function tasks_for( $contact_id ) {
		global $wpdb;
		return $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . self::t( 'tasks' ) . ' WHERE contact_id = %d ORDER BY done_at IS NOT NULL, due_at IS NULL, due_at, id', $contact_id ), ARRAY_A );
	}

	/** Tâches ouvertes échues avant $until (inclus), avec le contact. */
	public static function open_tasks( $until = null, $limit = 100 ) {
		global $wpdb;
		$until = $until ?: wp_date( 'Y-m-d 23:59:59' );
		return $wpdb->get_results( $wpdb->prepare(
			'SELECT t.*, c.name, c.company, c.email, c.phone, c.stage FROM ' . self::t( 'tasks' ) . ' t LEFT JOIN ' . self::t( 'contacts' ) . ' c ON c.id = t.contact_id
			 WHERE t.done_at IS NULL AND t.due_at IS NOT NULL AND t.due_at <= %s ORDER BY t.due_at LIMIT %d',
			$until, $limit
		), ARRAY_A );
	}

	public static function upcoming_tasks( $days = 7 ) {
		global $wpdb;
		return $wpdb->get_results( $wpdb->prepare(
			'SELECT t.*, c.name, c.company FROM ' . self::t( 'tasks' ) . ' t LEFT JOIN ' . self::t( 'contacts' ) . ' c ON c.id = t.contact_id
			 WHERE t.done_at IS NULL AND t.due_at > %s AND t.due_at <= %s ORDER BY t.due_at LIMIT 50',
			wp_date( 'Y-m-d 23:59:59' ), wp_date( 'Y-m-d 23:59:59', time() + $days * DAY_IN_SECONDS )
		), ARRAY_A );
	}

	/** Date d'échéance en jours ouvrables (lundi à vendredi), à 9 h. */
	public static function business_due( $days ) {
		$d = new DateTime( 'now', wp_timezone() );
		$n = 0;
		while ( $n < $days ) {
			$d->modify( '+1 day' );
			if ( (int) $d->format( 'N' ) <= 5 ) {
				$n++;
			}
		}
		return $d->format( 'Y-m-d 09:00:00' );
	}

	public static function label( $contact ) {
		$n = trim( (string) ( $contact['name'] ?? '' ) );
		$c = trim( (string) ( $contact['company'] ?? '' ) );
		if ( $n && $c && strcasecmp( $n, $c ) ) {
			return $n . ' (' . $c . ')';
		}
		return $n ?: ( $c ?: ( ! empty( $contact['email'] ) ? $contact['email'] : 'Contact n° ' . ( $contact['id'] ?? '' ) ) );
	}
}

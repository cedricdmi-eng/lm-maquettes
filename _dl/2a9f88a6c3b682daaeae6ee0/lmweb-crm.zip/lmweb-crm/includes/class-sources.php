<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Sources qui alimentent le CRM :
 * - LM Web Rendez-vous (accroches lmrdv_* + rattrapage horaire) ;
 * - LM Web Demandes de maquette (accroche lmwm_lead_created + rattrapage) ;
 * - formulaire natif (voir LMCRM_Form) ;
 * - boîte de dépôt : fichiers d'import (prospects Meta, Zoho...) déposés dans inbox/.
 * Chaque événement porte une référence unique : les reprises ne créent jamais de doublon.
 */
class LMCRM_Sources {

	public static function init() {
		add_action( 'lmrdv_booking_created', array( __CLASS__, 'on_booking_created' ), 10, 1 );
		add_action( 'lmrdv_booking_rescheduled', array( __CLASS__, 'on_booking_rescheduled' ), 10, 2 );
		add_action( 'lmrdv_booking_cancelled', array( __CLASS__, 'on_booking_cancelled' ), 10, 1 );
		add_action( 'lmwm_lead_created', array( __CLASS__, 'on_maquette' ), 10, 1 );
		add_action( 'lmcrm_sync', array( __CLASS__, 'sync' ), 10, 1 );
		add_action( 'lmcrm_digest', array( __CLASS__, 'digest' ) );
		// Boîte de dépôt vidée à chaque passage de wp-cron (en arrière-plan, jamais sur une page vue).
		add_action( 'wp_loaded', function () {
			if ( wp_doing_cron() ) {
				LMCRM_Sources::process_inbox();
			}
		} );
	}

	/** Comptes techniques de l'agence sur un site client : jamais proposés comme responsables d'un prospect. */
	public static function is_internal_team( $email ) {
		if ( false !== strpos( (string) wp_parse_url( home_url(), PHP_URL_HOST ), 'lm-web.ca' ) ) {
			return false;
		}
		$email = strtolower( (string) $email );
		return (bool) preg_match( '/@lm-web\.ca$/', $email ) || 'cedricdmi@gmail.com' === $email;
	}

	/** Adresse d'un administrateur du site : réservation ou demande de test, ignorée. */
	public static function is_internal( $email ) {
		$u = get_user_by( 'email', (string) $email );
		return $u && user_can( $u, 'manage_options' );
	}

	/* ---------- Rendez-vous ---------- */

	private static function booking( $id ) {
		if ( class_exists( 'LMRDV_Bookings' ) ) {
			return LMRDV_Bookings::get( $id );
		}
		return null;
	}

	private static function type_name( $type_id ) {
		if ( class_exists( 'LMRDV_Settings' ) && method_exists( 'LMRDV_Settings', 'type' ) ) {
			$t = LMRDV_Settings::type( $type_id );
			if ( $t && ! empty( $t['name'] ) ) {
				return $t['name'];
			}
		}
		return 'Rendez-vous';
	}

	private static function when( $ts ) {
		return wp_date( 'l j F Y à G \h i', (int) $ts );
	}

	public static function on_booking_created( $b ) {
		if ( is_numeric( $b ) ) {
			$b = self::booking( $b );
		}
		if ( ! is_array( $b ) || empty( $b['email'] ) || self::is_internal( $b['email'] ) ) {
			return;
		}
		$post  = get_post( $b['id'] );
		// Étape à la réservation : « Maquette envoyée » pour une présentation (LM Web),
		// « Rendez-vous planifié » ou « Visite » si le pipeline les a, sinon « Nouveau ».
		$stage = array();
		if ( LMCRM_DB::has_stage( 'maquette' ) ) {
			$stage['presentation'] = 'maquette';
		}
		$booked = LMCRM_DB::has_stage( 'planifie' ) ? 'planifie' : ( LMCRM_DB::has_stage( 'visite' ) ? 'visite' : 'nouveau' );
		list( $cid ) = LMCRM_DB::upsert_contact( array(
			'name'       => $b['name'],
			'email'      => $b['email'],
			'phone'      => $b['phone'],
			'source'     => 'rdv',
			'stage'      => isset( $stage[ $b['type'] ] ) ? $stage[ $b['type'] ] : $booked,
			'created_at' => $post ? $post->post_date : null,
		) );
		$name = self::type_name( $b['type'] );
		$body = trim( ( $b['notes'] ? "Message : {$b['notes']}\n" : '' ) . ( $b['meet'] ? "Meet : {$b['meet']}" : '' ) );
		LMCRM_DB::add_activity( $cid, 'rdv', $name . ' réservé pour le ' . self::when( $b['start'] ), $body, 'rdv:' . $b['id'] . ':created', $post ? $post->post_date : null );

		// Relance : faire le suivi le lendemain ouvrable du rendez-vous.
		$after = new DateTime( '@' . (int) $b['end'] );
		$after->setTimezone( wp_timezone() );
		do {
			$after->modify( '+1 day' );
		} while ( (int) $after->format( 'N' ) > 5 );
		if ( (int) $b['end'] > time() ) {
			LMCRM_DB::add_task( $cid, 'Suivi après : ' . $name, $after->format( 'Y-m-d 09:00:00' ), 'task:rdv:' . $b['id'] );
		}
		if ( $post && strtotime( $post->post_date_gmt . ' UTC' ) > time() - HOUR_IN_SECONDS ) {
			LMCRM_Notify::lead( $cid, '', '', array(), $name . ' réservé le ' . wp_date( 'j M à G \\h i', (int) $b['start'] ) );
		}
	}

	public static function on_booking_rescheduled( $b, $old_start = 0 ) {
		if ( ! is_array( $b ) || empty( $b['email'] ) ) {
			return;
		}
		$c = LMCRM_DB::contact_by_email( $b['email'] );
		if ( ! $c ) {
			self::on_booking_created( $b );
			return;
		}
		LMCRM_DB::add_activity( $c['id'], 'rdv', self::type_name( $b['type'] ) . ' déplacé au ' . self::when( $b['start'] ) . ( $old_start ? ' (au lieu du ' . self::when( $old_start ) . ')' : '' ) );
		global $wpdb;
		$after = new DateTime( '@' . (int) $b['end'] );
		$after->setTimezone( wp_timezone() );
		do {
			$after->modify( '+1 day' );
		} while ( (int) $after->format( 'N' ) > 5 );
		$wpdb->update( LMCRM_DB::t( 'tasks' ), array( 'due_at' => $after->format( 'Y-m-d 09:00:00' ) ), array( 'ref' => 'task:rdv:' . $b['id'] ) );
	}

	public static function on_booking_cancelled( $b ) {
		if ( ! is_array( $b ) || empty( $b['email'] ) ) {
			return;
		}
		$c = LMCRM_DB::contact_by_email( $b['email'] );
		if ( ! $c ) {
			return;
		}
		LMCRM_DB::add_activity( $c['id'], 'rdv', self::type_name( $b['type'] ) . ' du ' . self::when( $b['start'] ) . ' annulé', '', 'rdv:' . $b['id'] . ':cancelled' );
		global $wpdb;
		$wpdb->query( $wpdb->prepare( 'DELETE FROM ' . LMCRM_DB::t( 'tasks' ) . ' WHERE ref = %s AND done_at IS NULL', 'task:rdv:' . $b['id'] ) );
		LMCRM_DB::add_task( $c['id'], 'Rendez-vous annulé : relancer pour en fixer un autre', LMCRM_DB::business_due( 1 ), 'task:rdv-cancel:' . $b['id'] );
	}

	/**
	 * Rendez-vous passés (non annulés) : le contact passe en « Rendez-vous effectué »
	 * s'il en était encore à Nouveau ou Contacté. Une seule fois par rendez-vous.
	 */
	public static function meetings_done( $days = 30 ) {
		if ( ! class_exists( 'LMRDV_Bookings' ) || ! method_exists( 'LMRDV_Bookings', 'confirmed_between' ) ) {
			return 0;
		}
		$n   = 0;
		$now = time();
		foreach ( (array) LMRDV_Bookings::confirmed_between( $now - $days * DAY_IN_SECONDS, $now ) as $b ) {
			if ( ! $b || empty( $b['email'] ) || (int) $b['end'] > $now || self::is_internal( $b['email'] ) ) {
				continue;
			}
			$ref = 'rdv:' . $b['id'] . ':done';
			if ( LMCRM_DB::activity_exists( $ref ) ) {
				continue;
			}
			$c = LMCRM_DB::contact_by_email( $b['email'] );
			if ( ! $c ) {
				continue;
			}
			LMCRM_DB::add_activity( $c['id'], 'rdv', self::type_name( $b['type'] ) . ' effectué', '', $ref, wp_date( 'Y-m-d H:i:s', (int) $b['end'] ) );
			if ( LMCRM_DB::has_stage( 'rencontre' ) && LMCRM_DB::stage_rank( $c['stage'] ) >= 0 && LMCRM_DB::stage_rank( $c['stage'] ) < LMCRM_DB::stage_rank( 'rencontre' ) ) {
				LMCRM_DB::set_stage( $c['id'], 'rencontre' );
			}
			$n++;
		}
		return $n;
	}

	/* ---------- Demandes de maquette ---------- */

	public static function on_maquette( $id ) {
		$p = get_post( $id );
		if ( ! $p || 'lm_lead' !== $p->post_type ) {
			return;
		}
		$m = function ( $k ) use ( $id ) {
			return (string) get_post_meta( $id, 'lead_' . $k, true );
		};
		if ( '' === $m( 'email' ) || self::is_internal( $m( 'email' ) ) ) {
			return;
		}
		list( $cid ) = LMCRM_DB::upsert_contact( array(
			'name'       => $m( 'name' ),
			'company'    => $m( 'business' ),
			'email'      => $m( 'email' ),
			'phone'      => $m( 'phone' ),
			'website'    => $m( 'url' ),
			'city'       => $m( 'city' ),
			'source'     => 'maquette',
			'stage'      => 'nouveau',
			'created_at' => $p->post_date,
		) );
		$ad   = preg_match( '/utm_content=([^&]+)/', $m( 'utm' ), $mm ) ? urldecode( $mm[1] ) : '';
		$body = implode( "\n", array_filter( array(
			'Type : ' . ( 'nosite' === $m( 'type' ) ? 'Nouveau site' : 'Refonte' ),
			$m( 'url' ) ? 'Site actuel : ' . $m( 'url' ) : '',
			'Secteur : ' . $m( 'sector' ) . ( $m( 'activity' ) ? ' (' . $m( 'activity' ) . ')' : '' ),
			$m( 'priority' ) ? 'Priorité : ' . $m( 'priority' ) : '',
			$ad ? 'Publicité : ' . $ad : '',
			'Fiche : ' . admin_url( 'post.php?post=' . $id . '&action=edit' ),
		) ) );
		LMCRM_DB::add_activity( $cid, 'maquette', 'Demande de maquette gratuite', $body, 'maquette:' . $id, $p->post_date );
		// Promesse affichée au prospect : maquette sous 48 heures ouvrables.
		$due = ( strtotime( $p->post_date ) > time() - DAY_IN_SECONDS ) ? LMCRM_DB::business_due( 2 ) : wp_date( 'Y-m-d 09:00:00' );
		LMCRM_DB::add_task( $cid, 'Préparer et envoyer la maquette', $due, 'task:maquette:' . $id );
		if ( strtotime( $p->post_date_gmt . ' UTC' ) > time() - HOUR_IN_SECONDS ) {
			LMCRM_Notify::lead( $cid, '', '', array(), 'Demande de maquette' );
		}
	}

	/* ---------- Rattrapage et boîte de dépôt ---------- */

	/**
	 * Reprend les rendez-vous et demandes récents (ou tous si $full), puis traite la boîte de dépôt.
	 */
	public static function sync( $full = false ) {
		$since = $full ? '2000-01-01 00:00:00' : wp_date( 'Y-m-d H:i:s', time() - 3 * DAY_IN_SECONDS );

		$leads = get_posts( array(
			'post_type'      => 'lm_lead',
			'post_status'    => 'any',
			'posts_per_page' => 500,
			'fields'         => 'ids',
			'orderby'        => 'date',
			'order'          => 'ASC',
			'date_query'     => array( array( 'after' => $since, 'inclusive' => true ) ),
		) );
		foreach ( $leads as $id ) {
			if ( ! LMCRM_DB::activity_exists( 'maquette:' . $id ) ) {
				self::on_maquette( $id );
			}
		}

		if ( class_exists( 'LMRDV_Bookings' ) ) {
			$bookings = get_posts( array(
				'post_type'      => 'lmrdv_booking',
				'post_status'    => 'any',
				'posts_per_page' => 500,
				'fields'         => 'ids',
				'orderby'        => 'date',
				'order'          => 'ASC',
				'date_query'     => array( array( 'column' => 'post_modified', 'after' => $since, 'inclusive' => true ) ),
			) );
			foreach ( $bookings as $id ) {
				$b = self::booking( $id );
				if ( ! $b ) {
					continue;
				}
				if ( ! LMCRM_DB::activity_exists( 'rdv:' . $id . ':created' ) ) {
					self::on_booking_created( $b );
				}
				if ( 'cancelled' === $b['status'] && ! LMCRM_DB::activity_exists( 'rdv:' . $id . ':cancelled' ) ) {
					self::on_booking_cancelled( $b );
				}
			}
		}

		self::meetings_done();
		self::process_inbox();
		update_option( 'lmcrm_last_sync', LMCRM_DB::now(), false );
	}

	public static function inbox_dir() {
		return LMCRM_DIR . '/inbox';
	}

	/**
	 * Fichiers d'import : inbox/*.php, commençant par « <?php exit; ?> » suivi d'un JSON
	 * { "contacts": [ { name, company, email, phone, website, city, source, stage, value, notes,
	 *   created_at, activities: [ { type, title, body, ref, created_at } ], tasks: [ { title, due_at, ref } ] } ] }.
	 * Le fichier est supprimé une fois traité ; le bilan est gardé dans l'option lmcrm_inbox_log.
	 */
	public static function process_inbox() {
		$dir = self::inbox_dir();
		if ( ! is_dir( $dir ) ) {
			return;
		}
		$files = glob( $dir . '/*.php' );
		if ( ! $files ) {
			return;
		}
		$log = get_option( 'lmcrm_inbox_log', array() );
		foreach ( $files as $f ) {
			if ( 'index.php' === basename( $f ) ) {
				continue;
			}
			$raw  = (string) file_get_contents( $f );
			$raw  = preg_replace( '/^<\?php\s+exit;?\s*\?>\s*/', '', $raw );
			$data = json_decode( $raw, true );
			$res  = array( 'file' => basename( $f ), 't' => LMCRM_DB::now(), 'created' => 0, 'updated' => 0, 'errors' => 0 );
			if ( ! is_array( $data ) || empty( $data['contacts'] ) || ! is_array( $data['contacts'] ) ) {
				$res['errors'] = 1;
				$res['msg']    = 'JSON illisible';
			} else {
				foreach ( $data['contacts'] as $c ) {
					if ( ! is_array( $c ) || ( empty( $c['email'] ) && empty( $c['name'] ) && empty( $c['company'] ) ) ) {
						$res['errors']++;
						continue;
					}
					if ( ! empty( $c['email'] ) ) {
						list( $cid, $created ) = LMCRM_DB::upsert_contact( $c );
					} else {
						$cid     = LMCRM_DB::insert_contact( $c );
						$created = true;
					}
					$res[ $created ? 'created' : 'updated' ]++;
					if ( ! $created && ! empty( $c['notes'] ) ) {
						$cur = LMCRM_DB::contact( $cid );
						if ( '' === (string) $cur['notes'] ) {
							LMCRM_DB::update_contact( $cid, array( 'notes' => $c['notes'] ) );
						}
					}
					if ( ! $created && ! empty( $c['value'] ) ) {
						$cur = LMCRM_DB::contact( $cid );
						if ( 0.0 === (float) $cur['value'] ) {
							LMCRM_DB::update_contact( $cid, array( 'value' => $c['value'] ) );
						}
					}
					foreach ( (array) ( $c['activities'] ?? array() ) as $a ) {
						LMCRM_DB::add_activity( $cid, $a['type'] ?? 'note', $a['title'] ?? '', $a['body'] ?? '', $a['ref'] ?? null, $a['created_at'] ?? null );
					}
					foreach ( (array) ( $c['tasks'] ?? array() ) as $t ) {
						LMCRM_DB::add_task( $cid, $t['title'] ?? 'Relance', $t['due_at'] ?? null, $t['ref'] ?? null );
					}
				}
			}
			wp_delete_file( $f );
			array_unshift( $log, $res );
		}
		update_option( 'lmcrm_inbox_log', array_slice( $log, 0, 20 ), false );
	}

	/* ---------- Résumé quotidien ---------- */

	public static function notify_email() {
		$e = get_option( 'lmcrm_notify' );
		return is_email( $e ) ? $e : get_option( 'admin_email' );
	}

	public static function digest() {
		if ( ! get_option( 'lmcrm_digest_on', 1 ) ) {
			return;
		}
		$tasks = LMCRM_DB::open_tasks();
		if ( ! $tasks ) {
			return;
		}
		$today = wp_date( 'Y-m-d' );
		$rows  = '';
		foreach ( $tasks as $t ) {
			$late  = substr( $t['due_at'], 0, 10 ) < $today;
			$who   = $t['contact_id'] ? LMCRM_DB::label( $t ) : '';
			$link  = $t['contact_id'] ? admin_url( 'admin.php?page=lmcrm&contact=' . $t['contact_id'] ) : admin_url( 'admin.php?page=lmcrm' );
			$rows .= '<tr><td style="padding:8px 12px;border-bottom:1px solid #eee;color:' . ( $late ? '#c0392b' : '#555' ) . ';white-space:nowrap">'
				. esc_html( $late ? 'En retard (' . wp_date( 'j M', strtotime( $t['due_at'] ) ) . ')' : 'Aujourd’hui' ) . '</td>'
				. '<td style="padding:8px 12px;border-bottom:1px solid #eee"><a href="' . esc_url( $link ) . '" style="color:#0C1B40;font-weight:600;text-decoration:none">' . esc_html( $t['title'] ) . '</a>'
				. ( $who ? '<br><span style="color:#777;font-size:13px">' . esc_html( $who ) . ( $t['phone'] ? ' · ' . esc_html( $t['phone'] ) : '' ) . '</span>' : '' ) . '</td></tr>';
		}
		$html = '<div style="font-family:Arial,Helvetica,sans-serif;font-size:15px;color:#1a1a1a;max-width:640px">'
			. '<p style="margin:0 0 14px">Bonjour,</p><p style="margin:0 0 14px">Voici vos relances du jour (' . count( $tasks ) . ').</p>'
			. '<table style="border-collapse:collapse;width:100%">' . $rows . '</table>'
			. '<p style="margin:18px 0 0"><a href="' . esc_url( admin_url( 'admin.php?page=lmcrm' ) ) . '" style="display:inline-block;background:#FF7020;color:#fff;text-decoration:none;font-weight:bold;padding:10px 18px;border-radius:8px">Ouvrir le CRM</a></p></div>';
		wp_mail( self::notify_email(), 'CRM : ' . count( $tasks ) . ' relance' . ( count( $tasks ) > 1 ? 's' : '' ) . ' aujourd’hui', $html, array( 'Content-Type: text/html; charset=UTF-8' ) );
	}
}

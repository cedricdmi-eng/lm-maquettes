<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Prospects des formulaires instantanés Meta (Lead Ads).
 * Le site interroge l'API Graph toutes les 15 minutes, en arrière-plan (wp-cron),
 * avec un jeton d'utilisateur système du Business Manager. Aucun webhook, aucun service tiers.
 * Premier passage : l'historique arrive en « Contacté », sans tâche. Ensuite : « Nouveau » + relance.
 */
class LMCRM_Meta {

	const API  = 'https://graph.facebook.com/v21.0/';
	const HOOK = 'lmcrm_meta_sync';

	public static function init() {
		add_filter( 'cron_schedules', function ( $s ) {
			$s['lmcrm_15min'] = array( 'interval' => 15 * MINUTE_IN_SECONDS, 'display' => 'Toutes les 15 minutes (CRM)' );
			return $s;
		} );
		add_action( self::HOOK, array( __CLASS__, 'sync' ) );
	}

	/** Clé de chiffrement tirée des clés secrètes de wp-config.php (jamais stockée en base). */
	private static function key() {
		return hash( 'sha256', ( defined( 'AUTH_KEY' ) ? AUTH_KEY : '' ) . ( defined( 'SECURE_AUTH_SALT' ) ? SECURE_AUTH_SALT : '' ) . 'lmcrm-meta', true );
	}

	/** Enregistre le jeton chiffré (AES-256-GCM). */
	public static function save_token( $plain ) {
		$plain = trim( (string) $plain );
		if ( '' === $plain ) {
			return;
		}
		if ( function_exists( 'openssl_encrypt' ) ) {
			$iv  = random_bytes( 12 );
			$tag = '';
			$ct  = openssl_encrypt( $plain, 'aes-256-gcm', self::key(), OPENSSL_RAW_DATA, $iv, $tag );
			if ( false !== $ct ) {
				update_option( 'lmcrm_meta_token', 'enc1:' . base64_encode( $iv . $tag . $ct ), false );
				return;
			}
		}
		update_option( 'lmcrm_meta_token', $plain, false );
	}

	public static function token() {
		$v = (string) get_option( 'lmcrm_meta_token', '' );
		if ( 0 !== strpos( $v, 'enc1:' ) ) {
			return $v;
		}
		$raw = base64_decode( substr( $v, 5 ), true );
		if ( false === $raw || strlen( $raw ) < 29 || ! function_exists( 'openssl_decrypt' ) ) {
			return '';
		}
		$plain = openssl_decrypt( substr( $raw, 28 ), 'aes-256-gcm', self::key(), OPENSSL_RAW_DATA, substr( $raw, 0, 12 ), substr( $raw, 12, 16 ) );
		return false === $plain ? '' : $plain;
	}

	public static function page() {
		return preg_replace( '/\D/', '', (string) get_option( 'lmcrm_meta_page', '' ) );
	}

	public static function ready() {
		return '' !== self::token() && '' !== self::page();
	}

	public static function schedule() {
		if ( self::ready() ) {
			if ( ! wp_next_scheduled( self::HOOK ) ) {
				wp_schedule_event( time() + 30, 'lmcrm_15min', self::HOOK );
			}
		} else {
			wp_clear_scheduled_hook( self::HOOK );
		}
	}

	private static function get( $path, array $args, $token ) {
		$args['access_token'] = $token;
		$url                  = ( 0 === strpos( $path, 'https://' ) ) ? $path : self::API . ltrim( $path, '/' ) . '?' . http_build_query( $args );
		$r                    = wp_remote_get( $url, array( 'timeout' => 15 ) );
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		$j = json_decode( wp_remote_retrieve_body( $r ), true );
		if ( ! is_array( $j ) ) {
			return new WP_Error( 'lmcrm_meta', 'Réponse illisible de Meta' );
		}
		if ( ! empty( $j['error'] ) ) {
			return new WP_Error( 'lmcrm_meta', $j['error']['message'] ?? 'Erreur Meta' );
		}
		return $j;
	}

	/** Jeton de Page, obtenu à partir du jeton d'utilisateur système (en cache 1 h). */
	private static function page_token() {
		$hit = get_transient( 'lmcrm_meta_pt' );
		if ( $hit ) {
			return $hit;
		}
		$r = self::get( self::page(), array( 'fields' => 'access_token,name' ), self::token() );
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		if ( empty( $r['access_token'] ) ) {
			return new WP_Error( 'lmcrm_meta', 'Le jeton n’a pas accès à cette Page (droit « Prospects » requis).' );
		}
		update_option( 'lmcrm_meta_page_name', sanitize_text_field( $r['name'] ?? '' ), false );
		set_transient( 'lmcrm_meta_pt', $r['access_token'], HOUR_IN_SECONDS );
		return $r['access_token'];
	}

	private static function status( $ok, $msg ) {
		update_option( 'lmcrm_meta_status', array( 't' => LMCRM_DB::now(), 'ok' => $ok, 'msg' => $msg ), false );
	}

	/**
	 * Relève les prospects de tous les formulaires de la Page depuis le dernier passage.
	 *
	 * @return array|WP_Error Bilan.
	 */
	public static function sync() {
		if ( ! self::ready() ) {
			return new WP_Error( 'lmcrm_meta', 'Jeton ou Page manquant.' );
		}
		if ( get_transient( 'lmcrm_meta_lock' ) ) {
			return array( 'skipped' => true );
		}
		set_transient( 'lmcrm_meta_lock', 1, 5 * MINUTE_IN_SECONDS );

		$pt = self::page_token();
		if ( is_wp_error( $pt ) ) {
			delete_transient( 'lmcrm_meta_lock' );
			self::status( false, $pt->get_error_message() );
			return $pt;
		}
		$since   = (int) get_option( 'lmcrm_meta_since', 0 );
		$first   = 0 === $since;
		$started = time();
		$res     = array( 'forms' => 0, 'leads' => 0, 'created' => 0, 'first' => $first );

		$forms = self::get( self::page() . '/leadgen_forms', array( 'fields' => 'id,name', 'limit' => 100 ), $pt );
		if ( is_wp_error( $forms ) ) {
			delete_transient( 'lmcrm_meta_lock' );
			self::status( false, $forms->get_error_message() );
			return $forms;
		}
		foreach ( (array) ( $forms['data'] ?? array() ) as $f ) {
			$res['forms']++;
			$args = array( 'fields' => 'id,created_time,field_data,ad_name,campaign_name,platform', 'limit' => 100 );
			if ( $since ) {
				// Marge de 10 minutes : la référence unique évite tout doublon.
				$args['filtering'] = wp_json_encode( array( array( 'field' => 'time_created', 'operator' => 'GREATER_THAN', 'value' => $since - 600 ) ) );
			}
			$page = self::get( $f['id'] . '/leads', $args, $pt );
			$guard = 0;
			while ( ! is_wp_error( $page ) && $guard++ < 20 ) {
				foreach ( (array) ( $page['data'] ?? array() ) as $lead ) {
					$res['leads']++;
					if ( self::import_lead( $lead, (string) ( $f['name'] ?? '' ), $first ) ) {
						$res['created']++;
					}
				}
				if ( empty( $page['paging']['next'] ) ) {
					break;
				}
				$page = self::get( $page['paging']['next'], array(), $pt );
			}
			if ( is_wp_error( $page ) ) {
				delete_transient( 'lmcrm_meta_lock' );
				self::status( false, 'Formulaire ' . ( $f['name'] ?? $f['id'] ) . ' : ' . $page->get_error_message() );
				return $page;
			}
		}
		update_option( 'lmcrm_meta_since', $started, false );
		delete_transient( 'lmcrm_meta_lock' );
		self::status( true, sprintf( '%d formulaire(s), %d prospect(s) lus, %d ajouté(s)%s.', $res['forms'], $res['leads'], $res['created'], $first ? ' (reprise de l’historique)' : '' ) );
		return $res;
	}

	/** @return bool true si le prospect est nouveau dans le CRM. */
	private static function import_lead( array $lead, $form_name, $history ) {
		$ref = 'meta:' . $lead['id'];
		if ( LMCRM_DB::activity_exists( $ref ) ) {
			return false;
		}
		$f = array();
		foreach ( (array) ( $lead['field_data'] ?? array() ) as $fd ) {
			$f[ strtolower( (string) $fd['name'] ) ] = implode( ', ', (array) ( $fd['values'] ?? array() ) );
		}
		$pick = function ( array $keys ) use ( &$f ) {
			foreach ( $keys as $k ) {
				if ( isset( $f[ $k ] ) && '' !== $f[ $k ] ) {
					$v = $f[ $k ];
					unset( $f[ $k ] );
					return $v;
				}
			}
			return '';
		};
		$email = $pick( array( 'email', 'e-mail', 'courriel', 'adresse_courriel' ) );
		$name  = $pick( array( 'full_name', 'nom_complet', 'nom' ) );
		if ( '' === $name ) {
			$name = trim( $pick( array( 'first_name', 'prénom', 'prenom' ) ) . ' ' . $pick( array( 'last_name', 'nom_de_famille' ) ) );
		}
		$phone   = $pick( array( 'phone_number', 'phone', 'téléphone', 'telephone', 'numéro_de_téléphone' ) );
		$company = $pick( array( 'company_name', 'entreprise', 'nom_de_l\'entreprise', 'business_name' ) );
		$city    = $pick( array( 'city', 'ville' ) );
		$site    = $pick( array( 'website', 'site_web', 'site_internet' ) );
		if ( '' === $email && '' === $phone && '' === $name ) {
			return false;
		}
		$when = isset( $lead['created_time'] ) ? wp_date( 'Y-m-d H:i:s', strtotime( $lead['created_time'] ) ) : LMCRM_DB::now();
		$data = array(
			'name'       => $name,
			'company'    => $company,
			'email'      => $email,
			'phone'      => $phone,
			'city'       => $city,
			'website'    => $site,
			'source'     => 'meta',
			'stage'      => $history ? 'contacte' : 'nouveau',
			'created_at' => $when,
		);
		if ( '' !== $email ) {
			list( $cid ) = LMCRM_DB::upsert_contact( $data );
		} else {
			$cid = LMCRM_DB::insert_contact( $data );
		}
		$lines = array( 'Formulaire : ' . $form_name );
		if ( ! empty( $lead['campaign_name'] ) ) {
			$lines[] = 'Campagne : ' . $lead['campaign_name'];
		}
		if ( ! empty( $lead['ad_name'] ) ) {
			$lines[] = 'Publicité : ' . $lead['ad_name'];
		}
		if ( ! empty( $lead['platform'] ) ) {
			$lines[] = 'Plateforme : ' . ( 'ig' === $lead['platform'] ? 'Instagram' : 'Facebook' );
		}
		foreach ( $f as $k => $v ) {
			$lines[] = ucfirst( str_replace( '_', ' ', $k ) ) . ' : ' . $v;
		}
		LMCRM_DB::add_activity( $cid, 'meta', 'Prospect Meta : ' . $form_name, implode( "\n", $lines ), $ref, $when );
		if ( ! $history ) {
			LMCRM_DB::add_task( $cid, 'Rappeler le prospect Meta', LMCRM_DB::now(), 'task:' . $ref );
			$c = LMCRM_DB::contact( $cid );
			LMCRM_Notify::lead(
				$cid,
				'Nouveau prospect Meta : ' . LMCRM_DB::label( $c ),
				implode( "\n", array_filter( array( 'Nom : ' . $name, $company ? 'Entreprise : ' . $company : '', $email ? 'Courriel : ' . $email : '', $phone ? 'Téléphone : ' . $phone : '', '', implode( "\n", $lines ), '', 'Fiche : ' . admin_url( 'admin.php?page=lmcrm&contact=' . $cid ) ), function ( $l ) {
					return null !== $l;
				} ) )
			);
		}
		return true;
	}
}

<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * API REST lmcrm/v1, réservée aux administrateurs (cookie + nonce wp_rest).
 * Sert au glisser-déposer du pipeline et aux actions rapides de l'interface.
 */
class LMCRM_REST {

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
	}

	/** Accès au CRM : administrateurs et rôle « Utilisateur CRM » (capacité lmcrm_use). */
	public static function can() {
		return current_user_can( 'lmcrm_use' ) || current_user_can( 'manage_options' );
	}

	public static function admin() {
		return current_user_can( 'manage_options' );
	}

	public static function routes() {
		register_rest_route( 'lmcrm/v1', '/contacts/(?P<id>\d+)/stage', array(
			'methods'             => 'POST',
			'permission_callback' => array( __CLASS__, 'can' ),
			'callback'            => function ( WP_REST_Request $r ) {
				$id    = (int) $r['id'];
				$stage = sanitize_key( (string) $r->get_param( 'stage' ) );
				if ( ! LMCRM_DB::contact( $id ) || ! LMCRM_DB::has_stage( $stage ) ) {
					return new WP_Error( 'lmcrm', 'Contact ou étape inconnus', array( 'status' => 400 ) );
				}
				LMCRM_DB::set_stage( $id, $stage );
				return array( 'ok' => true, 'counts' => LMCRM_DB::stage_counts() );
			},
		) );

		register_rest_route( 'lmcrm/v1', '/tasks/(?P<id>\d+)/done', array(
			'methods'             => 'POST',
			'permission_callback' => array( __CLASS__, 'can' ),
			'callback'            => function ( WP_REST_Request $r ) {
				LMCRM_DB::complete_task( (int) $r['id'] );
				return array( 'ok' => true );
			},
		) );

		register_rest_route( 'lmcrm/v1', '/tasks/(?P<id>\d+)/undo', array(
			'methods'             => 'POST',
			'permission_callback' => array( __CLASS__, 'can' ),
			'callback'            => function ( WP_REST_Request $r ) {
				LMCRM_DB::reopen_task( (int) $r['id'] );
				return array( 'ok' => true );
			},
		) );

		register_rest_route( 'lmcrm/v1', '/summary', array(
			'methods'             => 'GET',
			'permission_callback' => array( __CLASS__, 'can' ),
			'callback'            => function () {
				return array(
					'stages' => LMCRM_DB::stage_counts(),
					'due'    => LMCRM_DB::open_tasks(),
				);
			},
		) );
	}
}

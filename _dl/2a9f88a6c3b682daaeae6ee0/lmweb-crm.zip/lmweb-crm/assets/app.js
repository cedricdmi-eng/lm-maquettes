/* LM Web CRM : application plein écran (sans dépendance). */
(function () {
	'use strict';
	var CFG = window.LMCRM_APP || {};
	var root = document.getElementById('lmcrm-app');
	if (!root) { return; }

	/* ---------- Outils ---------- */
	function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
	function $(sel, el) { return (el || document).querySelector(sel); }
	function $$(sel, el) { return Array.prototype.slice.call((el || document).querySelectorAll(sel)); }
	function parse(d) { return d ? new Date(String(d).replace(' ', 'T')) : null; }
	function pad(n) { return (n < 10 ? '0' : '') + n; }
	function ymd(d) { return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); }
	function sqlDate(d) { return ymd(d) + ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':00'; }
	var MONTHS = ['janv.', 'févr.', 'mars', 'avr.', 'mai', 'juin', 'juil.', 'août', 'sept.', 'oct.', 'nov.', 'déc.'];
	var DAYS = ['dim.', 'lun.', 'mar.', 'mer.', 'jeu.', 'ven.', 'sam.'];
	var DAYS_FULL = ['dimanche', 'lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi'];
	function hm(d) { return d.getHours() + ' h ' + pad(d.getMinutes()); }
	function dayLabel(d) {
		var t = new Date(); t.setHours(0, 0, 0, 0);
		var x = new Date(d); x.setHours(0, 0, 0, 0);
		var diff = Math.round((x - t) / 864e5);
		if (diff === 0) { return 'Aujourd’hui'; }
		if (diff === -1) { return 'Hier'; }
		if (diff === 1) { return 'Demain'; }
		if (diff > 1 && diff < 7) { return DAYS_FULL[d.getDay()].replace(/^./, function (c) { return c.toUpperCase(); }); }
		return DAYS[d.getDay()] + ' ' + d.getDate() + ' ' + MONTHS[d.getMonth()] + (d.getFullYear() !== t.getFullYear() ? ' ' + d.getFullYear() : '');
	}
	function ago(d) {
		d = parse(d); if (!d) { return ''; }
		var s = Math.max(0, (Date.now() - d) / 1000);
		if (s < 60) { return 'à l’instant'; }
		if (s < 3600) { return 'il y a ' + Math.floor(s / 60) + ' min'; }
		if (s < 86400) { return 'il y a ' + Math.floor(s / 3600) + ' h'; }
		var j = Math.floor(s / 86400);
		if (j < 30) { return 'il y a ' + j + ' j'; }
		return d.getDate() + ' ' + MONTHS[d.getMonth()] + ' ' + d.getFullYear();
	}
	function elapsed(d) {
		var s = Math.max(0, Math.floor((Date.now() - parse(d)) / 1000));
		if (s < 3600) { return Math.floor(s / 60) + ' min'; }
		if (s < 86400) { return Math.floor(s / 3600) + ' h ' + pad(Math.floor((s % 3600) / 60)); }
		return Math.floor(s / 86400) + ' j';
	}
	function heat(d) {
		var m = (Date.now() - parse(d)) / 60000;
		return m < 5 ? 'hot' : (m < 60 ? 'warm' : 'cold');
	}
	function money(v) { return (Math.round(v) || 0).toLocaleString('fr-CA') + '\u00a0$'; }
	function mark(n) { var w = String(n || '').trim().split(/\s+/); return (w[0] && w[0].length <= 3 ? w[0] : w.slice(0, 2).map(function (x) { return x[0]; }).join('')).toUpperCase(); }
	function dueInfo(d) {
		if (!d) { return { cls: '', text: '' }; }
		var x = parse(d), now = new Date(), t0 = new Date(); t0.setHours(0, 0, 0, 0);
		var late = x < t0 || (x < now && ymd(x) !== ymd(now));
		var today = ymd(x) === ymd(now);
		var txt = today ? 'Aujourd’hui' : dayLabel(x);
		if (x.getHours() !== 9 || x.getMinutes() !== 0) { txt += ', ' + hm(x); }
		return { cls: late ? 'late' : (today ? 'today' : ''), text: late ? 'En retard, ' + dayLabel(x).toLowerCase() : txt };
	}
	function initials(n) {
		var p = String(n || '?').trim().split(/\s+/).filter(Boolean);
		return ((p[0] || '?')[0] + (p.length > 1 ? p[p.length - 1][0] : '')).toUpperCase();
	}
	var HUES = [212, 262, 330, 24, 160, 190, 280, 140, 8, 45];
	function hue(s) { var h = 0; s = String(s || ''); for (var i = 0; i < s.length; i++) { h = (h * 31 + s.charCodeAt(i)) >>> 0; } return HUES[h % HUES.length]; }
	function avatar(c, size) {
		var n = c.name || c.company || c.email || '?';
		return '<span class="av' + (size ? ' av-' + size : '') + '" style="--h:' + hue(n) + '">' + esc(initials(n)) + '</span>';
	}
	function label(c) {
		var n = (c.name || '').trim(), co = (c.company || '').trim();
		return n || co || c.email || c.phone || 'Sans nom';
	}
	function tel(p) { return String(p || '').replace(/[^0-9+]/g, ''); }

	var ICON = {
		today: '<path d="M4 7h16M7 3v4m10-4v4M5 5h14a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1Z"/><path d="m9 14 2 2 4-4"/>',
		pipeline: '<path d="M4 5h4v14H4zM10 5h4v9h-4zM16 5h4v5h-4z"/>',
		contacts: '<path d="M16 19v-1a4 4 0 0 0-4-4H7a4 4 0 0 0-4 4v1"/><circle cx="9.5" cy="7.5" r="3.5"/><path d="M21 19v-1a4 4 0 0 0-3-3.87M16 4.13A3.5 3.5 0 0 1 16 11"/>',
		settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.6 1.6 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.6 1.6 0 0 0-1.8-.3 1.6 1.6 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.6 1.6 0 0 0-1-1.5 1.6 1.6 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.6 1.6 0 0 0 .3-1.8 1.6 1.6 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.6 1.6 0 0 0 1.5-1 1.6 1.6 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.6 1.6 0 0 0 1.8.3H9a1.6 1.6 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.6 1.6 0 0 0 1 1.5 1.6 1.6 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.6 1.6 0 0 0-.3 1.8V9a1.6 1.6 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.6 1.6 0 0 0-1.5 1Z"/>',
		phone: '<path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2Z"/>',
		mail: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/>',
		sms: '<path d="M21 12a8 8 0 0 1-11.6 7.1L4 20l1-4.6A8 8 0 1 1 21 12Z"/>',
		search: '<circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/>',
		plus: '<path d="M12 5v14M5 12h14"/>',
		x: '<path d="M18 6 6 18M6 6l12 12"/>',
		check: '<path d="M20 6 9 17l-5-5"/>',
		clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
		note: '<path d="M4 20h4L19 9l-4-4L4 16v4Z"/><path d="m14 6 4 4"/>',
		back: '<path d="m15 18-6-6 6-6"/>',
		external: '<path d="M14 4h6v6M10 14 20 4M19 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1h5"/>',
		trash: '<path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13"/>',
		video: '<rect x="3" y="6" width="13" height="12" rx="2"/><path d="m16 10 5-3v10l-5-3"/>',
		wp: '<circle cx="12" cy="12" r="9"/><path d="M5.5 8.5 9.5 19l2.5-7 2.5 7 4-10.5M8 8.5h3M13 8.5h3"/>',
		bolt: '<path d="M13 2 4 14h7l-1 8 9-12h-7l1-8Z"/>',
		sparkle: '<path d="M12 3v4M12 17v4M3 12h4M17 12h4M5.6 5.6l2.8 2.8M15.6 15.6l2.8 2.8M5.6 18.4l2.8-2.8M15.6 8.4l2.8-2.8"/>',
		bell: '<path d="M6 8a6 6 0 1 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.9 1.9 0 0 0 3.4 0"/>',
		logout: '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/>',
		user: '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>'
	};
	function icon(n, cls) { return '<svg class="ic' + (cls ? ' ' + cls : '') + '" viewBox="0 0 24 24" aria-hidden="true">' + ICON[n] + '</svg>'; }

	var SRC = {
		meta: { t: 'Meta', c: '#1877F2' }, google: { t: 'Google', c: '#1A73E8' }, form: { t: 'Site web', c: '#7C3AED' },
		rdv: { t: 'Rendez-vous', c: '#0E9F8E' }, maquette: { t: 'Maquette', c: '#E8590C' }, zoho: { t: 'Import', c: '#6B7280' }, manuel: { t: 'Manuel', c: '#6B7280' }
	};
	function src(s) { var x = SRC[s] || SRC.manuel; return '<span class="src" style="--c:' + x.c + '">' + esc(x.t) + '</span>'; }
	/* Étapes : définies par le site (modèle de métier), lues au démarrage. */
	var STAGE_ORDER = [], OPEN_STAGES = [], SHORT = {}, COLORS = {};
	function setStages(defs) {
		STAGE_ORDER = defs.map(function (d) { return d.key; });
		OPEN_STAGES = STAGE_ORDER.filter(function (k) { return k !== 'gagne' && k !== 'perdu'; });
		STAGES = {}; SHORT = {}; COLORS = {};
		defs.forEach(function (d) { STAGES[d.key] = d.label; SHORT[d.key] = d.short || d.label; COLORS[d.key] = d.color || '#8A93A6'; });
	}
	function pill(stage) { return '<span class="pill" style="--c:' + esc(COLORS[stage] || '#8A93A6') + '">' + esc(STAGES[stage] || stage) + '</span>'; }
	function dot(stage) { return '<span class="dot" style="background:' + esc(COLORS[stage] || '#8A93A6') + '"></span>'; }
	function kindChip(k) { return k ? '<span class="kind">' + esc(k) + '</span>' : ''; }
	function userName(id) { var u = (S.boot.users || []).filter(function (x) { return x.id === id; })[0]; return u ? u.name : ''; }
	function team() { return (S.boot.users || []).length > 1; }

	/* ---------- API (réelle ou démo) ---------- */
	var DEMO = /[?&]demo=1/.test(location.search) || CFG.demo;
	function api(method, path, body) {
		if (DEMO) { return Demo.call(method, path, body); }
		return fetch(CFG.rest + path, {
			method: method, credentials: 'same-origin',
			headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': CFG.nonce },
			body: body ? JSON.stringify(body) : undefined
		}).then(function (r) {
			return r.json().catch(function () { return {}; }).then(function (j) {
				if (!r.ok) { throw new Error(j.message || ('Erreur ' + r.status)); }
				return j;
			});
		});
	}

	/* ---------- État ---------- */
	var S = { boot: null, view: 'today', contacts: { s: '', stage: '', source: '', filter: '', sort: 'recent', page: 1 }, drawer: null, timers: [] };
	var STAGES = {}, BRAND = {};

	/* ---------- Coquille ---------- */
	function shell() {
		var b = S.boot;
		BRAND = b.brand; setStages(b.stage_defs);
		root.style.setProperty('--accent', BRAND.color);
		var nav = [['today', 'Aujourd’hui'], ['pipeline', 'Pipeline'], ['contacts', 'Contacts']];
		root.innerHTML =
			'<aside class="side">' +
			'<a class="brand" href="#/">' + (BRAND.logo ? '<img src="' + esc(BRAND.logo) + '" alt="">' : '<span class="brand-mark">' + esc(mark(BRAND.name)) + '</span>') + '<span class="brand-name">' + esc(BRAND.name) + '</span></a>' +
			'<nav class="nav">' + nav.map(function (n) { return '<a href="#/' + (n[0] === 'today' ? '' : n[0]) + '" data-nav="' + n[0] + '">' + icon(n[0]) + '<span>' + n[1] + '</span>' + (n[0] === 'today' ? '<b class="nav-badge" hidden></b>' : '') + '</a>'; }).join('') + '</nav>' +
			'<div class="side-foot">' +
			'<a href="#/" data-act="notif">' + icon('bell') + '<span>Sur mon téléphone</span></a>' +
			(DEMO || !CFG.settings ? '' : '<a href="' + esc(CFG.settings) + '">' + icon('settings') + '<span>Réglages</span></a>') +
			(DEMO ? '<a href="' + esc(location.pathname + location.search.replace(/[?&]demo=1/, '').replace(/^&/, '?')) + '">' + icon('sparkle') + '<span>Quitter la démo</span></a>' : '') +
			(CFG.wp ? '<a href="' + esc(CFG.wp) + '">' + icon('wp') + '<span>WordPress</span></a>' : (CFG.logout ? '<a href="' + esc(CFG.logout) + '">' + icon('logout') + '<span>Se déconnecter</span></a>' : '')) + '</div>' +
			'</aside>' +
			'<div class="main"><header class="top"><button class="search-btn" data-act="palette">' + icon('search') + '<span>Rechercher un contact</span><kbd>Ctrl K</kbd></button>' +
			(DEMO ? '<span class="demo-pill">Mode démo, données fictives</span>' : '') +
			'<button class="btn btn-ghost btn-icon top-bell" data-act="notif" aria-label="Recevoir les prospects sur le téléphone" title="Recevoir les prospects sur le téléphone">' + icon('bell') + '<i class="bell-dot"' + (DEMO ? ' hidden' : '') + '></i></button>' +
			'<button class="btn btn-accent" data-act="new">' + icon('plus') + '<span>Nouveau contact</span></button></header>' +
			'<div class="view" id="view"></div></div>' +
			'<div class="drawer-wrap" id="drawer" aria-hidden="true"><div class="drawer-scrim" data-act="close"></div><section class="drawer" role="dialog" aria-modal="true" aria-label="Fiche contact"></section></div>' +
			'<div class="modal-wrap" id="modal" hidden></div>' +
			'<div class="toasts" id="toasts" aria-live="polite"></div>';
		updateBadge();
	}

	function updateBadge() {
		var b = $('.nav-badge'); if (!b || !S.boot) { return; }
		var now = new Date(); var end = new Date(); end.setHours(23, 59, 59);
		var n = S.boot.fresh.filter(function (c) { return !c.rdv; }).length + S.boot.tasks.filter(function (t) { return parse(t.due_at) <= end && t.stage !== 'nouveau'; }).length;
		b.hidden = !n; b.textContent = n > 99 ? '99+' : n;
	}

	function setView(html) {
		S.timers.forEach(clearInterval); S.timers = [];
		$('#view').innerHTML = html;
		$$('.nav a').forEach(function (a) { a.classList.toggle('on', a.dataset.nav === S.view); });
		$('#view').scrollTop = 0;
	}

	/* ---------- Aujourd'hui ---------- */
	function greeting() {
		var h = new Date().getHours();
		return (h < 12 ? 'Bonjour' : (h < 18 ? 'Bon après-midi' : 'Bonsoir')) + (S.boot.user.name ? ', ' + S.boot.user.name : '');
	}

	function viewToday() {
		var b = S.boot, now = new Date();
		var end = new Date(); end.setHours(23, 59, 59);
		var freshIds = {};
		b.fresh.forEach(function (c) { freshIds[c.id] = 1; });
		var due = b.tasks.filter(function (t) { return parse(t.due_at) <= end && !freshIds[t.contact_id]; });
		var later = b.tasks.filter(function (t) { return parse(t.due_at) > end; });
		var urgent = b.fresh.filter(function (c) { return !c.rdv; }), booked = b.fresh.filter(function (c) { return c.rdv; });
		var n = urgent.length + due.length;
		var st = b.stats;
		var delta = st.new7 - st.prev7;
		var resp = st.response;
		var respTxt = resp == null ? 'pas encore mesuré' : (resp < 60 ? resp + ' min' : (resp < 1440 ? Math.round(resp / 60) + ' h' : Math.round(resp / 1440) + ' j'));
		var pipe = 0; OPEN_STAGES.forEach(function (k) { pipe += (b.counts[k] || {}).v || 0; });
		var open = 0; OPEN_STAGES.forEach(function (k) { open += (b.counts[k] || {}).n || 0; });

		var html = '<div class="today">' +
			'<section class="hello"><div><h1>' + esc(greeting()) + '</h1><p>' + esc(DAYS_FULL[now.getDay()].replace(/^./, function (c) { return c.toUpperCase(); }) + ' ' + now.getDate() + ' ' + MONTHS[now.getMonth()].replace('.', '')) + ' · ' +
			(n ? '<strong>' + n + ' ' + (n > 1 ? 'personnes attendent' : 'personne attend') + ' de tes nouvelles</strong>' : 'tout est à jour') + '</p></div></section>' +
			pushBanner() +
			'<section class="pulse" aria-label="Indicateurs">' +
			stat(st.new7, 'nouveaux prospects en 7 jours', delta === 0 ? 'stable' : (delta > 0 ? '+' + delta : delta) + ' vs semaine d’avant', delta > 0 ? 'up' : (delta < 0 ? 'down' : '')) +
			stat(respTxt, 'délai moyen de premier contact', resp == null ? 'calculé dès tes prochains appels' : (resp <= 60 ? 'excellent' : 'objectif : moins d’une heure'), resp != null && resp <= 60 ? 'up' : (resp != null && resp > 240 ? 'down' : '')) +
			stat(open, 'prospects en cours', money(pipe) + ' en jeu', '') +
			stat(st.won30, 'clients gagnés en 30 jours', '', st.won30 ? 'up' : '') +
			'</section>' +
			'<div class="today-grid"><div class="col-main">' +
			'<section class="block"><header class="block-h"><h2>À traiter maintenant</h2><span class="muted">' + (n ? 'du plus urgent au moins urgent' : '') + '</span></header>' +
			(n || booked.length ? '<ol class="queue">' + urgent.map(queueLead).join('') + due.map(queueTask).join('') + booked.map(queueLead).join('') + '</ol>'
				: '<div class="empty"><div class="empty-ic">' + icon('check') + '</div><h3>Rien ne t’attend</h3><p>Les nouveaux prospects apparaîtront ici avec leur chrono. Profites-en pour relancer un devis en attente.</p><a class="btn" href="#/pipeline">Ouvrir le pipeline</a></div>') +
			'</section>' +
			(later.length ? '<section class="block"><header class="block-h"><h2>Plus tard cette semaine</h2><span class="muted">' + later.length + ' relance' + (later.length > 1 ? 's' : '') + '</span></header><ul class="later">' + later.slice(0, 12).map(laterRow).join('') + '</ul></section>' : '') +
			'</div><div class="col-side">' + agendaBlock(b.agenda) + sourcesBlock(st.sources) + '</div></div></div>';
		setView(html);
		hideBannerIfActive();
		S.timers.push(setInterval(function () {
			$$('[data-since]').forEach(function (el) {
				el.querySelector('.clock-t').textContent = elapsed(el.dataset.since);
				el.className = 'clock clock-' + heat(el.dataset.since);
			});
		}, 15000));
	}

	function stat(v, l, sub, tone) {
		return '<div class="stat"><strong>' + esc(v) + '</strong><span>' + esc(l) + '</span>' + (sub ? '<em class="' + tone + '">' + esc(sub) + '</em>' : '') + '</div>';
	}

	function rdvDay(ts) { var d = new Date(ts * 1000), l = dayLabel(d); return /^\S+ \d+ /.test(l) ? l.split(' ').slice(0, 2).join(' ') : l; }
	function rdvHour(ts) { var d = new Date(ts * 1000); return d.getHours() + ' h' + (d.getMinutes() ? ' ' + pad(d.getMinutes()) : ''); }
	function queueLead(c) {
		var r = c.rdv, rd = r ? new Date(r.s * 1000) : null;
		return '<li class="q q-lead' + (r ? ' q-booked' : '') + '" data-open="' + c.id + '">' +
			(r ? '<span class="clock clock-rdv" title="Rendez-vous réservé"><small>' + esc(rdvDay(r.s)) + '</small>' + esc(rdvHour(r.s)) + '</span>'
				: '<span class="clock clock-' + heat(c.created) + '" data-since="' + esc(c.created) + '" title="Arrivé ' + esc(ago(c.created)) + '"><span class="clock-t">' + esc(elapsed(c.created)) + '</span></span>') +
			avatar(c) +
			'<div class="q-body"><div class="q-title"><strong>' + esc(label(c)) + '</strong>' + src(c.source) + kindChip(c.kind) + '</div>' +
			'<div class="q-sub">' + (r ? esc(r.title + ' prévu ' + dayLabel(rd).toLowerCase() + ' à ' + hm(rd)) : esc([c.company && c.company !== c.name ? c.company : '', c.city].filter(Boolean).join(', ') || 'Nouveau prospect') + (c.next_title ? ' · ' + esc(c.next_title) : '')) + '</div></div>' +
			'<div class="q-acts">' + (c.phone ? (r ? '<a class="btn btn-ghost btn-icon" href="tel:' + esc(tel(c.phone)) + '" data-call="' + c.id + '" title="Appeler">' + icon('phone') + '</a>' : '<a class="btn btn-call" href="tel:' + esc(tel(c.phone)) + '" data-call="' + c.id + '">' + icon('phone') + '<span>Appeler</span></a>') : '') +
			(c.email ? '<a class="btn btn-ghost btn-icon" href="mailto:' + esc(c.email) + '" data-mail="' + c.id + '" title="Écrire">' + icon('mail') + '</a>' : '') + '</div></li>';
	}

	function queueTask(t) {
		var di = dueInfo(t.due_at);
		var c = { name: t.name, company: t.company };
		return '<li class="q q-task" data-open="' + (t.contact_id || '') + '">' +
			'<button class="tick" data-done="' + t.id + '" aria-label="Marquer « ' + esc(t.title) + ' » comme faite"></button>' +
			avatar(c) +
			'<div class="q-body"><div class="q-title"><strong>' + esc(t.title) + '</strong></div>' +
			'<div class="q-sub">' + esc(label(c)) + ' · <span class="due ' + di.cls + '">' + esc(di.text) + '</span></div></div>' +
			'<div class="q-acts">' + (t.phone ? '<a class="btn btn-ghost btn-icon" href="tel:' + esc(tel(t.phone)) + '" data-call="' + t.contact_id + '" data-task="' + t.id + '" title="Appeler">' + icon('phone') + '</a>' : '') +
			'<button class="btn btn-ghost btn-sm" data-snooze="' + t.id + '">Reporter</button></div></li>';
	}

	function laterRow(t) {
		var d = parse(t.due_at);
		return '<li data-open="' + (t.contact_id || '') + '"><span class="later-d">' + esc(dayLabel(d)) + '</span><span class="later-t">' + esc(t.title) + '</span><span class="muted">' + esc(label({ name: t.name, company: t.company })) + '</span></li>';
	}

	function agendaBlock(items) {
		var now = Date.now() / 1000;
		var html = '<section class="block agenda"><header class="block-h"><h2>Mon agenda</h2></header>';
		if (!items || !items.length) { return html + '<p class="muted pad">Aucun rendez-vous aujourd’hui.</p></section>'; }
		return html + '<ul class="slots">' + items.map(function (it) {
			var cls = it.e < now ? ' past' : (it.s <= now ? ' live' : '');
			var s = new Date(it.s * 1000), e = new Date(it.e * 1000);
			return '<li class="slot' + cls + (it.busy ? ' busy' : '') + '"' + (it.contact ? ' data-open="' + it.contact + '"' : '') + '><span class="slot-h">' + esc(hm(s)) + '<small>' + esc(hm(e)) + '</small></span><div>' +
				(it.busy ? '<strong>Occupé</strong><span class="muted">autre engagement</span>' : '<strong>' + esc(it.title) + '</strong><span class="muted">' + esc(it.who) + '</span>' +
					(it.meet ? '<a class="slot-meet" href="' + esc(it.meet) + '" target="_blank" rel="noopener">' + icon('video') + 'Rejoindre</a>' : '')) +
				'</div></li>';
		}).join('') + '</ul></section>';
	}

	function sourcesBlock(rows) {
		if (!rows || !rows.length) { return ''; }
		var max = Math.max.apply(null, rows.map(function (r) { return +r.n; }));
		return '<section class="block"><header class="block-h"><h2>D’où viennent tes prospects</h2><span class="muted">30 jours</span></header><ul class="bars">' +
			rows.map(function (r) { var x = SRC[r.source] || SRC.manuel; return '<li><span>' + esc(x.t) + '</span><span class="bar"><i style="width:' + Math.max(4, Math.round(r.n / max * 100)) + '%;background:' + x.c + '"></i></span><b>' + esc(r.n) + '</b></li>'; }).join('') +
			'</ul></section>';
	}

	/* ---------- Pipeline ---------- */
	function viewPipeline() {
		setView('<div class="page-h"><h1>Pipeline</h1><p class="muted">Glisse une carte pour changer d’étape.</p>' +
			'<div class="board-arrows"><button class="btn btn-icon" data-scroll="-1" aria-label="Colonnes précédentes">' + icon('back') + '</button><button class="btn btn-icon" data-scroll="1" aria-label="Colonnes suivantes">' + icon('back', 'flip') + '</button></div></div>' +
			'<div class="board-nav" id="bnav" hidden></div><div class="board" id="board"><div class="loading">Chargement…</div></div>');
		api('GET', 'pipeline').then(function (r) {
			var by = {}; r.rows.forEach(function (c) { (by[c.stage] = by[c.stage] || []).push(c); });
			$('#bnav').innerHTML = '<div class="bn-segs">' + STAGE_ORDER.map(function (s) { return '<button class="bn-seg" data-goto="' + s + '">' + dot(s) + '<span class="bn-l">' + esc(SHORT[s] || STAGES[s]) + '</span><b>' + (by[s] || []).length + '</b></button>'; }).join('') + '</div><div class="bn-win" aria-hidden="true"></div>';
			$('#board').innerHTML = STAGE_ORDER.map(function (s) {
				var list = by[s] || [], tot = s === 'perdu' ? 0 : list.reduce(function (a, c) { return a + (c.value || 0); }, 0);
				return '<section class="col col-' + s + '" data-stage="' + s + '"><header>' + dot(s) + '<h2>' + esc(STAGES[s]) + '</h2><b>' + list.length + '</b>' + (tot ? '<em>' + money(tot) + '</em>' : '') + '</header>' +
					'<div class="col-list">' + (list.length ? list.map(card).join('') : '<p class="col-empty">Dépose une carte ici</p>') + '</div></section>';
			}).join('');
			bindBoard();
			bindBoardNav();
		}).catch(fail);
	}

	function card(c) {
		var di = dueInfo(c.next_due);
		return '<article class="card" draggable="true" data-id="' + c.id + '" data-open="' + c.id + '">' +
			'<div class="card-top">' + avatar(c, 'sm') + '<strong>' + esc(label(c)) + '</strong></div>' +
			(c.company && c.company !== c.name ? '<div class="card-co">' + esc(c.company) + '</div>' : '') +
			'<div class="card-meta"><span class="card-tags">' + src(c.source) + kindChip(c.kind) + '</span>' + (c.value ? '<span class="card-val">' + money(c.value) + '</span>' : (c.owner && team() ? '<span class="owner" title="' + esc(userName(c.owner)) + '">' + esc(initials(userName(c.owner))) + '</span>' : '')) + '</div>' +
			(c.next_due ? '<div class="card-next ' + di.cls + '">' + icon('clock') + esc(di.text) + '</div>' : '<div class="card-next none">Aucune relance prévue</div>') +
			'</article>';
	}

	function bindBoard() {
		var dragged = null;
		$$('.card').forEach(function (el) {
			el.addEventListener('dragstart', function (e) { dragged = el; el.classList.add('drag'); e.dataTransfer.effectAllowed = 'move'; e.dataTransfer.setData('text/plain', el.dataset.id); });
			el.addEventListener('dragend', function () { el.classList.remove('drag'); dragged = null; });
		});
		$$('.col').forEach(function (col) {
			col.addEventListener('dragover', function (e) { e.preventDefault(); col.classList.add('over'); });
			col.addEventListener('dragleave', function (e) { if (!col.contains(e.relatedTarget)) { col.classList.remove('over'); } });
			col.addEventListener('drop', function (e) {
				e.preventDefault(); col.classList.remove('over');
				if (!dragged) { return; }
				var from = dragged.closest('.col'); if (from === col) { return; }
				var list = col.querySelector('.col-list'); var empty = list.querySelector('.col-empty'); if (empty) { empty.remove(); }
				list.prepend(dragged);
				var id = dragged.dataset.id, old = from.dataset.stage, nu = col.dataset.stage;
				recount();
				api('PATCH', 'contacts/' + id, { stage: nu }).then(function () {
					toast('Déplacé vers « ' + STAGES[nu] + ' »', function () { api('PATCH', 'contacts/' + id, { stage: old }).then(viewPipeline); });
					refreshBoot();
				}).catch(function (er) { fail(er); viewPipeline(); });
			});
		});
	}
	function recount() {
		$$('.col').forEach(function (col) {
			var n = col.querySelectorAll('.card').length;
			col.querySelector('header b').textContent = n;
			var seg = $('.bn-seg[data-goto="' + col.dataset.stage + '"] b'); if (seg) { seg.textContent = n; }
		});
	}

	/* Navigation horizontale : la barre des étapes montre la partie visible et se glisse comme un curseur. */
	function bindBoardNav() {
		var board = $('#board'), nav = $('#bnav'), win = nav && nav.querySelector('.bn-win');
		if (!board || !win) { return; }
		function sync() {
			var sw = board.scrollWidth, cw = board.clientWidth;
			var fits = sw - cw < 4;
			nav.hidden = fits; $$('.board-arrows .btn').forEach(function (b) { b.disabled = fits; });
			if (fits) { return; }
			win.style.left = (board.scrollLeft / sw * 100) + '%';
			win.style.width = (cw / sw * 100) + '%';
			$$('.board-arrows .btn')[0].disabled = board.scrollLeft < 4;
			$$('.board-arrows .btn')[1].disabled = board.scrollLeft > sw - cw - 4;
			var l = board.getBoundingClientRect().left, r = l + cw;
			$$('.col', board).forEach(function (col) {
				var b = col.getBoundingClientRect(), seg = $('.bn-seg[data-goto="' + col.dataset.stage + '"]');
				if (seg) { seg.classList.toggle('in', b.right > l + 40 && b.left < r - 40); }
			});
		}
		function toFrac(x) { var rc = nav.getBoundingClientRect(); return Math.min(1, Math.max(0, (x - rc.left) / rc.width)); }
		var drag = null;
		nav.addEventListener('pointerdown', function (e) {
			var seg = e.target.closest('.bn-seg');
			var onWin = e.clientX >= win.getBoundingClientRect().left && e.clientX <= win.getBoundingClientRect().right;
			if (seg && !onWin) { return; }
			e.preventDefault(); nav.setPointerCapture(e.pointerId);
			drag = { x: e.clientX, start: board.scrollLeft, moved: false };
			nav.classList.add('dragging');
		});
		nav.addEventListener('pointermove', function (e) {
			if (!drag) { return; }
			var dx = e.clientX - drag.x; if (Math.abs(dx) > 3) { drag.moved = true; }
			board.style.scrollSnapType = 'none';
			board.scrollLeft = drag.start + dx / nav.getBoundingClientRect().width * board.scrollWidth;
		});
		function end(e) {
			if (!drag) { return; }
			if (!drag.moved) { board.scrollTo({ left: toFrac(e.clientX) * board.scrollWidth - board.clientWidth / 2, behavior: 'smooth' }); }
			drag = null; nav.classList.remove('dragging'); board.style.scrollSnapType = '';
			nav.classList.add('jd'); setTimeout(function () { nav.classList.remove('jd'); }, 60);
		}
		nav.addEventListener('pointerup', end); nav.addEventListener('pointercancel', end);
		board.addEventListener('scroll', sync, { passive: true });
		window.addEventListener('resize', sync);
		// Pendant un glisser de carte, le tableau défile tout seul près des bords.
		board.addEventListener('dragover', function (e) {
			var rc = board.getBoundingClientRect();
			if (e.clientX < rc.left + 70) { board.scrollLeft -= 18; } else if (e.clientX > rc.right - 70) { board.scrollLeft += 18; }
		});
		sync();
	}
	function scrollBoard(dir) {
		var board = $('#board'), col = board && board.querySelector('.col'); if (!col) { return; }
		var step = col.getBoundingClientRect().width + 14;
		board.scrollBy({ left: dir * step * Math.max(1, Math.floor(board.clientWidth / step)), behavior: 'smooth' });
	}

	/* ---------- Contacts ---------- */
	function viewContacts() {
		var q = S.contacts;
		var chips = [['', 'Tous']].concat(STAGE_ORDER.map(function (s) { return [s, STAGES[s]]; }));
		setView('<div class="page-h"><h1>Contacts</h1><span class="muted" id="ctotal"></span></div>' +
			'<div class="toolbar"><label class="field-search">' + icon('search') + '<input type="search" id="cs" placeholder="Nom, entreprise, courriel, téléphone ou ville" value="' + esc(q.s) + '"></label>' +
			'<select id="csrc" aria-label="Source"><option value="">Toutes les sources</option>' + Object.keys(SRC).map(function (k) { return '<option value="' + k + '"' + (q.source === k ? ' selected' : '') + '>' + esc(SRC[k].t) + '</option>'; }).join('') + '</select>' +
			'<select id="csort" aria-label="Tri"><option value="recent">Activité récente</option><option value="new">Plus récents</option><option value="next">Prochaine relance</option><option value="name">Nom</option><option value="value">Valeur</option></select></div>' +
			'<div class="chips" role="tablist">' + chips.map(function (c) { return '<button role="tab" class="chip' + (q.stage === c[0] && !q.filter ? ' on' : '') + '" data-stage="' + c[0] + '">' + esc(c[1]) + '</button>'; }).join('') +
			'<button class="chip chip-late' + (q.filter === 'late' ? ' on' : '') + '" data-filter="late">En retard</button>' +
			(team() ? '<button class="chip' + (q.filter === 'mine' ? ' on' : '') + '" data-filter="mine">Mes prospects</button>' : '') + '</div>' +
			'<div id="clist" class="table-wrap"><div class="loading">Chargement…</div></div>');
		$('#csort').value = q.sort;
		var t;
		$('#cs').addEventListener('input', function (e) { clearTimeout(t); t = setTimeout(function () { q.s = e.target.value; q.page = 1; loadContacts(); }, 250); });
		$('#csrc').addEventListener('change', function (e) { q.source = e.target.value; q.page = 1; loadContacts(); });
		$('#csort').addEventListener('change', function (e) { q.sort = e.target.value; loadContacts(); });
		loadContacts();
	}

	function loadContacts() {
		var q = S.contacts;
		var p = 'contacts?s=' + encodeURIComponent(q.s) + '&stage=' + q.stage + '&source=' + q.source + '&filter=' + q.filter + '&sort=' + q.sort + '&page=' + q.page;
		api('GET', p).then(function (r) {
			$('#ctotal').textContent = r.total + ' contact' + (r.total > 1 ? 's' : '');
			if (!r.rows.length) {
				$('#clist').innerHTML = '<div class="empty"><div class="empty-ic">' + icon('contacts') + '</div><h3>Aucun contact ne correspond</h3><p>Essaie un autre mot ou retire un filtre.</p></div>';
				return;
			}
			$('#clist').innerHTML = '<table class="tbl"><thead><tr><th>Contact</th><th>Étape</th><th class="hide-sm">Source</th><th class="hide-sm">Prochaine relance</th><th class="hide-md">Dernière activité</th></tr></thead><tbody>' +
				r.rows.map(function (c) {
					var di = dueInfo(c.next_due);
					return '<tr data-open="' + c.id + '"><td><div class="cell-c">' + avatar(c) + '<div><strong>' + esc(label(c)) + '</strong><span class="muted">' + esc([c.company && c.company !== c.name ? c.company : '', c.phone || c.email].filter(Boolean).join(' · ')) + '</span></div></div></td>' +
						'<td>' + pill(c.stage) + kindChip(c.kind) + '</td><td class="hide-sm">' + src(c.source) + '</td>' +
						'<td class="hide-sm"><span class="due ' + di.cls + '">' + esc(di.text || '—') + '</span></td><td class="hide-md muted">' + esc(ago(c.last)) + '</td></tr>';
				}).join('') + '</tbody></table>' +
				(r.pages > 1 ? '<div class="pager"><button class="btn btn-ghost" data-page="' + (r.page - 1) + '"' + (r.page <= 1 ? ' disabled' : '') + '>Précédents</button><span class="muted">Page ' + r.page + ' sur ' + r.pages + '</span><button class="btn btn-ghost" data-page="' + (r.page + 1) + '"' + (r.page >= r.pages ? ' disabled' : '') + '>Suivants</button></div>' : '');
		}).catch(fail);
	}

	/* ---------- Fiche contact (panneau) ---------- */
	function openContact(id, opts) {
		var wrap = $('#drawer'), d = wrap.querySelector('.drawer');
		if (!S.drawer || S.drawer.contact.id !== +id) { d.innerHTML = '<div class="loading">Chargement…</div>'; }
		wrap.classList.add('open'); wrap.setAttribute('aria-hidden', 'false');
		document.body.classList.add('noscroll');
		return api('GET', 'contacts/' + id).then(function (r) { S.drawer = r; renderDrawer(opts || {}); }).catch(function (e) { fail(e); closeDrawer(); });
	}

	function closeDrawer() {
		var wrap = $('#drawer'); wrap.classList.remove('open'); wrap.setAttribute('aria-hidden', 'true');
		document.body.classList.remove('noscroll'); S.drawer = null;
		if (/^#\/contact\//.test(location.hash)) { history.replaceState(null, '', '#/' + (S.view === 'today' ? '' : S.view)); }
	}

	function renderDrawer(opts) {
		var r = S.drawer, c = r.contact, d = $('#drawer .drawer');
		var open = r.tasks.filter(function (t) { return !t.done_at; }), done = r.tasks.filter(function (t) { return t.done_at; });
		var idx = STAGE_ORDER.indexOf(c.stage);
		d.innerHTML =
			'<header class="dh"><button class="btn btn-ghost btn-icon" data-act="close" aria-label="Fermer">' + icon('x') + '</button>' +
			'<div class="dh-id">' + avatar(c, 'lg') + '<div><h2>' + esc(label(c)) + '</h2><p class="muted">' + esc([c.company && c.company !== c.name ? c.company : '', c.city].filter(Boolean).join(', ')) + '</p><div class="dh-tags">' + src(c.source) + kindChip(c.kind) + '<span class="muted">arrivé ' + esc(ago(c.created)) + '</span>' +
				(team() ? '<label class="owner-pick">' + icon('user') + '<select data-owner="' + c.id + '" aria-label="Responsable"><option value="0">Non attribué</option>' + S.boot.users.map(function (u) { return '<option value="' + u.id + '"' + (u.id === c.owner ? ' selected' : '') + '>' + esc(u.name) + '</option>'; }).join('') + '</select></label>' : '') +
				'</div></div></div>' +
			'<div class="dh-acts">' +
			(c.phone ? '<a class="btn btn-call" href="tel:' + esc(tel(c.phone)) + '" data-call="' + c.id + '">' + icon('phone') + '<span>Appeler</span></a>' : '') +
			(c.email ? '<a class="btn" href="mailto:' + esc(c.email) + '" data-mail="' + c.id + '">' + icon('mail') + '<span>Courriel</span></a>' : '') +
			(c.phone ? '<a class="btn" href="sms:' + esc(tel(c.phone)) + '" data-sms="' + c.id + '">' + icon('sms') + '<span>Texto</span></a>' : '') +
			'</div></header>' +
			'<div class="db">' +
			'<div class="stepper" role="group" aria-label="Étape">' + STAGE_ORDER.map(function (s, i) {
				return '<button class="step' + (s === c.stage ? ' on' : '') + (i < idx && c.stage !== 'perdu' && s !== 'perdu' ? ' past' : '') + '" style="--c:' + esc(COLORS[s]) + '" data-stage-set="' + s + '">' + esc(SHORT[s] || STAGES[s]) + '</button>';
			}).join('') + '</div>' +
			'<div id="callflow"></div>' +
			'<section class="next"><h3>Prochaine action</h3>' +
			(open.length ? '<ul class="tasks">' + open.map(taskRow).join('') + '</ul>' : '<p class="next-none">Aucune relance prévue. Un prospect sans prochaine action est un prospect qu’on oublie.</p>') +
			'<form class="addtask" id="addtask"><input name="title" placeholder="Ajouter une relance, ex. envoyer la soumission" required>' +
			'<div class="presets">' + presets('due') + '</div><button class="btn btn-sm">Planifier</button></form></section>' +
			'<section class="compose"><div class="tabs" role="tablist"><button type="button" class="tab on" data-kind="note">Note</button><button type="button" class="tab" data-kind="call">Appel</button><button type="button" class="tab" data-kind="email">Courriel</button></div>' +
			'<form id="compose"><textarea name="body" rows="3" placeholder="Ce qui s’est dit, ce qui a été décidé…"></textarea><div class="compose-f"><span class="muted" id="kindhint">Visible seulement par toi</span><button class="btn btn-accent btn-sm">Enregistrer</button></div></form></section>' +
			'<section class="timeline"><h3>Historique</h3>' + timeline(r.activities) + '</section>' +
			(done.length ? '<details class="done-tasks"><summary>' + done.length + ' tâche' + (done.length > 1 ? 's' : '') + ' terminée' + (done.length > 1 ? 's' : '') + '</summary><ul class="tasks">' + done.map(taskRow).join('') + '</ul></details>' : '') +
			'<section class="details"><h3>Coordonnées</h3><form id="details" class="grid">' +
			field('name', 'Nom', c.name) + field('company', 'Entreprise', c.company) + field('phone', 'Téléphone', c.phone, 'tel') + field('email', 'Courriel', c.email, 'email') +
			field('city', 'Ville', c.city) + field('website', 'Site web', c.website, 'url') + field('value', 'Valeur estimée ($)', c.value || '', 'text') + field('kind', 'Type de demande', c.kind) +
			'<label class="full">Notes permanentes<textarea name="notes" rows="3">' + esc(c.notes) + '</textarea></label>' +
			'<div class="full form-f"><button class="btn btn-sm" type="submit">Enregistrer les coordonnées</button><button type="button" class="btn-link danger" data-act="delete">Supprimer ce contact</button></div></form></section>' +
			'</div>';
		bindDrawer();
		if (opts.call) { showCallFlow(opts.task); }
	}

	function field(n, l, v, type) { return '<label>' + esc(l) + '<input name="' + n + '" type="' + (type || 'text') + '" value="' + esc(v) + '"></label>'; }

	function presets(name) {
		var opts = [['+0', 'Aujourd’hui'], ['+1', 'Demain'], ['+3', 'Dans 3 jours'], ['+5', 'Dans 1 semaine']];
		return opts.map(function (o, i) { return '<label class="preset"><input type="radio" name="' + name + '" value="' + o[0] + '"' + (i === 1 ? ' checked' : '') + '><span>' + o[1] + '</span></label>'; }).join('') +
			'<label class="preset preset-date"><input type="radio" name="' + name + '" value="custom"><span>Date…</span></label><input type="date" class="preset-picker" name="' + name + '_date" hidden>';
	}
	function readDue(form, name) {
		var v = (form.querySelector('input[name="' + name + '"]:checked') || {}).value || '+1';
		if (v === 'custom') { return form.querySelector('input[name="' + name + '_date"]').value || '+1'; }
		if (v === '+0') { var d = new Date(); d.setHours(d.getHours() + 1, 0, 0, 0); return sqlDate(d).slice(0, 16).replace(' ', 'T'); }
		return v;
	}

	function taskRow(t) {
		var di = dueInfo(t.due_at), dn = !!t.done_at;
		return '<li class="task' + (dn ? ' is-done' : '') + '"><button class="tick' + (dn ? ' on' : '') + '" data-' + (dn ? 'undo' : 'done') + '="' + t.id + '" aria-label="' + (dn ? 'Rouvrir' : 'Marquer comme faite') + '"></button>' +
			'<div><strong>' + esc(t.title) + '</strong><span class="due ' + (dn ? '' : di.cls) + '">' + esc(dn ? 'Faite ' + ago(t.done_at) : (di.text || 'Sans date')) + '</span></div>' +
			(dn ? '' : '<button class="btn btn-ghost btn-sm" data-snooze="' + t.id + '">Reporter</button>') + '</li>';
	}

	var ACT_IC = { note: 'note', call: 'phone', email: 'mail', sms: 'sms', rdv: 'today', maquette: 'sparkle', form: 'mail', stage: 'pipeline', task: 'check', meta: 'bolt', google: 'bolt', zoho: 'contacts' };
	function timeline(list) {
		if (!list.length) { return '<p class="muted">Rien pour l’instant.</p>'; }
		var out = '', last = '';
		list.forEach(function (a) {
			var d = parse(a.created_at), k = ymd(d);
			if (k !== last) { out += '<li class="tl-day">' + esc(dayLabel(d)) + '</li>'; last = k; }
			out += '<li class="tl tl-' + esc(a.type) + '"><span class="tl-ic">' + icon(ACT_IC[a.type] || 'note') + '</span><div class="tl-b"><div class="tl-h"><strong>' + esc(a.title || a.type) + '</strong><time>' + esc(hm(d)) + '</time>' +
				(a.type === 'note' ? '<button class="tl-del" data-delact="' + a.id + '" aria-label="Supprimer la note">' + icon('trash') + '</button>' : '') + '</div>' +
				(a.body ? '<p>' + esc(a.body).replace(/(https?:\/\/[^\s<]+)/g, '<a href="$1" target="_blank" rel="noopener">$1</a>').replace(/\n/g, '<br>') + '</p>' : '') + '</div></li>';
		});
		return '<ol class="tl-list">' + out + '</ol>';
	}

	/* Flux d'appel : le résultat en un clic, la relance proposée automatiquement. */
	var OUTCOMES = [
		{ k: 'reached', t: 'Joint', next: 'Faire le suivi', due: '+3' },
		{ k: 'voicemail', t: 'Message laissé', next: 'Rappeler', due: '+1' },
		{ k: 'noanswer', t: 'Pas de réponse', next: 'Rappeler', due: '+1' },
		{ k: 'lost', t: 'Pas intéressé', next: '', due: '' },
		{ k: 'wrong', t: 'Mauvais numéro', next: 'Trouver le bon numéro', due: '+1' }
	];
	function showCallFlow(taskId) {
		var box = $('#callflow'); if (!box) { return; }
		box.innerHTML = '<section class="callflow"><div class="cf-h">' + icon('phone') + '<div><h3>Comment s’est passé l’appel ?</h3><p class="muted">Un clic enregistre l’appel et prépare la relance.</p></div><button class="btn-link" data-act="cf-close">Plus tard</button></div>' +
			'<div class="cf-opts">' + OUTCOMES.map(function (o) { return '<button class="cf-o cf-' + o.k + '" data-outcome="' + o.k + '">' + esc(o.t) + '</button>'; }).join('') + '</div><form class="cf-more" id="cfform" hidden data-task="' + (taskId || '') + '"></form></section>';
		box.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
	}
	function chooseOutcome(k) {
		var o = OUTCOMES.filter(function (x) { return x.k === k; })[0], f = $('#cfform');
		$$('.cf-o').forEach(function (b) { b.classList.toggle('on', b.dataset.outcome === k); });
		f.hidden = false; f.dataset.outcome = k;
		f.innerHTML = '<textarea name="body" rows="2" placeholder="' + (k === 'reached' ? 'Ce qui s’est dit (facultatif)' : 'Note (facultatif)') + '"></textarea>' +
			(o.next ? '<label class="cf-next"><input type="checkbox" name="has_next" checked> Planifier : <input name="next" value="' + esc(o.next) + '"></label><div class="presets">' + presets('cfdue') + '</div>' : '<p class="muted">Le contact passera en « Perdu ». Tu pourras toujours le rouvrir.</p>') +
			'<div class="compose-f"><span></span><button class="btn btn-accent btn-sm">Enregistrer l’appel</button></div>';
		if (o.due) { var r = f.querySelector('input[name="cfdue"][value="' + o.due + '"]'); if (r) { r.checked = true; } }
	}

	function bindDrawer() {
		var d = $('#drawer .drawer'), c = S.drawer.contact;
		var kind = 'note';
		$$('.tab', d).forEach(function (t) {
			t.addEventListener('click', function () {
				kind = t.dataset.kind; $$('.tab', d).forEach(function (x) { x.classList.toggle('on', x === t); });
				if (kind === 'call') { showCallFlow(); }
				$('#kindhint').textContent = kind === 'note' ? 'Visible seulement par toi' : (kind === 'email' ? 'Note un courriel envoyé hors du CRM' : 'Ou choisis le résultat ci-dessus');
			});
		});
		$('#compose').addEventListener('submit', function (e) {
			e.preventDefault(); var body = e.target.body.value.trim();
			if (!body && kind === 'note') { e.target.body.focus(); return; }
			submitLog({ kind: kind === 'call' ? 'call' : kind, body: body }, kind === 'note' ? 'Note ajoutée' : 'Enregistré');
		});
		$('#addtask').addEventListener('submit', function (e) {
			e.preventDefault();
			api('POST', 'tasks', { contact_id: c.id, title: e.target.title.value, due: readDue(e.target, 'due') }).then(function () { toast('Relance planifiée'); reloadDrawer(); refreshBoot(); }).catch(fail);
		});
		$('#details').addEventListener('submit', function (e) {
			e.preventDefault(); var fd = new FormData(e.target), body = {};
			fd.forEach(function (v, k) { body[k] = v; });
			api('PATCH', 'contacts/' + c.id, body).then(function (r) { S.drawer = r; renderDrawer({}); toast('Coordonnées enregistrées'); rerender(); }).catch(fail);
		});
	}

	function submitLog(body, msg) {
		var id = S.drawer.contact.id;
		return api('POST', 'contacts/' + id + '/log', body).then(function (r) { S.drawer = r; renderDrawer({}); toast(msg); refreshBoot(); rerender(); }).catch(fail);
	}
	function reloadDrawer() { if (S.drawer) { return openContact(S.drawer.contact.id); } }

	/* ---------- Fenêtres : nouveau contact, report, recherche ---------- */
	function modal(html, onReady) {
		var m = $('#modal'); m.hidden = false;
		m.innerHTML = '<div class="modal-scrim" data-act="mclose"></div><div class="modal" role="dialog" aria-modal="true">' + html + '</div>';
		var first = m.querySelector('input,select,textarea,button'); if (first) { setTimeout(function () { first.focus(); }, 30); }
		if (onReady) { onReady(m); }
	}
	function closeModal() { var m = $('#modal'); m.hidden = true; m.innerHTML = ''; }

	function newContact() {
		modal('<h2>Nouveau contact</h2><form id="newc" class="grid">' + field('name', 'Nom', '') + field('company', 'Entreprise', '') + field('phone', 'Téléphone', '', 'tel') + field('email', 'Courriel', '', 'email') +
			'<label>Source<select name="source">' + ['manuel', 'form', 'meta', 'google', 'rdv'].map(function (k) { return '<option value="' + k + '">' + esc(k === 'manuel' ? 'Bouche-à-oreille, appel, autre' : SRC[k].t) + '</option>'; }).join('') + '</select></label>' +
			field('value', 'Valeur estimée ($)', '') +
			'<label class="full"><span><input type="checkbox" name="call" checked> Planifier un premier appel</span></label><div class="full presets">' + presets('due') + '</div>' +
			'<div class="full form-f"><button type="button" class="btn btn-ghost" data-act="mclose">Annuler</button><button class="btn btn-accent">Créer le contact</button></div></form>', function (m) {
			$('#newc').addEventListener('submit', function (e) {
				e.preventDefault(); var f = e.target, body = {};
				['name', 'company', 'phone', 'email', 'source', 'value'].forEach(function (k) { body[k] = f[k].value; });
				if (f.call.checked) { body.task = { title: 'Premier appel', due: readDue(f, 'due') }; }
				api('POST', 'contacts', body).then(function (r) { closeModal(); toast('Contact créé'); refreshBoot(); go('#/contact/' + r.contact.id); }).catch(fail);
			});
		});
	}

	function snooze(taskId) {
		modal('<h2>Reporter la relance</h2><form id="snz"><div class="presets presets-lg">' + presets('due') + '</div><div class="form-f"><button type="button" class="btn btn-ghost" data-act="mclose">Annuler</button><button class="btn btn-accent">Reporter</button></div></form>', function () {
			$('#snz').addEventListener('submit', function (e) {
				e.preventDefault();
				api('PATCH', 'tasks/' + taskId, { due: readDue(e.target, 'due') }).then(function () { closeModal(); toast('Relance reportée'); refreshBoot(true); if (S.drawer) { reloadDrawer(); } }).catch(fail);
			});
		});
	}

	function palette() {
		modal('<div class="pal"><label class="field-search">' + icon('search') + '<input id="pq" placeholder="Rechercher un contact" autocomplete="off"></label><ul id="pres" class="pal-res"><li class="muted">Tape un nom, une entreprise, un numéro…</li></ul></div>', function () {
			var t, sel = 0;
			var input = $('#pq');
			function draw(rows) {
				$('#pres').innerHTML = rows.length ? rows.map(function (c, i) { return '<li class="pal-i' + (i === sel ? ' on' : '') + '" data-pick="' + c.id + '">' + avatar(c, 'sm') + '<div><strong>' + esc(label(c)) + '</strong><span class="muted">' + esc([c.company, c.phone || c.email].filter(Boolean).join(' · ')) + '</span></div>' + pill(c.stage) + '</li>'; }).join('') : '<li class="muted">Aucun résultat</li>';
			}
			input.addEventListener('input', function () { clearTimeout(t); var v = input.value.trim(); if (!v) { return; } t = setTimeout(function () { api('GET', 'search?s=' + encodeURIComponent(v)).then(function (r) { sel = 0; draw(r.rows); }); }, 180); });
			input.addEventListener('keydown', function (e) {
				var items = $$('.pal-i');
				if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { e.preventDefault(); if (!items.length) { return; } sel = (sel + (e.key === 'ArrowDown' ? 1 : items.length - 1)) % items.length; items.forEach(function (x, i) { x.classList.toggle('on', i === sel); }); }
				if (e.key === 'Enter' && items[sel]) { e.preventDefault(); closeModal(); go('#/contact/' + items[sel].dataset.pick); }
			});
		});
	}

	/* ---------- Notifications sur l'appareil (Web Push) ---------- */
	var IOS = /iPhone|iPad|iPod/.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
	var STANDALONE = (window.matchMedia && window.matchMedia('(display-mode: standalone)').matches) || navigator.standalone === true;
	function pushSupported() { return 'serviceWorker' in navigator && 'PushManager' in window && 'Notification' in window && !!(S.boot.push && S.boot.push.key); }
	function store(k, v) { try { if (v === undefined) { return localStorage.getItem(k); } localStorage.setItem(k, v); } catch (e) { return null; } }
	function b64ToU8(s) {
		var b = atob((s + '='.repeat((4 - s.length % 4) % 4)).replace(/-/g, '+').replace(/_/g, '/'));
		var a = new Uint8Array(b.length); for (var i = 0; i < b.length; i++) { a[i] = b.charCodeAt(i); } return a;
	}
	function swReg() {
		var scope = new URL(S.boot.sw, location.href).pathname.replace(/[^\/]*$/, '');
		return navigator.serviceWorker.register(S.boot.sw, { scope: scope }).then(function () { return navigator.serviceWorker.ready; });
	}
	function currentSub() {
		if (!pushSupported() || DEMO) { return Promise.resolve(null); }
		return navigator.serviceWorker.getRegistration(new URL(S.boot.sw, location.href).pathname.replace(/[^\/]*$/, '')).then(function (r) { return r ? r.pushManager.getSubscription() : null; }).catch(function () { return null; });
	}
	function pushEnable() {
		if (DEMO) { toast('Mode démo : rien n’est activé.'); return Promise.resolve(); }
		return Notification.requestPermission().then(function (p) {
			if (p !== 'granted') { var b0 = $('#setupbox'); if (b0) { renderSetup(b0); } throw new Error(p === 'denied' ? 'Avis bloqués : suis les étapes affichées pour les débloquer.' : 'Avis pas encore autorisés.'); }
			return swReg();
		}).then(function (reg) {
			return reg.pushManager.getSubscription().then(function (sub) { return sub || reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: b64ToU8(S.boot.push.key) }); });
		}).then(function (sub) { return api('POST', 'push', sub.toJSON()); })
			.then(function (r) { S.boot.push.devices = r.devices; return api('POST', 'push/test'); })
			.then(function (r) { toast(r && r.sent ? 'C’est activé : une notification de test arrive' : 'Avis activés'); hideBannerIfActive(); var b1 = $('#setupbox'); if (b1) { renderSetup(b1); } });
	}
	function pushDisable() {
		return currentSub().then(function (sub) {
			if (!sub) { return; }
			var ep = sub.endpoint;
			return sub.unsubscribe().then(function () { return api('DELETE', 'push', { endpoint: ep }); }).then(function (r) { S.boot.push.devices = r.devices; });
		}).then(function () { toast('Notifications désactivées sur cet appareil'); });
	}
	/* Parcours guidé « Mettre le CRM sur ton téléphone » : il détecte où en est l'appareil
	   (installé ou non, permission accordée, refusée, abonnement actif) et n'affiche que la prochaine étape. */
	var UA = navigator.userAgent;
	var ANDROID = /Android/i.test(UA);
	var IOS_SAFARI = IOS && !/CriOS|FxiOS|EdgiOS|OPiOS/.test(UA);
	var MOBILE = ANDROID || IOS;
	var installEvt = null;
	window.addEventListener('beforeinstallprompt', function (e) { e.preventDefault(); installEvt = e; var b = $('#setupbox'); if (b) { renderSetup(b); } });
	window.addEventListener('appinstalled', function () { installEvt = null; store('lmcrm_installed', '1'); var b = $('#setupbox'); if (b) { renderSetup(b); } });
	document.addEventListener('visibilitychange', function () { if (!document.hidden) { var b = $('#setupbox'); if (b) { renderSetup(b); } } });
	function appName() { return (S.boot && S.boot.brand.name) || 'CRM'; }
	function steps(list) { return '<ol class="guide">' + list.map(function (t) { return '<li>' + t + '</li>'; }).join('') + '</ol>'; }
	function stepper(n) {
		return '<div class="g-steps"><span class="' + (n === 1 ? 'on' : 'done') + '">' + (n === 1 ? '1' : icon('check')) + '</span><b>Installer l’app</b><i></i><span class="' + (n === 2 ? 'on' : (n > 2 ? 'done' : '')) + '">' + (n > 2 ? icon('check') : '2') + '</span><b>Activer les avis</b></div>';
	}
	function denyHelp() {
		var n = '« ' + esc(appName()) + ' »';
		if (ANDROID && STANDALONE) { return steps(['Sur ton écran d’accueil, <strong>appuie longtemps sur l’icône ' + n + '</strong>.', 'Touche <strong>Infos sur l’appli</strong> (ou le petit ⓘ).', 'Touche <strong>Notifications</strong> et active l’interrupteur.', 'Reviens ici : la page se met à jour toute seule.']); }
		if (ANDROID) { return steps(['Touche la petite icône <strong>à gauche de l’adresse</strong>, en haut de Chrome.', 'Touche <strong>Autorisations</strong>, puis <strong>Notifications</strong>.', 'Choisis <strong>Autoriser</strong> et reviens ici.']); }
		if (IOS) { return steps(['Ouvre l’app <strong>Réglages</strong> de l’iPhone.', 'Touche <strong>Notifications</strong>, puis ' + n + '.', 'Active <strong>Autoriser les notifications</strong> et reviens ici.']); }
		return steps(['Clique sur l’icône <strong>à gauche de l’adresse</strong> du site, en haut du navigateur.', 'Mets <strong>Notifications</strong> sur <strong>Autoriser</strong>.', 'Recharge la page.']);
	}
	function installHelp() {
		var n = '« ' + esc(appName()) + ' »';
		if (ANDROID) {
			return installEvt ? '<p>Une touche suffit :</p><button class="btn btn-accent btn-lg" data-act="install">' + icon('plus') + 'Installer l’app ' + esc(appName()) + '</button><p class="muted small">Puis touche <strong>Installer</strong> dans la fenêtre de Chrome.</p>'
				: steps(['Touche les <strong>trois points ⋮</strong> tout en haut à droite de Chrome.', 'Touche <strong>Ajouter à l’écran d’accueil</strong> (selon la version : <strong>Installer l’application</strong>).', 'Chrome propose deux choix : prends <strong>Installer</strong>, pas « Créer un raccourci ».', 'Ouvre ' + n + ' depuis ton écran d’accueil et reviens ici.']);
		}
		if (IOS && !IOS_SAFARI) { return '<p>Sur iPhone, l’installation se fait depuis <strong>Safari</strong>. Copie l’adresse, ouvre Safari et colle-la.</p><button class="btn" data-act="copylink">Copier l’adresse</button>'; }
		return steps(['Touche le bouton <strong>Partager</strong> de Safari : le carré avec une flèche vers le haut, en bas de l’écran.', 'Fais défiler et touche <strong>Sur l’écran d’accueil</strong>.', 'Touche <strong>Ajouter</strong>.', 'Ouvre ' + n + ' depuis ton écran d’accueil et reviens ici.']);
	}
	function renderSetup(box) {
		if (DEMO) { box.innerHTML = '<p class="muted">En mode démo, rien n’est installé ni activé. Dans le vrai CRM, ce panneau guide l’installation sur le téléphone en deux étapes.</p>'; return; }
		var here = !MOBILE ? '' : null;
		// Ordinateur : on envoie vers le téléphone avec un code QR, et on propose aussi l'activation sur l'ordinateur.
		if (!MOBILE) {
			box.innerHTML = '<div class="qr-row"><div id="qr" class="qr" aria-label="Code QR"></div><div><h3>Sur ton téléphone</h3>' +
				steps(['Ouvre l’<strong>appareil photo</strong> de ton téléphone et vise ce code.', 'Touche le lien qui apparaît : le CRM s’ouvre.', 'Laisse-toi guider : deux étapes, une minute.']) + '</div></div>' +
				'<div class="here"><h3>Sur cet ordinateur</h3><div id="herebox"><p class="muted">Vérification…</p></div></div>';
			drawQR($('#qr'), S.boot.app_url || location.href.split('#')[0]);
			here = $('#herebox');
		}
		if (MOBILE && !STANDALONE) {
			box.innerHTML = stepper(1) + '<h3>Installe l’app sur ton écran d’accueil</h3><p class="muted">Elle s’ouvre en plein écran, comme une vraie application, et c’est elle qui reçoit les avis.</p>' + installHelp() +
				(ANDROID ? '<p class="muted small alt">Déjà installée ? Ouvre ' + esc(appName()) + ' depuis ton écran d’accueil plutôt que depuis Chrome.</p>' : '');
			return;
		}
		var target = here || box;
		if (!pushSupported()) { target.innerHTML = '<p class="muted">Ce navigateur ne reçoit pas de notifications. Utilise Chrome, Edge, Firefox ou Safari à jour.</p>'; return; }
		currentSub().then(function (sub) {
			var head = MOBILE ? stepper(sub ? 3 : 2) : '';
			if (sub) {
				target.innerHTML = head + '<p class="ok-line">' + icon('check') + 'Les avis sont activés sur ' + (MOBILE ? 'ce téléphone' : 'cet ordinateur') + '.</p><div class="row-btns"><button class="btn" data-act="pushtest">Envoyer un test</button><button class="btn btn-ghost" data-act="pushoff">Désactiver ici</button></div>';
			} else if (Notification.permission === 'denied') {
				target.innerHTML = head + '<h3>Les avis sont bloqués' + (MOBILE ? ' sur ce téléphone' : '') + '</h3><p class="muted">Le réglage se fait en dehors du CRM, une seule fois :</p>' + denyHelp();
			} else {
				target.innerHTML = head + (MOBILE ? '<h3>Active les avis</h3>' : '') + '<button class="btn btn-accent btn-lg" data-act="pushon">' + icon('bell') + 'Activer les avis</button><p class="muted small">Touche ensuite <strong>Autoriser</strong> dans la fenêtre qui s’ouvre. Une notification de test arrive tout de suite.</p>';
			}
		});
	}
	function drawQR(el, url) {
		if (!el) { return; }
		var go = function () { try { var q = qrcode(0, 'M'); q.addData(url); q.make(); el.innerHTML = q.createSvgTag({ cellSize: 4, margin: 2, scalable: true }); } catch (e) { el.innerHTML = '<p class="muted small">' + esc(url) + '</p>'; } };
		if (window.qrcode) { go(); return; }
		var s = document.createElement('script'); s.src = CFG.assets + 'qrcode.min.js'; s.onload = go; s.onerror = go; document.head.appendChild(s);
	}
	function pushBanner() {
		if (DEMO || store('lmcrm_nopush')) { return ''; }
		if (!MOBILE && (S.boot.push.devices || []).length) { return ''; }
		var t = MOBILE && !STANDALONE ? ['Installe ' + appName() + ' sur ton téléphone', 'Deux étapes, une minute : chaque nouveau prospect arrivera en notification, avec sa fiche à un toucher.', 'C’est parti']
			: (MOBILE ? ['Active les avis sur ce téléphone', 'Chaque nouveau prospect arrivera en notification à la seconde, avec un bouton pour l’appeler.', 'Activer']
				: ['Reçois chaque nouveau prospect sur ton téléphone', 'Scanne un code avec ton téléphone : il te guide en deux étapes.', 'Voir comment']);
		return '<section class="banner" id="pushbanner"><span class="banner-ic">' + icon('bell') + '</span><div><strong>' + esc(t[0]) + '</strong><p>' + esc(t[1]) + '</p></div><button class="btn btn-accent btn-sm" data-act="notif">' + esc(t[2]) + '</button><button class="btn btn-ghost btn-icon" data-act="nopush" aria-label="Masquer">' + icon('x') + '</button></section>';
	}
	function hideBannerIfActive() { currentSub().then(function (sub) { var b = $('#pushbanner'); if (sub && b) { b.remove(); } var d = $('.bell-dot'); if (d) { d.hidden = !!sub; } }); }
	function notifPanel() {
		var devs = (S.boot.push.devices || []);
		modal('<h2>' + (MOBILE ? 'Recevoir les prospects sur ce téléphone' : 'Recevoir les prospects sur ton téléphone') + '</h2><div id="setupbox" class="setupbox"><p class="muted">Vérification…</p></div>' +
			(devs.length ? '<h3 class="sub-h">Appareils déjà activés</h3><ul class="devs">' + devs.map(function (d) { return '<li>' + icon('bell') + esc(d.device) + '<span class="muted">depuis ' + esc(ago(d.created)) + '</span></li>'; }).join('') + '</ul>' : '') +
			'<div class="form-f"><span></span><button class="btn btn-ghost" data-act="mclose">Fermer</button></div>', function () { renderSetup($('#setupbox')); });
	}

	/* ---------- Assistant d'installation ---------- */
	var W = null;
	var SWATCHES = ['#FF7020', '#E5484D', '#DB2777', '#7C3AED', '#2563EB', '#0E9F8E', '#11A36B', '#13213D'];
	function wizard() {
		var b = S.boot;
		W = W || { step: 0, brand: { name: b.brand.name, color: b.brand.color, logo: b.brand.logo || '' }, template: b.template || 'general', notify: b.notify || '' };
		var steps = ['Ton entreprise', 'Ton métier', 'Les avis', 'Tes sources'];
		var html = '<div class="wiz-in"><header class="wiz-h"><span class="brand-mark" style="background:' + esc(W.brand.color) + '">' + esc(mark(W.brand.name)) + '</span><ol class="wiz-steps">' +
			steps.map(function (t, i) { return '<li class="' + (i === W.step ? 'on' : (i < W.step ? 'done' : '')) + '"><span>' + (i < W.step ? icon('check') : (i + 1)) + '</span>' + esc(t) + '</li>'; }).join('') + '</ol>' +
			(b.setup ? '<button class="btn btn-ghost btn-icon" data-act="wizclose" aria-label="Fermer">' + icon('x') + '</button>' : '') + '</header><div class="wiz-body">';
		if (W.step === 0) {
			html += '<h1>Bienvenue dans ton CRM</h1><p class="lead-p">Quatre réglages et c’est prêt. Tout se modifie ensuite.</p>' +
				'<label class="wf">Nom affiché<input id="wname" value="' + esc(W.brand.name) + '" maxlength="40"></label>' +
				'<div class="wf"><span>Couleur</span><div class="swatches">' + SWATCHES.map(function (c) { return '<button type="button" class="sw' + (c.toLowerCase() === W.brand.color.toLowerCase() ? ' on' : '') + '" style="background:' + c + '" data-swatch="' + c + '" aria-label="' + c + '"></button>'; }).join('') +
				'<label class="sw sw-custom" title="Autre couleur"><input type="color" id="wcolor" value="' + esc(W.brand.color) + '"></label></div></div>' +
				'<label class="wf">Logo carré (adresse de l’image, facultatif)<input id="wlogo" value="' + esc(W.brand.logo) + '" placeholder="https://…"></label>';
		} else if (W.step === 1) {
			html += '<h1>Quel est ton métier ?</h1><p class="lead-p">Le pipeline suit les étapes de ta vente. Tu pourras renommer, ajouter ou retirer des étapes.</p><div class="tpls">' +
				b.templates.map(function (t) {
					return '<button type="button" class="tpl' + (t.key === W.template ? ' on' : '') + '" data-tpl="' + t.key + '"><strong>' + esc(t.label) + '</strong><span class="muted">' + esc(t.hint) + '</span><span class="tpl-st">' + t.stages.map(function (x) { return '<i>' + esc(x) + '</i>'; }).join('') + '</span></button>';
				}).join('') + '</div>';
		} else if (W.step === 2) {
			html += '<h1>Comment veux-tu être averti ?</h1><p class="lead-p">Un prospect rappelé dans les cinq minutes signe bien plus souvent qu’un prospect rappelé le lendemain.</p>' +
				'<div class="wcard"><strong>' + icon('bell') + 'Sur ton téléphone</strong><p class="muted">Une notification par nouveau prospect, avec un lien vers sa fiche.</p>' +
				'<div id="setupbox" class="setupbox"></div></div>' +
				'<div class="wcard"><strong>' + icon('mail') + 'Par courriel</strong><p class="muted">Chaque prospect et, chaque matin, la liste des relances du jour.</p><input id="wmail" type="email" value="' + esc(W.notify) + '"></div>';
		} else {
			var si = b.sources_info || {};
			var item = function (ok, t, d) { return '<li class="' + (ok ? 'ok' : '') + '"><span class="tick-s">' + (ok ? icon('check') : '') + '</span><div><strong>' + esc(t) + '</strong><span class="muted">' + d + '</span></div></li>'; };
			html += '<h1>D’où viendront tes prospects ?</h1><p class="lead-p">Tout ce qui arrive par ces canaux tombe dans « À traiter maintenant ».</p><ul class="srcs">' +
				item((si.forms || []).length > 0, 'Formulaires du site', (si.forms || []).length ? esc(si.forms.join(', ')) + ' : captés automatiquement.' : 'Aucun formulaire détecté. Le code court [lmweb_crm_form] en ajoute un.') +
				item(!!si.meta, 'Publicités Meta (Facebook, Instagram)', si.meta ? 'Branché : relève toutes les 15 minutes.' : 'À brancher dans les réglages, avec un accès à la Page.') +
				item(false, 'Publicités Google Ads', 'Une adresse de webhook à coller dans le formulaire de prospects Google (voir les réglages).') +
				item(!!si.rdv, 'Prise de rendez-vous en ligne', si.rdv ? 'LM Web Rendez-vous est branché.' : 'Disponible avec LM Web Rendez-vous.') +
				'</ul>' + (CFG.settings ? '<p><a class="btn-link" href="' + esc(CFG.settings) + '">Ouvrir les réglages des sources</a></p>' : '');
		}
		html += '</div><footer class="wiz-f">' + (W.step ? '<button class="btn btn-ghost" data-act="wizback">Retour</button>' : '<span></span>') +
			'<button class="btn btn-accent" data-act="wiznext">' + (W.step < 3 ? 'Continuer' : 'Ouvrir mon CRM') + '</button></footer></div>';
		var el = $('#wiz'); if (!el) { el = document.createElement('div'); el.id = 'wiz'; el.className = 'wiz'; root.appendChild(el); }
		el.innerHTML = html;
		root.style.setProperty('--accent', W.brand.color);
		if ($('#setupbox')) { renderSetup($('#setupbox')); }
	}
	function wizRead() {
		if (W.step === 0) { W.brand.name = ($('#wname') || {}).value || W.brand.name; W.brand.logo = ($('#wlogo') || {}).value || ''; }
		if (W.step === 2) { W.notify = ($('#wmail') || {}).value || W.notify; }
	}
	function wizFinish() {
		var body = { brand: W.brand, template: W.template, notify: W.notify, done: 1 };
		return api('POST', 'setup', body).then(function (b) { S.boot = b; W = null; shell(); location.hash = '#/'; route(); toast('Ton CRM est prêt'); });
	}
	function wizClose() { var el = $('#wiz'); if (el) { el.remove(); } W = null; root.style.setProperty('--accent', S.boot.brand.color); if (location.hash === '#/setup') { history.replaceState(null, '', '#/'); } }

	/* ---------- Toasts ---------- */
	function toast(msg, undo) {
		var el = document.createElement('div'); el.className = 'toast';
		el.innerHTML = '<span>' + esc(msg) + '</span>' + (undo ? '<button>Annuler</button>' : '');
		$('#toasts').appendChild(el);
		var timer = setTimeout(function () { el.classList.add('out'); setTimeout(function () { el.remove(); }, 300); }, undo ? 6000 : 3000);
		if (undo) { el.querySelector('button').addEventListener('click', function () { clearTimeout(timer); el.remove(); undo(); }); }
	}
	function fail(e) { toast((e && e.message) || 'Une erreur est survenue. Réessaie.'); }

	/* ---------- Données et routage ---------- */
	function refreshBoot(rerenderToday) {
		return api('GET', 'boot').then(function (b) { S.boot = b; updateBadge(); if (S.view === 'today' && (rerenderToday !== false)) { viewToday(); } });
	}
	function rerender() { if (S.view === 'contacts') { loadContacts(); } else if (S.view === 'pipeline') { viewPipeline(); } }
	function go(h) { if (location.hash === h) { route(); } else { location.hash = h; } }

	function route() {
		var h = location.hash.replace(/^#\/?/, '');
		if (h === 'setup') { if (!$('#view').innerHTML) { S.view = 'today'; viewToday(); } wizard(); return; }
		if ($('#wiz')) { wizClose(); }
		var m = h.match(/^contact\/(\d+)/);
		if (m) { if (!$('#view').innerHTML) { S.view = 'today'; viewToday(); } openContact(m[1]); return; }
		if (S.drawer) { closeDrawer(); }
		S.view = ['pipeline', 'contacts'].indexOf(h) >= 0 ? h : 'today';
		if (S.view === 'pipeline') { viewPipeline(); } else if (S.view === 'contacts') { viewContacts(); } else { viewToday(); }
	}

	/* ---------- Événements globaux ---------- */
	document.addEventListener('click', function (e) {
		var t = e.target;
		var a = t.closest('[data-act]');
		if (a) {
			var act = a.dataset.act;
			if (act === 'close') { closeDrawer(); }
			if (act === 'mclose') { closeModal(); }
			if (act === 'new') { newContact(); }
			if (act === 'palette') { palette(); }
			if (act === 'cf-close') { $('#callflow').innerHTML = ''; }
			if (act === 'notif') { e.preventDefault(); notifPanel(); }
			if (act === 'nopush') { store('lmcrm_nopush', '1'); var bn = a.closest('.banner'); if (bn) { bn.remove(); } }
			if (act === 'pushon') { a.disabled = true; pushEnable().then(function () { if ($('#modal') && !$('#modal').hidden) { notifPanel(); } if (W) { wizard(); } }).catch(function (er) { a.disabled = false; fail(er); }); }
			if (act === 'pushoff') { pushDisable().then(function () { var b2 = $('#setupbox'); if (b2) { renderSetup(b2); } }).catch(fail); }
			if (act === 'install' && installEvt) { installEvt.prompt(); installEvt.userChoice.then(function (c) { if (c.outcome === 'accepted') { installEvt = null; var b3 = $('#setupbox'); if (b3) { b3.innerHTML = stepper(2) + '<h3>C’est installé</h3><p>Ouvre <strong>' + esc(appName()) + '</strong> depuis ton écran d’accueil : l’étape 2 t’y attend.</p>'; } } }); }
			if (act === 'copylink') { var u = (S.boot.app_url || location.href.split('#')[0]); (navigator.clipboard ? navigator.clipboard.writeText(u) : Promise.reject()).then(function () { toast('Adresse copiée'); }).catch(function () { window.prompt('Copie cette adresse :', u); }); }
			if (act === 'pushtest') { api('POST', 'push/test').then(function (r) { toast(r.sent ? 'Notification envoyée' : 'Aucun appareil n’a reçu le test' + (r.errors && r.errors.length ? ' (' + r.errors.join(', ') + ')' : '')); }).catch(fail); }
			if (act === 'wiznext') { wizRead(); if (W.step < 3) { W.step++; wizard(); } else { a.disabled = true; wizFinish().catch(function (er) { a.disabled = false; fail(er); }); } }
			if (act === 'wizback') { wizRead(); W.step = Math.max(0, W.step - 1); wizard(); }
			if (act === 'wizclose') { wizClose(); }
			if (act === 'delete' && S.drawer) {
				if (window.confirm('Supprimer définitivement ce contact, son historique et ses tâches ?')) {
					api('DELETE', 'contacts/' + S.drawer.contact.id).then(function () { closeDrawer(); toast('Contact supprimé'); refreshBoot(); rerender(); }).catch(fail);
				}
			}
			return;
		}
		var call = t.closest('[data-call]');
		if (call) {
			var cid = call.dataset.call, tid = call.dataset.task;
			setTimeout(function () { openContact(cid, { call: true, task: tid }); if (location.hash !== '#/contact/' + cid) { history.replaceState(null, '', '#/contact/' + cid); } }, 300);
			return;
		}
		var mail = t.closest('[data-mail],[data-sms]');
		if (mail) {
			var mid = mail.dataset.mail || mail.dataset.sms, k = mail.dataset.mail ? 'email' : 'sms';
			setTimeout(function () {
				var after = function () { submitLog({ kind: k, body: '' }, k === 'email' ? 'Courriel noté' : 'Texto noté'); };
				if (S.drawer && S.drawer.contact.id === +mid) { after(); } else { openContact(mid).then(after); }
			}, 300);
			return;
		}
		var done = t.closest('[data-done]');
		if (done) {
			e.stopPropagation(); var id = done.dataset.done;
			done.classList.add('on'); var li = done.closest('li'); if (li) { li.classList.add('leaving'); }
			api('PATCH', 'tasks/' + id, { done: true }).then(function () {
				toast('Tâche faite', function () { api('PATCH', 'tasks/' + id, { done: false }).then(function () { refreshBoot(); if (S.drawer) { reloadDrawer(); } }); });
				setTimeout(function () { refreshBoot(); if (S.drawer) { reloadDrawer(); } }, 350);
			}).catch(fail);
			return;
		}
		var undo = t.closest('[data-undo]');
		if (undo) { api('PATCH', 'tasks/' + undo.dataset.undo, { done: false }).then(function () { reloadDrawer(); refreshBoot(); }).catch(fail); return; }
		var sn = t.closest('[data-snooze]'); if (sn) { e.stopPropagation(); snooze(sn.dataset.snooze); return; }
		var oc = t.closest('[data-outcome]'); if (oc) { chooseOutcome(oc.dataset.outcome); return; }
		var st = t.closest('[data-stage-set]');
		if (st && S.drawer) {
			var old = S.drawer.contact.stage, nu = st.dataset.stageSet, cid2 = S.drawer.contact.id;
			if (old === nu) { return; }
			api('PATCH', 'contacts/' + cid2, { stage: nu }).then(function (r) {
				S.drawer = r; renderDrawer({}); refreshBoot(false); rerender();
				toast('Étape : ' + STAGES[nu], function () { api('PATCH', 'contacts/' + cid2, { stage: old }).then(function (r2) { S.drawer = r2; renderDrawer({}); refreshBoot(false); rerender(); }); });
			}).catch(fail);
			return;
		}
		var da = t.closest('[data-delact]'); if (da) { api('DELETE', 'activities/' + da.dataset.delact).then(reloadDrawer).catch(fail); return; }
		var swc = t.closest('[data-swatch]'); if (swc && W) { wizRead(); W.brand.color = swc.dataset.swatch; wizard(); return; }
		var tp = t.closest('[data-tpl]'); if (tp && W) { W.template = tp.dataset.tpl; $$('.tpl').forEach(function (x) { x.classList.toggle('on', x === tp); }); return; }
		var gt = t.closest('[data-goto]');
		if (gt) { if (gt.closest('.jd')) { return; } var colEl = $('.col[data-stage="' + gt.dataset.goto + '"]'), bd = $('#board'); if (colEl && bd) { bd.scrollTo({ left: colEl.offsetLeft - bd.offsetLeft - 4, behavior: 'smooth' }); } return; }
		var sc = t.closest('[data-scroll]'); if (sc) { scrollBoard(+sc.dataset.scroll); return; }
		var chip = t.closest('.chip');
		if (chip) { S.contacts.stage = chip.dataset.stage || ''; S.contacts.filter = chip.dataset.filter || ''; S.contacts.page = 1; $$('.chip').forEach(function (x) { x.classList.toggle('on', x === chip); }); loadContacts(); return; }
		var pg = t.closest('[data-page]'); if (pg) { S.contacts.page = +pg.dataset.page; loadContacts(); return; }
		var pick = t.closest('[data-pick]'); if (pick) { closeModal(); go('#/contact/' + pick.dataset.pick); return; }
		var op = t.closest('[data-open]');
		if (op && op.dataset.open && !t.closest('a,button,input,label,select,textarea')) { go('#/contact/' + op.dataset.open); }
	});

	document.addEventListener('change', function (e) {
		if (e.target.id === 'wcolor' && W) { wizRead(); W.brand.color = e.target.value; wizard(); return; }
		if (e.target.matches('[data-owner]')) {
			var oid = e.target.dataset.owner;
			api('PATCH', 'contacts/' + oid, { owner: +e.target.value }).then(function (r) { S.drawer = r; renderDrawer({}); toast(+e.target.value ? 'Attribué à ' + userName(+e.target.value) : 'Attribution retirée'); rerender(); }).catch(fail);
			return;
		}
		if (e.target.matches('.preset input[value="custom"]')) { var p = e.target.closest('form,div').querySelector('.preset-picker') || e.target.closest('form').querySelector('.preset-picker'); if (p) { p.hidden = false; p.focus(); } }
		else if (e.target.matches('.preset input')) { var f = e.target.closest('form'); var pk = f && f.querySelector('.preset-picker'); if (pk) { pk.hidden = true; } }
	});

	document.addEventListener('submit', function (e) {
		if (e.target.id !== 'cfform') { return; }
		e.preventDefault(); var f = e.target, k = f.dataset.outcome;
		var body = { kind: 'call', outcome: k, body: f.body.value.trim() };
		if (f.has_next && f.has_next.checked && f.next.value.trim()) { body.next = { title: f.next.value.trim(), due: readDue(f, 'cfdue') }; }
		if (f.dataset.task) { body.done_task = +f.dataset.task; }
		submitLog(body, 'Appel enregistré');
	});

	document.addEventListener('keydown', function (e) {
		var typing = /INPUT|TEXTAREA|SELECT/.test((e.target || {}).tagName || '');
		if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); palette(); return; }
		if (e.key === 'Escape') { if (!$('#modal').hidden) { closeModal(); } else if (S.drawer) { closeDrawer(); } return; }
		if (typing) { return; }
		if (e.key === '/') { e.preventDefault(); palette(); }
		if (e.key.toLowerCase() === 'n' && !e.ctrlKey && !e.metaKey) { e.preventDefault(); newContact(); }
	});

	window.addEventListener('hashchange', route);

	/* ---------- Mode démo : données fictives, rien n'est enregistré ---------- */
	var Demo = (function () {
		var db = null;
		function rnd(a) { return a[Math.floor(Math.random() * a.length)]; }
		function minsAgo(m) { var d = new Date(Date.now() - m * 60000); return sqlDate(d); }
		function at(dayOffset, h, mi) { var d = new Date(); d.setDate(d.getDate() + dayOffset); d.setHours(h, mi || 0, 0, 0); return sqlDate(d); }
		function plain(s) { return s.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, ''); }
		function seed() {
			var people = [
				['Sophie Tremblay', 'Toitures Tremblay', 'Sherbrooke', 'meta', 'nouveau', 3, 0], ['Marc-André Gagnon', 'Gagnon Plomberie', 'Magog', 'google', 'nouveau', 21, 0],
				['Julie Bouchard', 'Clinique Physio Santé', 'Granby', 'form', 'nouveau', 95, 0], ['Patrick Côté', 'Excavation Côté', 'Drummondville', 'meta', 'nouveau', 400, 0],
				['Isabelle Roy', 'Salon Lumière', 'Sherbrooke', 'rdv', 'rencontre', 2900, 1800], ['Étienne Lévesque', 'Lévesque Électrique', 'Coaticook', 'google', 'rencontre', 5200, 2400],
				['Nadia Morin', 'Massothérapie Équilibre', 'Magog', 'meta', 'maquette', 8600, 2500], ['François Pelletier', 'Rénovations FP', 'Sherbrooke', 'form', 'soumission', 12000, 3500],
				['Caroline Fortin', 'Pâtisserie Fortin', 'North Hatley', 'maquette', 'soumission', 15000, 2800], ['Mathieu Bélanger', 'Garage Bélanger', 'Windsor', 'meta', 'gagne', 30000, 3200],
				['Annie Gauthier', 'Gauthier Paysagement', 'Bromont', 'google', 'gagne', 42000, 4800], ['Simon Ouellet', 'Déneigement Ouellet', 'Sherbrooke', 'meta', 'contacte', 7000, 0],
				['Valérie Bergeron', 'Studio Yoga Prana', 'Orford', 'form', 'maquette', 9800, 3200], ['Jean-François Paquette', 'Paquette Entretien', 'Lennoxville', 'rdv', 'soumission', 6500, 4200],
				['Mélanie Girard', 'Fleuriste Girard', 'Sherbrooke', 'meta', 'perdu', 20000, 0], ['Olivier Lapointe', 'Lapointe Thermopompes', 'Granby', 'google', 'nouveau', 1500, 0],
				['Geneviève Caron', 'Caron Notaires', 'Sherbrooke', 'form', 'gagne', 60000, 6000], ['Alexandre Poirier', 'Poirier Peinture', 'Magog', 'meta', 'contacte', 3900, 0],
				['Chantal Dubé', 'Garderie Les Pommettes', 'Sherbrooke', 'meta', 'maquette', 11000, 0], ['Louis-Philippe Boivin', 'Boivin Mécanique', 'Asbestos', 'google', 'soumission', 18000, 5200],
				['Karine Lefebvre', 'Boutique Kali', 'Sherbrooke', 'rdv', 'nouveau', 320, 0], ['Sylvain Morissette', 'Morissette Toitures', 'Victoriaville', 'google', 'perdu', 12000, 0]
			];
			var id = 100, contacts = [], acts = [], tasks = [], aid = 1, tid = 1;
			people.forEach(function (p) {
				id++;
				var parts = plain(p[0]).split(' ');
				var c = { id: id, name: p[0], company: p[1], city: p[2], source: p[3], stage: p[4], email: parts[0] + '@' + plain(p[1]).replace(/[^a-z]/g, '') + '.ca',
					phone: '819 ' + (500 + id) + '-' + (1000 + id * 7 % 9000), website: '', value: p[6], notes: '', created_at: minsAgo(p[5]), last_activity_at: minsAgo(Math.max(1, p[5] / 3)), first_contact_at: p[4] === 'nouveau' ? null : minsAgo(p[5] - 40) };
				contacts.push(c);
				var srcTitle = { meta: 'Prospect Meta : Site web 499 $', google: 'Prospect Google Ads', form: 'Message reçu par le formulaire (/contact/)', rdv: 'Appel découverte réservé', maquette: 'Demande de maquette gratuite' }[p[3]];
				acts.push({ id: aid++, contact_id: id, type: p[3] === 'form' ? 'form' : (p[3] === 'maquette' ? 'maquette' : (p[3] === 'rdv' ? 'rdv' : p[3])), title: srcTitle, body: p[3] === 'meta' ? 'Formulaire : LM Web | Site WordPress 499 $\nCampagne : Acquisition automne\nPlateforme : Facebook' : '', created_at: c.created_at });
				if (p[4] !== 'nouveau') {
					acts.push({ id: aid++, contact_id: id, type: 'call', title: 'Appel : joint', body: rnd(['Intéressé par une refonte complète, budget autour de 3 000 $.', 'Veut plus d’appels depuis Google, rappeler après ses vacances.', 'Demande une maquette avant de décider.']), created_at: minsAgo(p[5] - 40) });
					acts.push({ id: aid++, contact_id: id, type: 'stage', title: 'Étape : Nouveau → ' + ({ contacte: 'Contacté', rencontre: 'Rendez-vous effectué', maquette: 'Maquette envoyée', soumission: 'Soumission', gagne: 'Client', perdu: 'Perdu' })[p[4]], body: '', created_at: minsAgo(p[5] - 45) });
				}
			});
			var T = function (cid, title, due) { tasks.push({ id: tid++, contact_id: cid, title: title, due_at: due, done_at: null, created_at: minsAgo(60) }); };
			T(101, 'Rappeler le prospect Meta', minsAgo(3)); T(102, 'Rappeler le prospect Google', minsAgo(21)); T(103, 'Répondre au message du formulaire', at(0, 9));
			T(105, 'Suivi après : Appel découverte', at(-1, 9)); T(108, 'Relancer la soumission', at(0, 9)); T(109, 'Envoyer le contrat', at(0, 14, 30));
			T(107, 'Présenter la maquette', at(1, 10)); T(113, 'Appeler pour la maquette', at(2, 9)); T(114, 'Relancer la soumission', at(3, 9)); T(118, 'Rappeler', at(4, 9)); T(120, 'Relancer la soumission', at(-2, 9));
			var kr = new Date(); kr.setDate(kr.getDate() + 1); kr.setHours(10, 0, 0, 0);
			contacts.filter(function (c) { return c.id === 121; })[0].rdv = { s: Math.floor(kr / 1000), title: 'Appel découverte' };
			contacts.forEach(function (c, i) { c.owner = c.stage === 'nouveau' ? 0 : (i % 3 ? 1 : 2); c.kind = ''; });
			db = { contacts: contacts, acts: acts, tasks: tasks, aid: aid, tid: tid, id: id };
		}
		var STG = { nouveau: 'Nouveau', contacte: 'Contacté', rencontre: 'Rendez-vous effectué', maquette: 'Maquette envoyée', soumission: 'Soumission', gagne: 'Client', perdu: 'Perdu' };
		var STG_DEFS = [['nouveau', '#3B7BF6', 'Nouveau'], ['contacte', '#8B5CF6', 'Contacté'], ['rencontre', '#0E9F8E', 'RDV effectué'], ['maquette', '#F08A24', 'Maquette'], ['soumission', '#E2468E', 'Soumission'], ['gagne', '#11A36B', 'Client'], ['perdu', '#8A93A6', 'Perdu']].map(function (x) { return { key: x[0], label: STG[x[0]], color: x[1], short: x[2] }; });
		var TPLS = [
			{ key: 'general', label: 'Général', hint: 'Pour la plupart des entreprises de services.', stages: ['Nouveau', 'Contacté', 'Rendez-vous effectué', 'Soumission envoyée', 'Client', 'Perdu'] },
			{ key: 'services', label: 'Services à domicile et construction', hint: 'Plombier, électricien, rénovation, déneigement, entretien…', stages: ['Nouveau', 'Contacté', 'Visite ou estimation', 'Soumission envoyée', 'Travaux confirmés', 'Perdu'] },
			{ key: 'immo', label: 'Courtage immobilier', hint: 'Acheteurs et vendeurs, du premier appel à la transaction.', stages: ['Nouveau', 'Contacté', 'Rencontre effectuée', 'Contrat signé', 'Offre acceptée', 'Transaction conclue', 'Perdu'] },
			{ key: 'sante', label: 'Santé et bien-être', hint: 'Clinique, physiothérapie, dentiste, massothérapie…', stages: ['Nouveau', 'Contacté', 'Rendez-vous planifié', 'Première visite faite', 'Patient suivi', 'Perdu'] },
			{ key: 'pro', label: 'Services professionnels', hint: 'Comptable, avocat, conseiller financier, consultant…', stages: ['Nouveau', 'Contacté', 'Rencontre effectuée', 'Proposition envoyée', 'Client', 'Perdu'] },
			{ key: 'agence', label: 'Agence web et marketing', hint: 'Le pipeline de LM Web, avec la maquette.', stages: ['Nouveau', 'Contacté', 'Rendez-vous effectué', 'Maquette envoyée', 'Soumission', 'Client', 'Perdu'] }
		];
		function find(id) { return db.contacts.filter(function (c) { return c.id === +id; })[0]; }
		function nextOf(c) { var o = db.tasks.filter(function (t) { return t.contact_id === c.id && !t.done_at; }).sort(function (a, b) { return a.due_at < b.due_at ? -1 : 1; })[0]; return o; }
		function shape(c) { var n = nextOf(c); return { id: c.id, name: c.name, company: c.company, email: c.email, phone: c.phone, website: c.website, city: c.city, source: c.source, stage: c.stage, value: c.value, notes: c.notes, created: c.created_at, last: c.last_activity_at, contacted: c.first_contact_at, next_due: n ? n.due_at : null, next_title: n ? n.title : null, rdv: c.rdv || null, kind: c.kind || '', owner: c.owner || 0 }; }
		function full(id) { var c = find(id); return { contact: shape(c), activities: db.acts.filter(function (a) { return a.contact_id === c.id; }).sort(function (a, b) { return a.created_at < b.created_at ? 1 : -1; }), tasks: db.tasks.filter(function (t) { return t.contact_id === c.id; }) }; }
		function addAct(cid, type, title, body) { var now = sqlDate(new Date()); db.acts.push({ id: db.aid++, contact_id: +cid, type: type, title: title, body: body || '', created_at: now }); var c = find(cid); if (c) { c.last_activity_at = now; } }
		function due(v) { if (!v) { return null; } var m = /^\+(\d+)$/.exec(v); if (m) { var d = new Date(), n = +m[1]; while (n > 0) { d.setDate(d.getDate() + 1); if (d.getDay() % 6) { n--; } } d.setHours(9, 0, 0, 0); return sqlDate(d); } if (/^\d{4}-\d{2}-\d{2}$/.test(v)) { return v + ' 09:00:00'; } return v.replace('T', ' ').slice(0, 16) + ':00'; }
		function setStage(c, s) { if (c.stage === s) { return; } addAct(c.id, 'stage', 'Étape : ' + STG[c.stage] + ' → ' + STG[s]); if (c.stage === 'nouveau' && !c.first_contact_at) { c.first_contact_at = sqlDate(new Date()); } c.stage = s; }
		function counts() { var o = {}; Object.keys(STG).forEach(function (k) { o[k] = { n: 0, v: 0 }; }); db.contacts.forEach(function (c) { o[c.stage].n++; o[c.stage].v += c.value || 0; }); return o; }
		function boot() {
			var now = new Date(), end = new Date(); end.setDate(end.getDate() + 7); end.setHours(23, 59, 59);
			var tasks = db.tasks.filter(function (t) { return !t.done_at && parse(t.due_at) <= end; }).sort(function (a, b) { return a.due_at < b.due_at ? -1 : 1; }).map(function (t) { var c = find(t.contact_id) || {}; return { id: t.id, contact_id: t.contact_id, title: t.title, due_at: t.due_at, name: c.name, company: c.company, phone: c.phone, email: c.email, source: c.source, stage: c.stage }; });
			var fresh = db.contacts.filter(function (c) { return c.stage === 'nouveau'; }).sort(function (a, b) { return a.created_at < b.created_at ? 1 : -1; }).map(shape);
			var t0 = new Date(); t0.setHours(0, 0, 0, 0); var s = t0.getTime() / 1000;
			return {
				user: { name: 'Cédric' }, brand: CFG.brand || { name: 'LM Web CRM', color: '#FF7020', logo: '' }, stages: STG, stage_defs: STG_DEFS, templates: TPLS, template: 'agence',
				setup: true, admin: true, me: 1, users: [{ id: 1, name: 'Cédric' }, { id: 2, name: 'Annie' }], notify: 'contact@lm-web.ca', push: { key: '', devices: [] }, sw: '',
				sources_info: { forms: ['Contact', 'Demande de soumission'], meta: true, rdv: true },
				sources: {}, counts: counts(),
				stats: { new7: 14, prev7: 9, response: 12, won30: 3, sources: [{ source: 'meta', n: 21 }, { source: 'google', n: 12 }, { source: 'form', n: 7 }, { source: 'rdv', n: 4 }, { source: 'maquette', n: 3 }] },
				fresh: fresh, tasks: tasks,
				agenda: [
					{ s: s + 9 * 3600, e: s + 9.5 * 3600, title: 'Appel découverte', who: 'Isabelle Roy (Salon Lumière)', contact: 105, meet: 'https://meet.google.com/' },
					{ s: s + 11 * 3600, e: s + 12 * 3600, busy: true },
					{ s: s + 14 * 3600, e: s + 14.5 * 3600, title: 'Présentation de votre maquette', who: 'Nadia Morin (Massothérapie Équilibre)', contact: 107, meet: 'https://meet.google.com/' },
					{ s: s + 16 * 3600, e: s + 17 * 3600, title: 'Brief ou suivi de votre projet', who: 'François Pelletier (Rénovations FP)', contact: 108, meet: 'https://meet.google.com/' }
				],
				meta: true
			};
		}
		function list(q) {
			var s = (q.s || '').toLowerCase(), rows = db.contacts.filter(function (c) {
				if (q.stage && c.stage !== q.stage) { return false; }
				if (q.source && c.source !== q.source) { return false; }
				if (q.filter === 'mine' && c.owner !== 1) { return false; }
				if (q.filter === 'late') { var n = nextOf(c); var t0 = new Date(); t0.setHours(0, 0, 0, 0); if (!n || parse(n.due_at) >= t0) { return false; } }
				return !s || [c.name, c.company, c.email, c.phone, c.city].join(' ').toLowerCase().indexOf(s) >= 0;
			});
			var key = { recent: 'last_activity_at', new: 'created_at' }[q.sort];
			rows.sort(function (a, b) {
				if (q.sort === 'name') { return a.name.localeCompare(b.name); }
				if (q.sort === 'value') { return b.value - a.value; }
				if (q.sort === 'next') { var x = nextOf(a), y = nextOf(b); return (x ? x.due_at : 'z') < (y ? y.due_at : 'z') ? -1 : 1; }
				return a[key || 'last_activity_at'] < b[key || 'last_activity_at'] ? 1 : -1;
			});
			return { rows: rows.map(shape), total: rows.length, page: 1, pages: 1 };
		}
		function qs(path) { var o = {}; (path.split('?')[1] || '').split('&').forEach(function (kv) { var p = kv.split('='); if (p[0]) { o[p[0]] = decodeURIComponent(p[1] || ''); } }); return o; }
		return {
			call: function (method, path, body) {
				if (!db) { seed(); }
				var base = path.split('?')[0], m, res;
				body = body || {};
				if (base === 'boot' || base === 'setup') { res = boot(); }
				else if (base === 'contacts' && method === 'GET') { res = list(qs(path)); }
				else if (base === 'search') { var q = qs(path); q.sort = 'recent'; res = { rows: list(q).rows.slice(0, 8) }; }
				else if (base === 'pipeline') { res = { rows: db.contacts.map(shape), counts: counts() }; }
				else if (base === 'contacts' && method === 'POST') { db.id++; var c = { id: db.id, name: body.name || '', company: body.company || '', email: body.email || '', phone: body.phone || '', website: '', city: '', source: body.source || 'manuel', stage: 'nouveau', value: +body.value || 0, notes: '', created_at: sqlDate(new Date()), last_activity_at: sqlDate(new Date()), first_contact_at: null }; db.contacts.push(c); addAct(c.id, 'note', 'Contact créé'); if (body.task) { db.tasks.push({ id: db.tid++, contact_id: c.id, title: body.task.title, due_at: due(body.task.due), done_at: null }); } res = full(c.id); }
				else if ((m = /^contacts\/(\d+)$/.exec(base))) {
					var ct = find(m[1]);
					if (method === 'PATCH') { if (body.stage) { setStage(ct, body.stage); } if ('owner' in body) { ct.owner = +body.owner; addAct(ct.id, 'stage', body.owner ? 'Attribué à ' + (+body.owner === 1 ? 'Cédric' : 'Annie') : 'Attribution retirée'); } if ('kind' in body) { ct.kind = body.kind; } ['name', 'company', 'email', 'phone', 'website', 'city', 'notes'].forEach(function (k) { if (k in body) { ct[k] = body[k]; } }); if ('value' in body) { ct.value = +body.value || 0; } }
					if (method === 'DELETE') { db.contacts = db.contacts.filter(function (x) { return x !== ct; }); res = { ok: true }; }
					else { res = full(m[1]); }
				}
				else if ((m = /^contacts\/(\d+)\/log$/.exec(base))) {
					var cc = find(m[1]), L = { reached: 'Appel : joint', voicemail: 'Appel : message laissé', noanswer: 'Appel : pas de réponse', lost: 'Appel : pas intéressé', wrong: 'Appel : mauvais numéro' };
					var title = body.kind === 'call' ? (L[body.outcome] || 'Appel') : ({ note: 'Note', email: 'Courriel envoyé', sms: 'Texto envoyé' })[body.kind];
					if (body.kind !== 'note' || body.body) { addAct(cc.id, body.kind, title, body.body); }
					if (body.kind !== 'note' && !cc.first_contact_at) { cc.first_contact_at = sqlDate(new Date()); }
					if (body.outcome === 'reached' && cc.stage === 'nouveau') { setStage(cc, 'contacte'); }
					if (body.outcome === 'lost') { setStage(cc, 'perdu'); }
					if (body.done_task) { db.tasks.forEach(function (t) { if (t.id === body.done_task) { t.done_at = sqlDate(new Date()); } }); }
					if (body.next) { db.tasks.push({ id: db.tid++, contact_id: cc.id, title: body.next.title, due_at: due(body.next.due), done_at: null }); }
					res = full(cc.id);
				}
				else if ((m = /^activities\/(\d+)$/.exec(base))) { db.acts = db.acts.filter(function (a) { return a.id !== +m[1]; }); res = { ok: true }; }
				else if (base === 'tasks') { db.tasks.push({ id: db.tid++, contact_id: +body.contact_id, title: body.title, due_at: due(body.due), done_at: null }); res = { ok: true }; }
				else if ((m = /^tasks\/(\d+)$/.exec(base))) {
					var tk = db.tasks.filter(function (t) { return t.id === +m[1]; })[0];
					if (method === 'DELETE') { db.tasks = db.tasks.filter(function (t) { return t !== tk; }); }
					else if (tk) { if (body.due) { tk.due_at = due(body.due); } if ('done' in body) { tk.done_at = body.done ? sqlDate(new Date()) : null; if (body.done) { addAct(tk.contact_id, 'task', 'Tâche faite : ' + tk.title); } } }
					res = { ok: true };
				}
				else { res = { ok: true }; }
				return new Promise(function (ok) { setTimeout(function () { ok(JSON.parse(JSON.stringify(res))); }, 120); });
			}
		};
	})();

	/* ---------- Démarrage ---------- */
	root.innerHTML = '<div class="boot-load"><span class="brand-mark">·</span></div>';
	api('GET', 'boot').then(function (b) {
		S.boot = b; shell();
		if (b.admin && !b.setup && !DEMO && location.hash !== '#/setup') { history.replaceState(null, '', '#/setup'); }
		route();
	}).catch(function (e) {
		root.innerHTML = '<div class="boot-err"><h1>Le CRM ne répond pas</h1><p>' + esc(e.message) + '</p><p><a href="">Recharger la page</a></p></div>';
	});
})();

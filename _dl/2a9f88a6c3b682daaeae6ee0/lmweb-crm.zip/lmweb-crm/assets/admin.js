(function () {
	'use strict';
	if (!window.LMCRM) { return; }

	function api(path, body) {
		return fetch(LMCRM.rest + path, {
			method: 'POST',
			credentials: 'same-origin',
			headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': LMCRM.nonce },
			body: JSON.stringify(body || {})
		}).then(function (r) {
			if (!r.ok) { throw new Error('HTTP ' + r.status); }
			return r.json();
		});
	}

	function updateCounts(counts) {
		if (!counts) { return; }
		document.querySelectorAll('.lmcrm-col').forEach(function (col) {
			var c = counts[col.dataset.stage];
			var b = col.querySelector('.lmcrm-count');
			if (c && b) { b.textContent = c.n; }
		});
	}

	// Tâches : la coche marque faite, un second clic rouvre.
	document.addEventListener('click', function (e) {
		var btn = e.target.closest('button.lmcrm-check');
		if (!btn) { return; }
		var li = btn.closest('[data-task]');
		var done = btn.classList.contains('is-on');
		btn.disabled = true;
		api('tasks/' + li.dataset.task + (done ? '/undo' : '/done')).then(function () {
			btn.disabled = false;
			btn.classList.toggle('is-on', !done);
			li.classList.toggle('is-done', !done);
			btn.setAttribute('aria-pressed', done ? 'false' : 'true');
			btn.title = btn.ariaLabel = done ? 'Marquer comme faite' : 'Rouvrir la tâche';
			var when = li.querySelector('.lmcrm-when');
			if (when) {
				if (!done) { when.dataset.was = when.innerHTML; when.innerHTML = '<span class="lmcrm-due">Faite à l’instant</span>'; }
				else if (when.dataset.was) { when.innerHTML = when.dataset.was; }
			}
		}).catch(function () { btn.disabled = false; alert('La tâche n’a pas pu être enregistrée.'); });
	});

	// Fiche : barre des étapes.
	var bar = document.querySelector('.lmcrm-stagebar');
	if (bar) {
		bar.addEventListener('click', function (e) {
			var b = e.target.closest('button[data-stage]');
			if (!b || b.classList.contains('is-current')) { return; }
			api('contacts/' + bar.dataset.id + '/stage', { stage: b.dataset.stage }).then(function () {
				window.location.reload();
			}).catch(function () { alert('L’étape n’a pas pu être changée.'); });
		});
	}

	// Pipeline : glisser-déposer.
	var dragged = null;
	document.querySelectorAll('.lmcrm-cardlet').forEach(function (card) {
		card.addEventListener('dragstart', function (e) {
			dragged = card;
			card.classList.add('is-dragging');
			e.dataTransfer.effectAllowed = 'move';
			e.dataTransfer.setData('text/plain', card.dataset.id);
		});
		card.addEventListener('dragend', function () {
			card.classList.remove('is-dragging');
			dragged = null;
		});
	});
	document.querySelectorAll('.lmcrm-col').forEach(function (col) {
		col.addEventListener('dragover', function (e) { e.preventDefault(); col.classList.add('is-over'); });
		col.addEventListener('dragleave', function (e) { if (!col.contains(e.relatedTarget)) { col.classList.remove('is-over'); } });
		col.addEventListener('drop', function (e) {
			e.preventDefault();
			col.classList.remove('is-over');
			if (!dragged) { return; }
			var card = dragged, from = card.parentNode;
			if (from === col.querySelector('.lmcrm-drop')) { return; }
			col.querySelector('.lmcrm-drop').prepend(card);
			api('contacts/' + card.dataset.id + '/stage', { stage: col.dataset.stage }).then(function (r) {
				updateCounts(r.counts);
			}).catch(function () {
				from.prepend(card);
				alert('Le changement d’étape n’a pas été enregistré.');
			});
		});
	});
})();

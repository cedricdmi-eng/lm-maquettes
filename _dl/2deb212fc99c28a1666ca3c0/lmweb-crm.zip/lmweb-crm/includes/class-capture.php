<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Captation des formulaires existants du site : Forminator, Contact Form 7, WPForms,
 * Gravity Forms, Fluent Forms et Elementor Pro. Chaque envoi qui contient un courriel ou un
 * téléphone devient un prospect « Nouveau » avec une relance immédiate.
 * Rien ne change pour le visiteur ni pour les courriels que le formulaire envoie déjà.
 */
class LMCRM_Capture {

	const OPT = 'lmcrm_capture';

	public static function init() {
		add_action( 'forminator_custom_form_submit_before_set_fields', array( __CLASS__, 'forminator' ), 30, 3 );
		add_action( 'wpcf7_mail_sent', array( __CLASS__, 'cf7' ), 30, 1 );
		add_action( 'wpforms_process_complete', array( __CLASS__, 'wpforms' ), 30, 4 );
		add_action( 'gform_after_submission', array( __CLASS__, 'gravity' ), 30, 2 );
		add_action( 'fluentform/submission_inserted', array( __CLASS__, 'fluent' ), 30, 3 );
		add_action( 'elementor_pro/forms/new_record', array( __CLASS__, 'elementor' ), 30, 2 );
	}

	/** Réglages : array( 'on' => 1, 'forms' => array( 'forminator:12' => array( 'kind' => 'Acheteur', 'off' => 0 ) ) ). */
	public static function settings() {
		$s = get_option( self::OPT, array() );
		return wp_parse_args( is_array( $s ) ? $s : array(), array( 'on' => 1, 'forms' => array() ) );
	}

	/* ---------- Adaptateurs ---------- */

	public static function forminator( $entry, $form_id, $data ) {
		$labels = array();
		if ( class_exists( 'Forminator_API' ) ) {
			$fields = Forminator_API::get_form_fields( $form_id );
			if ( is_array( $fields ) ) {
				foreach ( $fields as $f ) {
					$raw                    = is_object( $f ) && isset( $f->raw ) ? (array) $f->raw : array();
					$labels[ $f->slug ?? '' ] = $raw['field_label'] ?? '';
				}
			}
		}
		$out = array();
		foreach ( (array) $data as $f ) {
			if ( ! isset( $f['name'] ) ) {
				continue;
			}
			$k     = (string) $f['name'];
			$out[] = array( 'key' => $k, 'label' => $labels[ $k ] ?? '', 'type' => preg_replace( '/-\d+$/', '', $k ), 'value' => $f['value'] ?? '' );
		}
		self::handle( 'forminator', (int) $form_id, self::forminator_title( $form_id ), $out );
	}

	private static function forminator_title( $form_id ) {
		if ( class_exists( 'Forminator_API' ) ) {
			$f = Forminator_API::get_form( $form_id );
			if ( $f && ! is_wp_error( $f ) && ! empty( $f->settings['formName'] ) ) {
				return $f->settings['formName'];
			}
		}
		return get_the_title( $form_id );
	}

	public static function cf7( $cf ) {
		if ( ! class_exists( 'WPCF7_Submission' ) ) {
			return;
		}
		$sub = WPCF7_Submission::get_instance();
		if ( ! $sub ) {
			return;
		}
		$out = array();
		foreach ( (array) $sub->get_posted_data() as $k => $v ) {
			if ( 0 === strpos( (string) $k, '_' ) ) {
				continue;
			}
			$out[] = array( 'key' => (string) $k, 'label' => '', 'type' => '', 'value' => $v );
		}
		self::handle( 'cf7', (int) $cf->id(), $cf->title(), $out );
	}

	public static function wpforms( $fields, $entry, $form_data, $entry_id = 0 ) {
		$out = array();
		foreach ( (array) $fields as $f ) {
			$out[] = array( 'key' => (string) ( $f['id'] ?? '' ), 'label' => (string) ( $f['name'] ?? '' ), 'type' => (string) ( $f['type'] ?? '' ), 'value' => $f['value'] ?? '' );
		}
		self::handle( 'wpforms', (int) ( $form_data['id'] ?? 0 ), (string) ( $form_data['settings']['form_title'] ?? '' ), $out );
	}

	public static function gravity( $entry, $form ) {
		$out = array();
		foreach ( (array) ( $form['fields'] ?? array() ) as $f ) {
			$id   = is_object( $f ) ? $f->id : ( $f['id'] ?? '' );
			$type = is_object( $f ) ? $f->type : ( $f['type'] ?? '' );
			$lab  = is_object( $f ) ? $f->label : ( $f['label'] ?? '' );
			$val  = $entry[ $id ] ?? '';
			if ( 'name' === $type ) {
				$val = trim( ( $entry[ $id . '.3' ] ?? '' ) . ' ' . ( $entry[ $id . '.6' ] ?? '' ) );
			}
			$out[] = array( 'key' => (string) $id, 'label' => (string) $lab, 'type' => (string) $type, 'value' => $val );
		}
		self::handle( 'gravity', (int) ( $form['id'] ?? 0 ), (string) ( $form['title'] ?? '' ), $out );
	}

	public static function fluent( $entry_id, $data, $form ) {
		$out = array();
		foreach ( (array) $data as $k => $v ) {
			if ( 0 === strpos( (string) $k, '_' ) ) {
				continue;
			}
			$out[] = array( 'key' => (string) $k, 'label' => '', 'type' => '', 'value' => $v );
		}
		self::handle( 'fluent', (int) ( is_object( $form ) ? $form->id : 0 ), is_object( $form ) ? (string) $form->title : '', $out );
	}

	public static function elementor( $record, $handler ) {
		$out = array();
		foreach ( (array) $record->get( 'fields' ) as $id => $f ) {
			$out[] = array( 'key' => (string) $id, 'label' => (string) ( $f['title'] ?? '' ), 'type' => (string) ( $f['type'] ?? '' ), 'value' => $f['value'] ?? '' );
		}
		$name = (string) $record->get_form_settings( 'form_name' );
		self::handle( 'elementor', abs( crc32( $name ) ), $name, $out );
	}

	/* ---------- Traitement commun ---------- */

	private static function flat( $v ) {
		if ( is_array( $v ) ) {
			// Champ « nom » en plusieurs parties (prénom, nom) ou cases multiples.
			$v = implode( ' ', array_filter( array_map( array( __CLASS__, 'flat' ), $v ), 'strlen' ) );
		}
		return trim( wp_strip_all_tags( (string) $v ) );
	}

	private static function match( $f, array $types, $re ) {
		$t = strtolower( $f['type'] );
		if ( $t && in_array( $t, $types, true ) ) {
			return true;
		}
		return (bool) preg_match( $re, strtolower( remove_accents( $f['key'] . ' ' . $f['label'] ) ) );
	}

	/**
	 * Déduit les coordonnées des champs, garde le reste comme détail de la demande.
	 *
	 * @return array array( contact, details[] )
	 */
	public static function parse( array $fields ) {
		$c    = array( 'name' => '', 'first' => '', 'last' => '', 'email' => '', 'phone' => '', 'company' => '', 'city' => '', 'message' => '' );
		$rest = array();
		foreach ( $fields as $f ) {
			$v = self::flat( $f['value'] );
			if ( '' === $v ) {
				continue;
			}
			$t = strtolower( $f['type'] );
			if ( in_array( $t, array( 'consent', 'gdprcheckbox', 'captcha', 'hidden', 'html', 'submit', 'honeypot', 'recaptcha', 'turnstile' ), true ) ) {
				continue;
			}
			if ( '' === $c['email'] && ( is_email( $v ) && self::match( $f, array( 'email' ), '/e-?mail|courriel|adresse_courriel/' ) ) ) {
				$c['email'] = $v;
			} elseif ( '' === $c['phone'] && self::match( $f, array( 'phone', 'tel' ), '/phone|tel(ephone)?|cell|mobile/' ) ) {
				$c['phone'] = $v;
			} elseif ( '' === $c['first'] && self::match( $f, array(), '/first.?name|prenom/' ) ) {
				$c['first'] = $v;
			} elseif ( '' === $c['last'] && self::match( $f, array(), '/last.?name|nom.?de.?famille|surname/' ) ) {
				$c['last'] = $v;
			} elseif ( '' === $c['name'] && self::match( $f, array( 'name' ), '/(^|[^a-z])(name|nom|your-name|full.?name|nom.?complet)([^a-z]|$)/' ) ) {
				$c['name'] = $v;
			} elseif ( '' === $c['company'] && self::match( $f, array(), '/company|entreprise|societe|business|organisation/' ) ) {
				$c['company'] = $v;
			} elseif ( '' === $c['city'] && self::match( $f, array(), '/(^|[^a-z])(city|ville)([^a-z]|$)/' ) ) {
				$c['city'] = $v;
			} elseif ( '' === $c['message'] && self::match( $f, array( 'textarea' ), '/message|commentaire|projet|details|your-message/' ) ) {
				$c['message'] = $v;
			} else {
				$label  = $f['label'] ? $f['label'] : ucfirst( str_replace( array( '-', '_' ), ' ', preg_replace( '/-\d+$/', '', $f['key'] ) ) );
				$rest[] = $label . ' : ' . mb_substr( $v, 0, 500 );
			}
		}
		if ( '' === $c['email'] ) {
			foreach ( $fields as $f ) {
				$v = self::flat( $f['value'] );
				if ( is_email( $v ) ) {
					$c['email'] = $v;
					break;
				}
			}
		}
		if ( '' === $c['name'] ) {
			$c['name'] = trim( $c['first'] . ' ' . $c['last'] );
		}
		return array( $c, $rest );
	}

	/** Page d'où vient l'envoi (référent), sans admin-ajax. */
	private static function page() {
		$ref  = isset( $_SERVER['HTTP_REFERER'] ) ? (string) wp_unslash( $_SERVER['HTTP_REFERER'] ) : ''; // phpcs:ignore
		$path = $ref ? (string) wp_parse_url( $ref, PHP_URL_PATH ) : '';
		return ( '' === $path || false !== strpos( $path, 'admin-ajax' ) ) ? '' : sanitize_text_field( $path );
	}

	/**
	 * @param string $plugin Extension (forminator, cf7…).
	 * @param int    $form_id Formulaire.
	 * @param string $title Nom du formulaire.
	 * @param array  $fields Champs normalisés.
	 * @param array  $opts history (date d'origine : import sans relance ni avis).
	 * @return int|false Contact.
	 */
	public static function handle( $plugin, $form_id, $title, array $fields, array $opts = array() ) {
		try {
			$set = self::settings();
			$key = $plugin . ':' . $form_id;
			$cfg = $set['forms'][ $key ] ?? array();
			if ( empty( $set['on'] ) || ! empty( $cfg['off'] ) ) {
				return false;
			}
			list( $c, $rest ) = self::parse( $fields );
			if ( ( '' === $c['email'] && '' === $c['phone'] ) || ( $c['email'] && LMCRM_Sources::is_internal( $c['email'] ) ) ) {
				return false;
			}
			$history = ! empty( $opts['history'] );
			$when    = $history ? $opts['history'] : LMCRM_DB::now();
			$data    = array(
				'name'       => $c['name'],
				'company'    => $c['company'],
				'email'      => $c['email'],
				'phone'      => $c['phone'],
				'city'       => $c['city'],
				'kind'       => (string) ( $cfg['kind'] ?? '' ),
				'source'     => 'form',
				'stage'      => $history ? 'contacte' : 'nouveau',
				'created_at' => $when,
			);
			if ( $history && $c['email'] && LMCRM_DB::contact_by_email( $c['email'] ) ) {
				return false;
			}
			if ( $c['email'] ) {
				list( $cid ) = LMCRM_DB::upsert_contact( $data );
			} else {
				$cid = LMCRM_DB::insert_contact( $data );
			}
			$page  = $history ? '' : self::page();
			$body  = trim( ( $c['message'] ? $c['message'] . "\n\n" : '' ) . implode( "\n", $rest ) );
			$title = $title ? $title : 'Formulaire ' . $form_id;
			$ref   = $history && ! empty( $opts['ref'] ) ? $opts['ref'] : null;
			LMCRM_DB::add_activity( $cid, 'form', 'Formulaire « ' . $title . ' »' . ( $page ? ' (' . $page . ')' : '' ), $body, $ref, $when );
			if ( ! $history ) {
				LMCRM_DB::add_task( $cid, 'Rappeler : demande « ' . mb_substr( $title, 0, 60 ) . ' »', LMCRM_DB::now() );
				LMCRM_Notify::lead( $cid, '', '', array(), ! empty( $cfg['kind'] ) ? 'Nouveau prospect ' . mb_strtolower( $cfg['kind'] ) : 'Nouvelle demande' );
			}
			return $cid;
		} catch ( \Throwable $e ) {
			// Le formulaire du visiteur ne doit jamais échouer à cause du CRM.
			update_option( 'lmcrm_capture_error', LMCRM_DB::now() . ' ' . $e->getMessage(), false );
			return false;
		}
	}

	/* ---------- Formulaires détectés et reprise de l'historique ---------- */

	/** Formulaires présents sur le site : array( 'plugin:id' => titre ). */
	public static function detected() {
		$out = array();
		if ( class_exists( 'Forminator_API' ) ) {
			foreach ( (array) Forminator_API::get_forms( null, 1, 100 ) as $f ) {
				if ( is_object( $f ) && isset( $f->id ) ) {
					$out[ 'forminator:' . $f->id ] = ( $f->settings['formName'] ?? '' ) ?: ( $f->name ?? 'Formulaire ' . $f->id );
				}
			}
		}
		foreach ( array( 'wpcf7_contact_form' => 'cf7', 'wpforms' => 'wpforms' ) as $pt => $pl ) {
			if ( post_type_exists( $pt ) ) {
				foreach ( get_posts( array( 'post_type' => $pt, 'numberposts' => 100, 'post_status' => 'publish' ) ) as $p ) {
					$out[ $pl . ':' . $p->ID ] = $p->post_title;
				}
			}
		}
		if ( class_exists( 'GFAPI' ) ) {
			foreach ( (array) GFAPI::get_forms() as $f ) {
				$out[ 'gravity:' . $f['id'] ] = $f['title'];
			}
		}
		return $out;
	}

	/** Reprise des demandes déjà reçues par Forminator : en « Contacté », sans relance ni avis. */
	public static function backfill() {
		$n = 0;
		if ( ! class_exists( 'Forminator_API' ) ) {
			return 0;
		}
		foreach ( array_keys( self::detected() ) as $key ) {
			if ( 0 !== strpos( $key, 'forminator:' ) ) {
				continue;
			}
			$fid     = (int) substr( $key, 11 );
			$title   = self::forminator_title( $fid );
			$entries = Forminator_API::get_entries( $fid );
			foreach ( is_array( $entries ) ? $entries : array() as $e ) {
				$fields = array();
				foreach ( (array) $e->meta_data as $k => $m ) {
					$fields[] = array( 'key' => (string) $k, 'label' => '', 'type' => preg_replace( '/-\d+$/', '', (string) $k ), 'value' => $m['value'] ?? '' );
				}
				$when = ! empty( $e->date_created_sql ) ? $e->date_created_sql : LMCRM_DB::now();
				if ( self::handle( 'forminator', $fid, $title, $fields, array( 'history' => $when, 'ref' => 'fm:' . $fid . ':' . $e->entry_id ) ) ) {
					$n++;
				}
			}
		}
		return $n;
	}
}

<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * API de l'application (lmcrm/v1), réservée aux administrateurs, plus le webhook
 * public des formulaires de prospects Google Ads (protégé par une clé).
 */
class LMCRM_API {

	const NS = 'lmcrm/v1';

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
	}

	private static function r( $path, $methods, $cb, $public = false ) {
		register_rest_route( self::NS, $path, array(
			'methods'             => $methods,
			'callback'            => $cb,
			'permission_callback' => true === $public ? '__return_true' : ( 'admin' === $public ? array( 'LMCRM_REST', 'admin' ) : array( 'LMCRM_REST', 'can' ) ),
		) );
	}

	public static function routes() {
		self::r( '/boot', 'GET', array( __CLASS__, 'boot' ) );
		self::r( '/contacts', 'GET', array( __CLASS__, 'list_contacts' ) );
		self::r( '/contacts', 'POST', array( __CLASS__, 'create_contact' ) );
		self::r( '/contacts/(?P<id>\d+)', 'GET', array( __CLASS__, 'get_contact' ) );
		self::r( '/contacts/(?P<id>\d+)', 'PATCH', array( __CLASS__, 'patch_contact' ) );
		self::r( '/contacts/(?P<id>\d+)', 'DELETE', array( __CLASS__, 'delete_contact' ) );
		self::r( '/contacts/(?P<id>\d+)/log', 'POST', array( __CLASS__, 'log' ) );
		self::r( '/activities/(?P<id>\d+)', 'DELETE', array( __CLASS__, 'delete_activity' ) );
		self::r( '/tasks', 'POST', array( __CLASS__, 'create_task' ) );
		self::r( '/tasks/(?P<id>\d+)', 'PATCH', array( __CLASS__, 'patch_task' ) );
		self::r( '/tasks/(?P<id>\d+)', 'DELETE', array( __CLASS__, 'delete_task' ) );
		self::r( '/pipeline', 'GET', array( __CLASS__, 'pipeline' ) );
		self::r( '/search', 'GET', array( __CLASS__, 'search' ) );
		self::r( '/google-lead', 'POST', array( __CLASS__, 'google_lead' ), true );
		self::r( '/setup', 'POST', array( __CLASS__, 'setup' ), 'admin' );
		self::r( '/push', 'POST', array( __CLASS__, 'push_subscribe' ) );
		self::r( '/push', 'DELETE', array( __CLASS__, 'push_unsubscribe' ) );
		self::r( '/push/test', 'POST', array( __CLASS__, 'push_test' ) );
	}

	/* ---------- Aides ---------- */

	private static function t( $n ) {
		return LMCRM_DB::t( $n );
	}

	/** Colonnes calculées : prochaine tâche ouverte. */
	private static function select() {
		$t = self::t( 'tasks' );
		return 'c.*, (SELECT MIN(due_at) FROM ' . $t . ' x WHERE x.contact_id = c.id AND x.done_at IS NULL) AS next_due,'
			. ' (SELECT title FROM ' . $t . ' y WHERE y.contact_id = c.id AND y.done_at IS NULL ORDER BY y.due_at IS NULL, y.due_at LIMIT 1) AS next_title';
	}

	private static function shape( array $c ) {
		return array(
			'id'          => (int) $c['id'],
			'name'        => $c['name'],
			'company'     => $c['company'],
			'email'       => $c['email'],
			'phone'       => $c['phone'],
			'website'     => $c['website'],
			'city'        => $c['city'],
			'source'      => $c['source'],
			'stage'       => $c['stage'],
			'value'       => (float) $c['value'],
			'notes'       => (string) $c['notes'],
			'created'     => $c['created_at'],
			'last'        => $c['last_activity_at'],
			'contacted'   => $c['first_contact_at'] ?? null,
			'next_due'    => $c['next_due'] ?? null,
			'next_title'  => $c['next_title'] ?? null,
			'kind'        => (string) ( $c['kind'] ?? '' ),
			'owner'       => (int) ( $c['owner_id'] ?? 0 ),
		);
	}

	/** Marque affichée : réglée dans l'assistant, sinon le nom et l'icône du site. */
	public static function brand() {
		$b = (array) get_option( 'lmcrm_brand', array() );
		return array(
			'name'  => ! empty( $b['name'] ) ? $b['name'] : wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ),
			'color' => ! empty( $b['color'] ) ? $b['color'] : '#FF7020',
			'logo'  => ! empty( $b['logo'] ) ? $b['logo'] : (string) get_site_icon_url( 128 ),
		);
	}

	/** Personnes qui ont accès au CRM (pour attribuer un prospect). */
	public static function users() {
		$out = array();
		foreach ( get_users( array( 'capability__in' => array( 'lmcrm_use', 'manage_options' ), 'fields' => array( 'ID', 'display_name', 'user_email' ) ) ) as $u ) {
			if ( LMCRM_Sources::is_internal_team( $u->user_email ) ) {
				continue;
			}
			$fn    = get_user_meta( $u->ID, 'first_name', true );
			$out[] = array( 'id' => (int) $u->ID, 'name' => $fn ? $fn : $u->display_name );
		}
		return $out;
	}

	/* ---------- Accueil ---------- */

	public static function boot() {
		global $wpdb;
		$c   = self::t( 'contacts' );
		$now = LMCRM_DB::now();
		$d7  = wp_date( 'Y-m-d H:i:s', time() - 7 * DAY_IN_SECONDS );
		$d14 = wp_date( 'Y-m-d H:i:s', time() - 14 * DAY_IN_SECONDS );
		$d30 = wp_date( 'Y-m-d H:i:s', time() - 30 * DAY_IN_SECONDS );

		$new7  = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $c WHERE created_at >= %s AND source NOT IN ('zoho','manuel')", $d7 ) );
		$prev7 = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $c WHERE created_at >= %s AND created_at < %s AND source NOT IN ('zoho','manuel')", $d14, $d7 ) );
		$resp  = $wpdb->get_var( $wpdb->prepare( "SELECT AVG(TIMESTAMPDIFF(MINUTE, created_at, first_contact_at)) FROM $c WHERE first_contact_at IS NOT NULL AND created_at >= %s AND source NOT IN ('zoho','manuel','rdv')", $d30 ) );
		$won30 = (int) $wpdb->get_var( $wpdb->prepare(
			'SELECT COUNT(DISTINCT contact_id) FROM ' . self::t( 'activities' ) . " WHERE type = 'stage' AND title LIKE %s AND created_at >= %s",
			'%→ Client', $d30
		) );
		$src   = $wpdb->get_results( $wpdb->prepare( "SELECT source, COUNT(*) n FROM $c WHERE created_at >= %s AND source NOT IN ('zoho') GROUP BY source ORDER BY n DESC", $d30 ), ARRAY_A );
		LMCRM_Sources::meetings_done( 2 );
		$fresh = $wpdb->get_results( 'SELECT ' . self::select() . " FROM $c c WHERE c.stage = 'nouveau' ORDER BY c.created_at DESC LIMIT 30", ARRAY_A );
		$fresh = array_map( array( __CLASS__, 'shape' ), $fresh );
		$next  = self::upcoming_meetings();
		foreach ( $fresh as &$f ) {
			$k        = strtolower( (string) $f['email'] );
			$f['rdv'] = ( '' !== $k && isset( $next[ $k ] ) ) ? $next[ $k ] : null;
		}
		unset( $f );
		$tasks = $wpdb->get_results( $wpdb->prepare(
			'SELECT t.id, t.contact_id, t.title, t.due_at, c.name, c.company, c.phone, c.email, c.source, c.stage FROM ' . self::t( 'tasks' ) . " t LEFT JOIN $c c ON c.id = t.contact_id
			 WHERE t.done_at IS NULL AND t.due_at IS NOT NULL AND t.due_at <= %s ORDER BY t.due_at LIMIT 100",
			wp_date( 'Y-m-d 23:59:59', time() + 7 * DAY_IN_SECONDS )
		), ARRAY_A );

		$user = wp_get_current_user();
		return array(
			'user'    => array( 'name' => $user->first_name ?: $user->display_name ),
			'brand'   => self::brand(),
			'now'     => $now,
			'today'   => wp_date( 'Y-m-d' ),
			'stages'  => LMCRM_DB::stages(),
			'stage_defs' => LMCRM_DB::stage_defs(),
			'templates'  => self::templates(),
			'template'   => (string) get_option( 'lmcrm_template', '' ),
			'sources_info' => current_user_can( 'manage_options' ) ? array(
				'forms' => array_values( LMCRM_Capture::detected() ),
				'meta'  => LMCRM_Meta::ready(),
				'rdv'   => class_exists( 'LMRDV_Bookings' ),
			) : null,
			'setup'   => (bool) get_option( 'lmcrm_setup_done' ),
			'admin'   => current_user_can( 'manage_options' ),
			'me'      => get_current_user_id(),
			'users'   => self::users(),
			'notify'  => LMCRM_Sources::notify_email(),
			'push'    => array( 'key' => LMCRM_Push::public_key(), 'devices' => LMCRM_Push::devices( get_current_user_id() ) ),
			'sw'      => admin_url( 'admin-ajax.php?action=lmcrm_sw' ),
			'manifest' => admin_url( 'admin-ajax.php?action=lmcrm_manifest' ),
			'sources' => LMCRM_DB::SOURCES,
			'counts'  => LMCRM_DB::stage_counts(),
			'stats'   => array(
				'new7'     => $new7,
				'prev7'    => $prev7,
				'response' => null === $resp ? null : (int) round( (float) $resp ),
				'won30'    => $won30,
				'sources'  => $src,
			),
			'fresh'   => $fresh,
			'tasks'   => $tasks,
			'agenda'  => self::agenda(),
			'meta'    => LMCRM_Meta::ready(),
		);
	}

	/** Prochain rendez-vous confirmé par courriel (60 jours) : array( courriel => array( s, title ) ). */
	private static function upcoming_meetings() {
		if ( ! class_exists( 'LMRDV_Bookings' ) ) {
			return array();
		}
		$out = array();
		foreach ( (array) LMRDV_Bookings::confirmed_between( time(), time() + 60 * DAY_IN_SECONDS ) as $b ) {
			if ( ! $b || empty( $b['email'] ) || (int) $b['start'] < time() ) {
				continue;
			}
			$k = strtolower( $b['email'] );
			if ( ! isset( $out[ $k ] ) || $out[ $k ]['s'] > (int) $b['start'] ) {
				$type      = class_exists( 'LMRDV_Settings' ) ? LMRDV_Settings::type( $b['type'] ) : null;
				$out[ $k ] = array( 's' => (int) $b['start'], 'title' => $type['name'] ?? 'Rendez-vous' );
			}
		}
		return $out;
	}

	/** Agenda du jour (mêmes règles que l'ancien écran : détails LM Web, plages occupées sans titre). */
	private static function agenda() {
		if ( ! class_exists( 'LMRDV_Bookings' ) ) {
			return array();
		}
		$start = ( new DateTime( 'today', wp_timezone() ) )->getTimestamp();
		$end   = $start + DAY_IN_SECONDS;
		$out   = array();
		foreach ( (array) LMRDV_Bookings::confirmed_between( $start, $end ) as $b ) {
			if ( ! $b ) {
				continue;
			}
			$type  = class_exists( 'LMRDV_Settings' ) ? LMRDV_Settings::type( $b['type'] ) : null;
			$c     = LMCRM_DB::contact_by_email( $b['email'] );
			$out[] = array(
				's'       => (int) $b['start'],
				'e'       => (int) $b['end'],
				'title'   => $type['name'] ?? 'Rendez-vous',
				'who'     => $c ? LMCRM_DB::label( $c ) : $b['name'],
				'contact' => $c ? (int) $c['id'] : null,
				'phone'   => $b['phone'],
				'meet'    => $b['meet'],
			);
		}
		if ( class_exists( 'LMRDV_Settings' ) && method_exists( 'LMRDV_Settings', 'google_ready' ) && LMRDV_Settings::google_ready() && class_exists( 'LMRDV_Google' ) ) {
			$busy = LMRDV_Google::busy( $start, $end );
			if ( ! is_wp_error( $busy ) ) {
				foreach ( $busy as $r ) {
					$hit = false;
					foreach ( $out as $o ) {
						if ( $r[0] < $o['e'] && $r[1] > $o['s'] ) {
							$hit = true;
							break;
						}
					}
					if ( ! $hit ) {
						$out[] = array( 's' => $r[0], 'e' => $r[1], 'busy' => true );
					}
				}
			}
		}
		usort( $out, function ( $a, $b ) {
			return $a['s'] <=> $b['s'];
		} );
		return $out;
	}

	/* ---------- Contacts ---------- */

	public static function list_contacts( WP_REST_Request $r ) {
		global $wpdb;
		$where = array( '1=1' );
		$vals  = array();
		$s     = trim( (string) $r->get_param( 's' ) );
		if ( '' !== $s ) {
			$like    = '%' . $wpdb->esc_like( $s ) . '%';
			$where[] = '(c.name LIKE %s OR c.company LIKE %s OR c.email LIKE %s OR c.phone LIKE %s OR c.city LIKE %s)';
			array_push( $vals, $like, $like, $like, $like, $like );
		}
		$stage = sanitize_key( (string) $r->get_param( 'stage' ) );
		if ( LMCRM_DB::has_stage( $stage ) ) {
			$where[] = 'c.stage = %s';
			$vals[]  = $stage;
		}
		$source = sanitize_key( (string) $r->get_param( 'source' ) );
		if ( isset( LMCRM_DB::SOURCES[ $source ] ) ) {
			$where[] = 'c.source = %s';
			$vals[]  = $source;
		}
		if ( 'mine' === $r->get_param( 'filter' ) ) {
			$where[] = 'c.owner_id = %d';
			$vals[]  = get_current_user_id();
		}
		if ( 'late' === $r->get_param( 'filter' ) ) {
			$where[] = 'EXISTS (SELECT 1 FROM ' . self::t( 'tasks' ) . ' z WHERE z.contact_id = c.id AND z.done_at IS NULL AND z.due_at < %s)';
			$vals[]  = wp_date( 'Y-m-d 00:00:00' );
		}
		$sorts = array( 'recent' => 'c.last_activity_at DESC', 'new' => 'c.created_at DESC', 'name' => 'c.name ASC', 'value' => 'c.value DESC', 'next' => 'next_due IS NULL, next_due ASC' );
		$sort  = $sorts[ (string) $r->get_param( 'sort' ) ] ?? $sorts['recent'];
		$per   = 40;
		$page  = max( 1, (int) $r->get_param( 'page' ) );
		$sql   = 'SELECT SQL_CALC_FOUND_ROWS ' . self::select() . ' FROM ' . self::t( 'contacts' ) . ' c WHERE ' . implode( ' AND ', $where ) . " ORDER BY $sort, c.id DESC LIMIT %d OFFSET %d";
		$vals[] = $per;
		$vals[] = ( $page - 1 ) * $per;
		$rows   = $wpdb->get_results( $wpdb->prepare( $sql, $vals ), ARRAY_A );
		$total  = (int) $wpdb->get_var( 'SELECT FOUND_ROWS()' );
		return array( 'rows' => array_map( array( __CLASS__, 'shape' ), $rows ), 'total' => $total, 'page' => $page, 'pages' => (int) ceil( $total / $per ) );
	}

	private static function full( $id ) {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( 'SELECT ' . self::select() . ' FROM ' . self::t( 'contacts' ) . ' c WHERE c.id = %d', $id ), ARRAY_A );
		if ( ! $row ) {
			return new WP_Error( 'lmcrm', 'Contact introuvable', array( 'status' => 404 ) );
		}
		return array(
			'contact'    => self::shape( $row ),
			'activities' => LMCRM_DB::activities( $id ),
			'tasks'      => LMCRM_DB::tasks_for( $id ),
		);
	}

	public static function get_contact( WP_REST_Request $r ) {
		return self::full( (int) $r['id'] );
	}

	public static function create_contact( WP_REST_Request $r ) {
		$d = (array) $r->get_json_params();
		if ( empty( $d['name'] ) && empty( $d['company'] ) && empty( $d['email'] ) && empty( $d['phone'] ) ) {
			return new WP_Error( 'lmcrm', 'Indiquez au moins un nom, une entreprise, un courriel ou un téléphone.', array( 'status' => 400 ) );
		}
		$d['source'] = $d['source'] ?? 'manuel';
		$d['stage']  = $d['stage'] ?? 'nouveau';
		if ( ! empty( $d['email'] ) && LMCRM_DB::contact_by_email( $d['email'] ) ) {
			$id = (int) LMCRM_DB::contact_by_email( $d['email'] )['id'];
		} else {
			$id = LMCRM_DB::insert_contact( $d );
			LMCRM_DB::add_activity( $id, 'note', 'Contact créé' );
		}
		if ( ! empty( $d['task'] ) && ! empty( $d['task']['title'] ) ) {
			LMCRM_DB::add_task( $id, $d['task']['title'], self::due( $d['task']['due'] ?? '' ) );
		}
		return self::full( $id );
	}

	public static function patch_contact( WP_REST_Request $r ) {
		$id = (int) $r['id'];
		$c  = LMCRM_DB::contact( $id );
		if ( ! $c ) {
			return new WP_Error( 'lmcrm', 'Contact introuvable', array( 'status' => 404 ) );
		}
		$d = (array) $r->get_json_params();
		if ( isset( $d['stage'] ) ) {
			LMCRM_DB::set_stage( $id, sanitize_key( $d['stage'] ) );
			unset( $d['stage'] );
		}
		if ( isset( $d['owner'] ) && (int) $d['owner'] !== (int) $c['owner_id'] ) {
			$who = (int) $d['owner'];
			LMCRM_DB::update_contact( $id, array( 'owner_id' => $who ) );
			$names = wp_list_pluck( self::users(), 'name', 'id' );
			LMCRM_DB::add_activity( $id, 'stage', $who ? 'Attribué à ' . ( $names[ $who ] ?? 'un membre' ) : 'Attribution retirée' );
		}
		$d = array_intersect_key( $d, array_flip( array( 'name', 'company', 'email', 'phone', 'website', 'city', 'value', 'notes', 'source', 'kind' ) ) );
		if ( $d ) {
			LMCRM_DB::update_contact( $id, $d );
		}
		return self::full( $id );
	}

	public static function delete_contact( WP_REST_Request $r ) {
		LMCRM_DB::delete_contact( (int) $r['id'] );
		return array( 'ok' => true );
	}

	public static function delete_activity( WP_REST_Request $r ) {
		LMCRM_DB::delete_activity( (int) $r['id'] );
		return array( 'ok' => true );
	}

	/** « 2026-11-02 », « 2026-11-02T14:30 » ou « +3 » (jours ouvrables) → datetime MySQL. */
	private static function due( $v ) {
		$v = trim( (string) $v );
		if ( '' === $v ) {
			return null;
		}
		if ( preg_match( '/^\+(\d+)$/', $v, $m ) ) {
			return LMCRM_DB::business_due( (int) $m[1] );
		}
		if ( preg_match( '/^\d{4}-\d{2}-\d{2}$/', $v ) ) {
			return $v . ' 09:00:00';
		}
		if ( preg_match( '/^(\d{4}-\d{2}-\d{2})[T ](\d{2}:\d{2})/', $v, $m ) ) {
			return $m[1] . ' ' . $m[2] . ':00';
		}
		return null;
	}

	/**
	 * Journal d'une action : note, appel (avec résultat), courriel, texto.
	 * Peut terminer une tâche et en créer la suite en un seul envoi.
	 */
	public static function log( WP_REST_Request $r ) {
		$id = (int) $r['id'];
		$c  = LMCRM_DB::contact( $id );
		if ( ! $c ) {
			return new WP_Error( 'lmcrm', 'Contact introuvable', array( 'status' => 404 ) );
		}
		$d       = (array) $r->get_json_params();
		$kind    = in_array( $d['kind'] ?? '', array( 'note', 'call', 'email', 'sms' ), true ) ? $d['kind'] : 'note';
		$outcome = sanitize_key( $d['outcome'] ?? '' );
		$body    = sanitize_textarea_field( $d['body'] ?? '' );
		$labels  = array(
			'reached'  => 'Appel : joint',
			'voicemail' => 'Appel : message laissé',
			'noanswer' => 'Appel : pas de réponse',
			'lost'     => 'Appel : pas intéressé',
			'wrong'    => 'Appel : mauvais numéro',
		);
		$titles = array( 'note' => 'Note', 'call' => $labels[ $outcome ] ?? 'Appel', 'email' => 'Courriel envoyé', 'sms' => 'Texto envoyé' );
		if ( 'note' !== $kind || '' !== trim( $body ) ) {
			LMCRM_DB::add_activity( $id, 'note' === $kind ? 'note' : $kind, $titles[ $kind ], $body );
		}
		if ( 'note' !== $kind && ! in_array( $outcome, array( 'wrong' ), true ) ) {
			LMCRM_DB::mark_contacted( $id );
		}
		if ( 'call' === $kind && 'reached' === $outcome && 'nouveau' === $c['stage'] ) {
			LMCRM_DB::set_stage( $id, 'contacte' );
		}
		if ( 'call' === $kind && 'lost' === $outcome ) {
			LMCRM_DB::set_stage( $id, 'perdu' );
		}
		if ( ! empty( $d['done_task'] ) ) {
			LMCRM_DB::complete_task( (int) $d['done_task'] );
		}
		if ( ! empty( $d['next'] ) && ! empty( $d['next']['title'] ) ) {
			LMCRM_DB::add_task( $id, $d['next']['title'], self::due( $d['next']['due'] ?? '' ) );
		}
		return self::full( $id );
	}

	/* ---------- Tâches ---------- */

	public static function create_task( WP_REST_Request $r ) {
		$d  = (array) $r->get_json_params();
		$id = LMCRM_DB::add_task( (int) ( $d['contact_id'] ?? 0 ), (string) ( $d['title'] ?? 'Relance' ), self::due( $d['due'] ?? '' ) );
		return array( 'ok' => (bool) $id, 'id' => $id );
	}

	public static function patch_task( WP_REST_Request $r ) {
		global $wpdb;
		$d   = (array) $r->get_json_params();
		$row = array();
		if ( isset( $d['due'] ) ) {
			$row['due_at'] = self::due( $d['due'] );
		}
		if ( isset( $d['title'] ) && '' !== trim( (string) $d['title'] ) ) {
			$row['title'] = mb_substr( sanitize_text_field( $d['title'] ), 0, 255 );
		}
		if ( $row ) {
			$wpdb->update( self::t( 'tasks' ), $row, array( 'id' => (int) $r['id'] ) );
		}
		if ( isset( $d['done'] ) ) {
			$d['done'] ? LMCRM_DB::complete_task( (int) $r['id'] ) : LMCRM_DB::reopen_task( (int) $r['id'] );
		}
		return array( 'ok' => true, 'task' => LMCRM_DB::task( (int) $r['id'] ) );
	}

	public static function delete_task( WP_REST_Request $r ) {
		LMCRM_DB::delete_task( (int) $r['id'] );
		return array( 'ok' => true );
	}

	/* ---------- Pipeline et recherche ---------- */

	public static function pipeline() {
		global $wpdb;
		// Les perdus restent visibles 90 jours après leur dernière activité.
		$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT ' . self::select() . ' FROM ' . self::t( 'contacts' ) . " c WHERE c.stage <> 'perdu' OR c.last_activity_at >= %s ORDER BY c.last_activity_at DESC LIMIT 800", wp_date( 'Y-m-d H:i:s', time() - 90 * DAY_IN_SECONDS ) ), ARRAY_A );
		return array( 'rows' => array_map( array( __CLASS__, 'shape' ), $rows ), 'counts' => LMCRM_DB::stage_counts() );
	}

	public static function search( WP_REST_Request $r ) {
		$r->set_param( 'sort', 'recent' );
		$res = self::list_contacts( $r );
		return array( 'rows' => array_slice( $res['rows'], 0, 8 ) );
	}

	/* ---------- Assistant d'installation ---------- */

	public static function templates() {
		$out = array();
		foreach ( LMCRM_DB::TEMPLATES as $k => $t ) {
			$out[] = array( 'key' => $k, 'label' => $t['label'], 'hint' => $t['hint'], 'stages' => array_values( $t['stages'] ) );
		}
		return $out;
	}

	public static function setup( WP_REST_Request $r ) {
		$d = (array) $r->get_json_params();
		if ( isset( $d['brand'] ) ) {
			$b     = (array) $d['brand'];
			$color = sanitize_hex_color( $b['color'] ?? '' );
			update_option( 'lmcrm_brand', array(
				'name'  => mb_substr( sanitize_text_field( $b['name'] ?? '' ), 0, 40 ),
				'color' => $color ? $color : '#FF7020',
				'logo'  => esc_url_raw( $b['logo'] ?? '' ),
			), false );
		}
		if ( ! empty( $d['template'] ) && isset( LMCRM_DB::TEMPLATES[ $d['template'] ] ) ) {
			LMCRM_DB::apply_template( $d['template'] );
		}
		if ( isset( $d['notify'] ) ) {
			$e = sanitize_email( $d['notify'] );
			update_option( 'lmcrm_notify', is_email( $e ) ? $e : '', false );
		}
		if ( ! empty( $d['done'] ) ) {
			update_option( 'lmcrm_setup_done', 1, false );
		}
		return self::boot();
	}

	/* ---------- Notifications ---------- */

	public static function push_subscribe( WP_REST_Request $r ) {
		$ok = LMCRM_Push::subscribe( (array) $r->get_json_params(), get_current_user_id(), (string) $r->get_header( 'user-agent' ) );
		if ( ! $ok ) {
			return new WP_Error( 'lmcrm', 'Abonnement refusé par le navigateur.', array( 'status' => 400 ) );
		}
		return array( 'ok' => true, 'devices' => LMCRM_Push::devices( get_current_user_id() ) );
	}

	public static function push_unsubscribe( WP_REST_Request $r ) {
		LMCRM_Push::unsubscribe( (string) ( $r->get_json_params()['endpoint'] ?? '' ) );
		return array( 'ok' => true, 'devices' => LMCRM_Push::devices( get_current_user_id() ) );
	}

	public static function push_test() {
		$res = LMCRM_Push::send( array(
			'title' => 'Notifications activées',
			'body'  => 'Chaque nouveau prospect arrivera ici, avec un lien direct vers sa fiche.',
			'url'   => admin_url( 'admin.php?page=lmcrm' ),
			'tag'   => 'test',
			'icon'  => LMCRM_Push::icon_url( 192 ),
		), get_current_user_id() );
		return $res;
	}

	/* ---------- Webhook Google Ads (formulaires de prospects) ---------- */

	public static function google_key() {
		$k = (string) get_option( 'lmcrm_google_key', '' );
		if ( '' === $k ) {
			$k = wp_generate_password( 32, false );
			update_option( 'lmcrm_google_key', $k, false );
		}
		return $k;
	}

	public static function google_lead( WP_REST_Request $r ) {
		$d = (array) $r->get_json_params();
		if ( empty( $d['google_key'] ) || ! hash_equals( self::google_key(), (string) $d['google_key'] ) ) {
			return new WP_REST_Response( array( 'error' => 'clé invalide' ), 403 );
		}
		$f = array();
		foreach ( (array) ( $d['user_column_data'] ?? array() ) as $col ) {
			$key       = strtoupper( (string) ( $col['column_id'] ?? '' ) );
			$f[ $key ] = (string) ( $col['string_value'] ?? '' );
		}
		$name = $f['FULL_NAME'] ?? trim( ( $f['FIRST_NAME'] ?? '' ) . ' ' . ( $f['LAST_NAME'] ?? '' ) );
		$test = ! empty( $d['is_test'] );
		$data = array(
			'name'    => $name . ( $test ? ' (test Google)' : '' ),
			'email'   => $f['EMAIL'] ?? '',
			'phone'   => $f['PHONE_NUMBER'] ?? '',
			'company' => $f['COMPANY_NAME'] ?? '',
			'city'    => $f['CITY'] ?? '',
			'source'  => 'google',
			'stage'   => 'nouveau',
		);
		if ( ! empty( $data['email'] ) ) {
			list( $cid ) = LMCRM_DB::upsert_contact( $data );
		} else {
			$cid = LMCRM_DB::insert_contact( $data );
		}
		$lines = array();
		foreach ( $f as $k => $v ) {
			if ( ! in_array( $k, array( 'FULL_NAME', 'FIRST_NAME', 'LAST_NAME', 'EMAIL', 'PHONE_NUMBER', 'COMPANY_NAME', 'CITY' ), true ) ) {
				$lines[] = ucfirst( strtolower( str_replace( '_', ' ', $k ) ) ) . ' : ' . $v;
			}
		}
		if ( ! empty( $d['campaign_id'] ) ) {
			$lines[] = 'Campagne Google Ads : ' . $d['campaign_id'];
		}
		$ref = 'google:' . sanitize_key( (string) ( $d['lead_id'] ?? wp_generate_password( 12, false ) ) );
		LMCRM_DB::add_activity( $cid, 'google', 'Prospect Google Ads' . ( $test ? ' (test)' : '' ), implode( "\n", $lines ), $ref );
		LMCRM_DB::add_task( $cid, 'Rappeler le prospect Google', LMCRM_DB::now(), 'task:' . $ref );
		LMCRM_Notify::lead( $cid, 'Nouveau prospect Google Ads : ' . ( $name ?: $data['email'] ), "Nom : $name\nCourriel : {$data['email']}\nTéléphone : {$data['phone']}\n\n" . implode( "\n", $lines ) . "\n\nFiche : " . admin_url( 'admin.php?page=lmcrm#/contact/' . $cid ) );
		return array( 'ok' => true );
	}
}

<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Notifications sur téléphone et ordinateur (Web Push, norme ouverte des navigateurs).
 * Aucun service tiers ni abonnement : le site signe (VAPID) et chiffre (aes128gcm, RFC 8291)
 * chaque message lui-même, puis le remet au service de notifications du navigateur
 * (Google pour Chrome et Android, Apple pour Safari et iPhone, Mozilla pour Firefox).
 */
class LMCRM_Push {

	const SUBS = 'lmcrm_push_subs';
	const KEYS = 'lmcrm_vapid';

	public static function supported() {
		return function_exists( 'openssl_pkey_new' ) && function_exists( 'openssl_pkey_derive' ) && function_exists( 'hash_hkdf' );
	}

	public static function init() {
		// Service worker et manifeste servis par admin-ajax : portée /wp-admin/, donc l'app installée
		// (écran d'accueil du téléphone) et ses notifications fonctionnent sans fichier à la racine du site.
		add_action( 'wp_ajax_lmcrm_sw', array( __CLASS__, 'service_worker' ) );
		add_action( 'wp_ajax_nopriv_lmcrm_sw', array( __CLASS__, 'service_worker' ) );
		add_action( 'wp_ajax_lmcrm_manifest', array( __CLASS__, 'manifest' ) );
		add_action( 'wp_ajax_nopriv_lmcrm_manifest', array( __CLASS__, 'manifest' ) );
	}

	/* ---------- Clés VAPID ---------- */

	private static function b64u( $bin ) {
		return rtrim( strtr( base64_encode( $bin ), '+/', '-_' ), '=' );
	}

	private static function b64u_dec( $s ) {
		$s = strtr( (string) $s, '-_', '+/' );
		return (string) base64_decode( $s . str_repeat( '=', ( 4 - strlen( $s ) % 4 ) % 4 ), true );
	}

	/** Point public non compressé (65 octets) d'une clé EC P-256. */
	private static function raw_public( $key ) {
		$d = openssl_pkey_get_details( $key );
		return "\x04" . str_pad( $d['ec']['x'], 32, "\0", STR_PAD_LEFT ) . str_pad( $d['ec']['y'], 32, "\0", STR_PAD_LEFT );
	}

	/** Clé publique PEM à partir d'un point brut de 65 octets. */
	private static function pem_from_raw( $raw ) {
		$der = hex2bin( '3059301306072a8648ce3d020106082a8648ce3d030107034200' ) . $raw;
		return "-----BEGIN PUBLIC KEY-----\n" . chunk_split( base64_encode( $der ), 64, "\n" ) . "-----END PUBLIC KEY-----\n";
	}

	private static function new_key() {
		return openssl_pkey_new( array( 'private_key_type' => OPENSSL_KEYTYPE_EC, 'curve_name' => 'prime256v1' ) );
	}

	/** @return array{pem:string,public:string} */
	public static function vapid() {
		$v = get_option( self::KEYS );
		if ( is_array( $v ) && ! empty( $v['pem'] ) && ! empty( $v['public'] ) ) {
			return $v;
		}
		$k = self::new_key();
		openssl_pkey_export( $k, $pem );
		$v = array( 'pem' => $pem, 'public' => self::b64u( self::raw_public( $k ) ) );
		update_option( self::KEYS, $v, false );
		return $v;
	}

	public static function public_key() {
		return self::supported() ? self::vapid()['public'] : '';
	}

	/* ---------- Abonnements ---------- */

	public static function subs() {
		$s = get_option( self::SUBS, array() );
		return is_array( $s ) ? $s : array();
	}

	public static function subscribe( array $sub, $user_id, $ua = '' ) {
		$ep = esc_url_raw( $sub['endpoint'] ?? '' );
		$p  = (string) ( $sub['keys']['p256dh'] ?? '' );
		$a  = (string) ( $sub['keys']['auth'] ?? '' );
		if ( 0 !== strpos( $ep, 'https://' ) || 65 !== strlen( self::b64u_dec( $p ) ) || 16 !== strlen( self::b64u_dec( $a ) ) ) {
			return false;
		}
		$subs        = self::subs();
		$subs[ md5( $ep ) ] = array(
			'endpoint' => $ep,
			'p256dh'   => $p,
			'auth'     => $a,
			'user'     => (int) $user_id,
			'device'   => self::device( $ua ),
			'created'  => LMCRM_DB::now(),
		);
		update_option( self::SUBS, $subs, false );
		return true;
	}

	public static function unsubscribe( $endpoint ) {
		$subs = self::subs();
		unset( $subs[ md5( (string) $endpoint ) ] );
		update_option( self::SUBS, $subs, false );
	}

	private static function device( $ua ) {
		$ua = (string) $ua;
		foreach ( array( 'iPhone' => 'iPhone', 'iPad' => 'iPad', 'Android' => 'Android', 'Macintosh' => 'Mac', 'Windows' => 'Windows' ) as $k => $l ) {
			if ( false !== stripos( $ua, $k ) ) {
				return $l;
			}
		}
		return 'Navigateur';
	}

	/** Appareils abonnés pour un utilisateur (pour l'affichage). */
	public static function devices( $user_id = null ) {
		$out = array();
		foreach ( self::subs() as $id => $s ) {
			if ( null === $user_id || (int) $s['user'] === (int) $user_id ) {
				$out[] = array( 'id' => $id, 'device' => $s['device'], 'created' => $s['created'] );
			}
		}
		return $out;
	}

	/* ---------- Envoi ---------- */

	/**
	 * Envoie une notification à tous les appareils (ou à ceux d'un utilisateur).
	 *
	 * @return array{sent:int,failed:int,errors:array}
	 */
	public static function send( array $payload, $user_id = null ) {
		$res = array( 'sent' => 0, 'failed' => 0, 'errors' => array() );
		if ( ! self::supported() ) {
			$res['errors'][] = 'OpenSSL incomplet sur ce serveur';
			return $res;
		}
		$subs = self::subs();
		$json = wp_json_encode( $payload );
		$dead = false;
		foreach ( $subs as $id => $s ) {
			if ( null !== $user_id && (int) $s['user'] !== (int) $user_id ) {
				continue;
			}
			$code = self::deliver( $s, $json );
			if ( $code >= 200 && $code < 300 ) {
				$res['sent']++;
				continue;
			}
			$res['failed']++;
			$res['errors'][] = $s['device'] . ' : ' . $code;
			if ( 404 === $code || 410 === $code ) {
				unset( $subs[ $id ] ); // Abonnement expiré ou retiré par l'utilisateur.
				$dead = true;
			}
		}
		if ( $dead ) {
			update_option( self::SUBS, $subs, false );
		}
		return $res;
	}

	/** @return int Code HTTP (0 en cas d'erreur réseau). */
	private static function deliver( array $s, $json ) {
		$body = self::encrypt( $json, self::b64u_dec( $s['p256dh'] ), self::b64u_dec( $s['auth'] ) );
		if ( false === $body ) {
			return 0;
		}
		$parts = wp_parse_url( $s['endpoint'] );
		$aud   = $parts['scheme'] . '://' . $parts['host'];
		$v     = self::vapid();
		$jwt   = self::jwt( $aud, $v['pem'] );
		if ( ! $jwt ) {
			return 0;
		}
		$r = wp_remote_post( $s['endpoint'], array(
			'timeout' => 8,
			'headers' => array(
				'TTL'              => '86400',
				'Urgency'          => 'high',
				'Content-Type'     => 'application/octet-stream',
				'Content-Encoding' => 'aes128gcm',
				'Authorization'    => 'vapid t=' . $jwt . ', k=' . $v['public'],
			),
			'body'    => $body,
		) );
		return is_wp_error( $r ) ? 0 : (int) wp_remote_retrieve_response_code( $r );
	}

	/** Jeton VAPID (JWT ES256) valable 12 h. */
	public static function jwt( $aud, $pem ) {
		$sub    = get_option( 'admin_email' );
		$header = self::b64u( wp_json_encode( array( 'typ' => 'JWT', 'alg' => 'ES256' ) ) );
		$claims = self::b64u( wp_json_encode( array( 'aud' => $aud, 'exp' => time() + 12 * HOUR_IN_SECONDS, 'sub' => 'mailto:' . $sub ) ) );
		$input  = $header . '.' . $claims;
		$key    = openssl_pkey_get_private( $pem );
		if ( ! $key || ! openssl_sign( $input, $der, $key, OPENSSL_ALGO_SHA256 ) ) {
			return '';
		}
		return $input . '.' . self::b64u( self::der_to_raw( $der ) );
	}

	/** Signature ECDSA : DER (SEQUENCE de deux INTEGER) vers r||s de 64 octets. */
	private static function der_to_raw( $der ) {
		$pos = 2;
		if ( ord( $der[1] ) & 0x80 ) {
			$pos += ord( $der[1] ) & 0x7f;
		}
		$out = '';
		for ( $i = 0; $i < 2; $i++ ) {
			$len  = ord( $der[ $pos + 1 ] );
			$int  = substr( $der, $pos + 2, $len );
			$int  = ltrim( $int, "\0" );
			$out .= str_pad( $int, 32, "\0", STR_PAD_LEFT );
			$pos += 2 + $len;
		}
		return $out;
	}

	/**
	 * Chiffrement aes128gcm du message pour un abonné (RFC 8291 + RFC 8188).
	 *
	 * @param string $plain Message.
	 * @param string $ua_pub Clé publique de l'abonné (65 octets).
	 * @param string $auth Secret d'authentification de l'abonné (16 octets).
	 * @return string|false Corps binaire de la requête.
	 */
	public static function encrypt( $plain, $ua_pub, $auth ) {
		if ( 65 !== strlen( $ua_pub ) || 16 !== strlen( $auth ) ) {
			return false;
		}
		$eph    = self::new_key();
		$as_pub = self::raw_public( $eph );
		$peer   = openssl_pkey_get_public( self::pem_from_raw( $ua_pub ) );
		if ( ! $peer ) {
			return false;
		}
		$ecdh = openssl_pkey_derive( $peer, $eph, 32 );
		if ( false === $ecdh ) {
			return false;
		}
		$ikm   = hash_hkdf( 'sha256', $ecdh, 32, "WebPush: info\0" . $ua_pub . $as_pub, $auth );
		$salt  = random_bytes( 16 );
		$cek   = hash_hkdf( 'sha256', $ikm, 16, "Content-Encoding: aes128gcm\0", $salt );
		$nonce = hash_hkdf( 'sha256', $ikm, 12, "Content-Encoding: nonce\0", $salt );
		$tag   = '';
		$ct    = openssl_encrypt( $plain . "\x02", 'aes-128-gcm', $cek, OPENSSL_RAW_DATA, $nonce, $tag, '', 16 );
		if ( false === $ct ) {
			return false;
		}
		return $salt . pack( 'N', 4096 ) . chr( 65 ) . $as_pub . $ct . $tag;
	}

	/* ---------- Fichiers de l'application installable ---------- */

	public static function service_worker() {
		nocache_headers();
		header( 'Content-Type: application/javascript; charset=utf-8' );
		header( 'Service-Worker-Allowed: ' . wp_parse_url( admin_url(), PHP_URL_PATH ) );
		$app = admin_url( 'admin.php?page=lmcrm' );
		echo "/* LM Web CRM : notifications */\n"
			. "self.addEventListener('install', function () { self.skipWaiting(); });\n"
			. "self.addEventListener('activate', function (e) { e.waitUntil(self.clients.claim()); });\n"
			. "self.addEventListener('push', function (e) {\n"
			. "  var d = {}; try { d = e.data ? e.data.json() : {}; } catch (x) { d = { title: 'CRM', body: e.data ? e.data.text() : '' }; }\n"
			. "  e.waitUntil(self.registration.showNotification(d.title || 'Nouveau prospect', { body: d.body || '', tag: d.tag || undefined, renotify: !!d.tag, icon: d.icon || undefined, badge: d.badge || undefined, data: { url: d.url || " . wp_json_encode( $app ) . " }, requireInteraction: !!d.sticky }));\n"
			. "});\n"
			. "self.addEventListener('notificationclick', function (e) {\n"
			. "  e.notification.close(); var url = (e.notification.data && e.notification.data.url) || " . wp_json_encode( $app ) . ";\n"
			. "  e.waitUntil(self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then(function (list) {\n"
			. "    for (var i = 0; i < list.length; i++) { var c = list[i]; if (c.url.indexOf('page=lmcrm') > -1 && 'focus' in c) { c.navigate ? c.navigate(url) : null; return c.focus(); } }\n"
			. "    return self.clients.openWindow(url);\n"
			. "  }));\n"
			. "});\n";
		exit;
	}

	public static function icon_url( $size = 192 ) {
		$b = LMCRM_API::brand();
		if ( ! empty( $b['logo'] ) ) {
			return $b['logo'];
		}
		$i = get_site_icon_url( $size );
		return $i ? $i : '';
	}

	public static function manifest() {
		nocache_headers();
		header( 'Content-Type: application/manifest+json; charset=utf-8' );
		$b     = LMCRM_API::brand();
		$icons = array();
		foreach ( array( 192, 512 ) as $sz ) {
			$u = self::icon_url( $sz );
			if ( $u ) {
				$icons[] = array( 'src' => $u, 'sizes' => $sz . 'x' . $sz, 'purpose' => 'any' );
			}
		}
		echo wp_json_encode( array(
			'name'             => $b['name'],
			'short_name'       => mb_substr( $b['name'], 0, 12 ),
			'start_url'        => admin_url( 'admin.php?page=lmcrm' ),
			'scope'            => wp_parse_url( admin_url(), PHP_URL_PATH ),
			'display'          => 'standalone',
			'background_color' => '#F2F4F7',
			'theme_color'      => '#13213D',
			'icons'            => $icons,
		) );
		exit;
	}
}

/**
 * Avis d'un nouveau prospect : courriel (comme avant) et notification sur les appareils abonnés.
 */
class LMCRM_Notify {

	/**
	 * @param int    $cid Contact.
	 * @param string $subject Objet du courriel (ex. « Nouveau prospect Meta : Sophie Tremblay »).
	 * @param string $text Corps du courriel (texte brut). Vide : pas de courriel.
	 * @param array  $headers En-têtes du courriel.
	 */
	public static function lead( $cid, $subject, $text = '', array $headers = array(), $push_title = '' ) {
		if ( '' !== $text ) {
			wp_mail( LMCRM_Sources::notify_email(), $subject, $text, $headers );
		}
		$c = LMCRM_DB::contact( $cid );
		if ( ! $c || ! LMCRM_Push::subs() ) {
			return;
		}
		$src  = LMCRM_DB::SOURCES[ $c['source'] ] ?? '';
		$body = implode( ' · ', array_filter( array( $c['company'] && strcasecmp( $c['company'], $c['name'] ) ? $c['company'] : '', $c['kind'] ?? '', $c['phone'] ?: $c['email'] ) ) );
		LMCRM_Push::send( array(
			'title' => ( $push_title ? $push_title : 'Nouveau prospect' . ( $src ? ' · ' . $src : '' ) ) . ' : ' . LMCRM_DB::label( array( 'name' => $c['name'], 'email' => $c['email'], 'id' => $c['id'] ) ),
			'body'  => $body ? $body : 'Touchez pour ouvrir la fiche et appeler.',
			'url'   => admin_url( 'admin.php?page=lmcrm#/contact/' . (int) $cid ),
			'tag'   => 'lead-' . (int) $cid,
			'icon'  => LMCRM_Push::icon_url( 192 ),
		), $c['owner_id'] ? (int) $c['owner_id'] : null );
	}
}

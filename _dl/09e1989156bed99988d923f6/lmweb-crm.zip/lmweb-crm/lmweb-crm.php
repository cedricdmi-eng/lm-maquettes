<?php
/**
 * Plugin Name: LM Web – CRM
 * Description: Suivi des prospects et clients : file des prospects à rappeler, pipeline, fiches, relances, notifications sur téléphone. Alimenté par les formulaires du site (natif, Forminator, Contact Form 7, WPForms, Gravity, Fluent, Elementor), Meta, Google Ads et LM Web Rendez-vous. Aucun fichier chargé sur les pages publiques (sauf le formulaire natif, là où il est placé).
 * Version: 3.1.2
 * Author: LM Web
 * Author URI: https://lm-web.ca/
 * Requires PHP: 7.4
 * Requires at least: 6.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'LMCRM_VERSION', '3.1.2' );
define( 'LMCRM_DB_VERSION', '3' );
define( 'LMCRM_DIR', __DIR__ );
define( 'LMCRM_URL', plugin_dir_url( __FILE__ ) );

require_once LMCRM_DIR . '/includes/class-db.php';
require_once LMCRM_DIR . '/includes/class-sources.php';
require_once LMCRM_DIR . '/includes/class-form.php';
require_once LMCRM_DIR . '/includes/class-rest.php';
require_once LMCRM_DIR . '/includes/class-meta.php';
require_once LMCRM_DIR . '/includes/class-push.php';
require_once LMCRM_DIR . '/includes/class-capture.php';
require_once LMCRM_DIR . '/includes/class-api.php';
require_once LMCRM_DIR . '/includes/class-updater.php';

if ( is_admin() ) {
	require_once LMCRM_DIR . '/includes/class-admin.php';
	LMCRM_Admin::init();
}

register_activation_hook( __FILE__, array( 'LMCRM_DB', 'activate' ) );
register_deactivation_hook( __FILE__, function () {
	wp_clear_scheduled_hook( 'lmcrm_sync' );
	wp_clear_scheduled_hook( 'lmcrm_digest' );
	wp_clear_scheduled_hook( 'lmcrm_meta_sync' );
} );

add_action( 'plugins_loaded', array( 'LMCRM_DB', 'maybe_upgrade' ) );

// Les membres de l'équipe (rôle « Utilisateur CRM ») arrivent directement dans le CRM.
add_filter( 'login_redirect', function ( $to, $requested, $user ) {
	if ( $user instanceof WP_User && user_can( $user, 'lmcrm_use' ) && ! user_can( $user, 'manage_options' ) ) {
		return admin_url( 'admin.php?page=lmcrm' );
	}
	return $to;
}, 10, 3 );

LMCRM_Sources::init();
LMCRM_Form::init();
LMCRM_REST::init();
LMCRM_Meta::init();
LMCRM_Push::init();
LMCRM_Capture::init();
LMCRM_API::init();
LMCRM_Updater::init();
